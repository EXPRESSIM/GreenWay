<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUpsizer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUpsizer))
        Me.txtServer = New System.Windows.Forms.TextBox
        Me.txtDatabase = New System.Windows.Forms.TextBox
        Me.txtERDFile = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnUpsize = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtUserName = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtPassWord = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.btnBrowse = New System.Windows.Forms.Button
        Me.chkImpDri = New System.Windows.Forms.CheckBox
        Me.chkDrpObsolete = New System.Windows.Forms.CheckBox
        Me.grpStatus = New System.Windows.Forms.GroupBox
        Me.lblStatusMsg2 = New System.Windows.Forms.Label
        Me.lblStatusMsg1 = New System.Windows.Forms.Label
        Me.txtErrors = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.chkLogSQL = New System.Windows.Forms.CheckBox
        Me.lblTimeout = New System.Windows.Forms.Label
        Me.txtTimeOut = New System.Windows.Forms.TextBox
        Me.grpStatus.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtServer
        '
        Me.txtServer.Location = New System.Drawing.Point(121, 45)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.Size = New System.Drawing.Size(128, 20)
        Me.txtServer.TabIndex = 2
        '
        'txtDatabase
        '
        Me.txtDatabase.Location = New System.Drawing.Point(324, 45)
        Me.txtDatabase.Name = "txtDatabase"
        Me.txtDatabase.Size = New System.Drawing.Size(123, 20)
        Me.txtDatabase.TabIndex = 3
        '
        'txtERDFile
        '
        Me.txtERDFile.Location = New System.Drawing.Point(121, 10)
        Me.txtERDFile.Name = "txtERDFile"
        Me.txtERDFile.Size = New System.Drawing.Size(326, 20)
        Me.txtERDFile.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label1.Location = New System.Drawing.Point(70, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Server:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label2.Location = New System.Drawing.Point(253, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Database:"
        '
        'btnUpsize
        '
        Me.btnUpsize.Location = New System.Drawing.Point(491, 8)
        Me.btnUpsize.Name = "btnUpsize"
        Me.btnUpsize.Size = New System.Drawing.Size(75, 23)
        Me.btnUpsize.TabIndex = 6
        Me.btnUpsize.Text = "&Upsize"
        Me.btnUpsize.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label4.Location = New System.Drawing.Point(52, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Username:"
        '
        'txtUserName
        '
        Me.txtUserName.Location = New System.Drawing.Point(121, 75)
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.Size = New System.Drawing.Size(128, 20)
        Me.txtUserName.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label5.Location = New System.Drawing.Point(254, 76)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Password:"
        '
        'txtPassWord
        '
        Me.txtPassWord.Location = New System.Drawing.Point(324, 75)
        Me.txtPassWord.Name = "txtPassWord"
        Me.txtPassWord.Size = New System.Drawing.Size(123, 20)
        Me.txtPassWord.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label6.Location = New System.Drawing.Point(21, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(99, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Data Dictionary:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(453, 8)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(25, 23)
        Me.btnBrowse.TabIndex = 0
        Me.btnBrowse.Text = "..."
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'chkImpDri
        '
        Me.chkImpDri.AutoSize = True
        Me.chkImpDri.Location = New System.Drawing.Point(55, 108)
        Me.chkImpDri.Name = "chkImpDri"
        Me.chkImpDri.Size = New System.Drawing.Size(96, 17)
        Me.chkImpDri.TabIndex = 13
        Me.chkImpDri.Text = "Implement DRI"
        Me.chkImpDri.UseVisualStyleBackColor = True
        '
        'chkDrpObsolete
        '
        Me.chkDrpObsolete.AutoSize = True
        Me.chkDrpObsolete.Location = New System.Drawing.Point(157, 108)
        Me.chkDrpObsolete.Name = "chkDrpObsolete"
        Me.chkDrpObsolete.Size = New System.Drawing.Size(120, 17)
        Me.chkDrpObsolete.TabIndex = 14
        Me.chkDrpObsolete.Text = "Drop Obsolete Data"
        Me.chkDrpObsolete.UseVisualStyleBackColor = True
        '
        'grpStatus
        '
        Me.grpStatus.Controls.Add(Me.lblStatusMsg2)
        Me.grpStatus.Controls.Add(Me.lblStatusMsg1)
        Me.grpStatus.Location = New System.Drawing.Point(12, 131)
        Me.grpStatus.Name = "grpStatus"
        Me.grpStatus.Size = New System.Drawing.Size(554, 71)
        Me.grpStatus.TabIndex = 16
        Me.grpStatus.TabStop = False
        Me.grpStatus.Text = "Status"
        '
        'lblStatusMsg2
        '
        Me.lblStatusMsg2.Location = New System.Drawing.Point(32, 42)
        Me.lblStatusMsg2.Name = "lblStatusMsg2"
        Me.lblStatusMsg2.Size = New System.Drawing.Size(448, 26)
        Me.lblStatusMsg2.TabIndex = 1
        '
        'lblStatusMsg1
        '
        Me.lblStatusMsg1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusMsg1.Location = New System.Drawing.Point(19, 19)
        Me.lblStatusMsg1.Name = "lblStatusMsg1"
        Me.lblStatusMsg1.Size = New System.Drawing.Size(394, 21)
        Me.lblStatusMsg1.TabIndex = 0
        Me.lblStatusMsg1.Text = "   "
        '
        'txtErrors
        '
        Me.txtErrors.Location = New System.Drawing.Point(12, 226)
        Me.txtErrors.Multiline = True
        Me.txtErrors.Name = "txtErrors"
        Me.txtErrors.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtErrors.Size = New System.Drawing.Size(554, 144)
        Me.txtErrors.TabIndex = 17
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Label3.Location = New System.Drawing.Point(12, 210)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Errors:"
        '
        'chkLogSQL
        '
        Me.chkLogSQL.AutoSize = True
        Me.chkLogSQL.Location = New System.Drawing.Point(283, 109)
        Me.chkLogSQL.Name = "chkLogSQL"
        Me.chkLogSQL.Size = New System.Drawing.Size(68, 17)
        Me.chkLogSQL.TabIndex = 19
        Me.chkLogSQL.Text = "Log SQL"
        Me.chkLogSQL.UseVisualStyleBackColor = True
        '
        'lblTimeout
        '
        Me.lblTimeout.AutoSize = True
        Me.lblTimeout.Location = New System.Drawing.Point(357, 109)
        Me.lblTimeout.Name = "lblTimeout"
        Me.lblTimeout.Size = New System.Drawing.Size(139, 13)
        Me.lblTimeout.TabIndex = 20
        Me.lblTimeout.Text = "Connection Timeout (Sec) : "
        '
        'txtTimeOut
        '
        Me.txtTimeOut.Location = New System.Drawing.Point(491, 105)
        Me.txtTimeOut.Name = "txtTimeOut"
        Me.txtTimeOut.Size = New System.Drawing.Size(28, 20)
        Me.txtTimeOut.TabIndex = 21
        Me.txtTimeOut.Text = "30"
        '
        'frmUpsizer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(580, 381)
        Me.Controls.Add(Me.txtTimeOut)
        Me.Controls.Add(Me.lblTimeout)
        Me.Controls.Add(Me.chkLogSQL)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtErrors)
        Me.Controls.Add(Me.chkDrpObsolete)
        Me.Controls.Add(Me.chkImpDri)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtPassWord)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtUserName)
        Me.Controls.Add(Me.btnUpsize)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtERDFile)
        Me.Controls.Add(Me.txtDatabase)
        Me.Controls.Add(Me.txtServer)
        Me.Controls.Add(Me.grpStatus)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmUpsizer"
        Me.Text = "AnUpsizer"
        Me.grpStatus.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtServer As System.Windows.Forms.TextBox
    Friend WithEvents txtDatabase As System.Windows.Forms.TextBox
    Friend WithEvents txtERDFile As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnUpsize As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtUserName As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtPassWord As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
    Friend WithEvents chkImpDri As System.Windows.Forms.CheckBox
    Friend WithEvents chkDrpObsolete As System.Windows.Forms.CheckBox
    Friend WithEvents grpStatus As System.Windows.Forms.GroupBox
    Friend WithEvents txtErrors As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblStatusMsg1 As System.Windows.Forms.Label
    Friend WithEvents lblStatusMsg2 As System.Windows.Forms.Label
    Friend WithEvents chkLogSQL As System.Windows.Forms.CheckBox
    Friend WithEvents lblTimeout As System.Windows.Forms.Label
    Friend WithEvents txtTimeOut As System.Windows.Forms.TextBox

End Class
