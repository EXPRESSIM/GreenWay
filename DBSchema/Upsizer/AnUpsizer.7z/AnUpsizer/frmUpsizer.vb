
Imports AnUpsizerLib
Imports ACS
Imports AnUpsizerLib.AnEnums


Public Class frmUpsizer

    Dim moFileDialogBox As OpenFileDialog
    Dim moUpsizer As AnUpsizerLib.claUpsizer
    Dim moUpsizerTest As AnUpsizerLib.claUpsizerTest
    Dim WithEvents moClientMsgSender As ClientMsgSender
    Dim msLogPath$
    Dim moErrorCol As AnUpsizerErrCol
    Dim mblnLogToDB As Boolean

    Private Sub btnUpsize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpsize.Click

        Me.txtErrors.Text = ""
        Me.txtErrors.Refresh()

        If Me.chkDrpObsolete.Checked Then
            If MsgBox("Are you sure you want to drop obsolete data?", MsgBoxStyle.YesNo, "AnUpsizer") = MsgBoxResult.No Then
                Exit Sub
            End If
        Else
            If MsgBox("Upsize now?", MsgBoxStyle.YesNo, "AnUpsizer") = MsgBoxResult.No Then
                Exit Sub
            End If
        End If

        'Dim obConnection As ACS.DataAccess.claConnection = Nothing

        'Save the Form values
        My.Settings.Default.Server = Me.txtServer.Text
        My.Settings.Default.Password = Me.txtPassWord.Text
        My.Settings.Default.Username = Me.txtUserName.Text
        My.Settings.Default.ERDPath = Me.txtERDFile.Text
        My.Settings.Default.Database = Me.txtDatabase.Text
        My.Settings.Default.Save()

        Dim Thread1 As New System.Threading.Thread(AddressOf DoUpsize)
        Thread1.Start()

    End Sub

    'Clean up Stuff
    Private Sub DoCleanUp()
        'Need to do this in order to re-run it
        moUpsizer.Dispose()
        moUpsizer = Nothing
        Me.lblStatusMsg1.Text = "Done"
        Me.lblStatusMsg2.Text = ""

    End Sub

    'Event Handler to update status msg from AnUpsizer.dll
    Public Sub UpdateStatus(ByVal Msg$, ByVal Level As claUpsizer.StatusMsgLevel) Handles moClientMsgSender.evSendStatusMsg

        If Level = claUpsizer.StatusMsgLevel.Level_1 Then
            Me.lblStatusMsg1.Text = Msg
            Me.lblStatusMsg1.Refresh()
        Else
            Me.lblStatusMsg2.Text = Msg
            Me.lblStatusMsg2.Refresh()
        End If
    End Sub

    'Event Handler to update Error Msgs from AnUpsizer.dll
    Public Sub UpdateErrorText(ByVal Msg$) Handles moClientMsgSender.evSendErrorText
        Me.txtErrors.AppendText(Msg & vbCrLf & vbCrLf)
        Me.txtErrors.SelectionStart = Me.txtErrors.Text.Length
        Me.txtErrors.ScrollToCaret()
        Me.txtErrors.Refresh()
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        moFileDialogBox = New OpenFileDialog
        moFileDialogBox.Filter = "XML|*.xml"

        If moFileDialogBox.ShowDialog() = Windows.Forms.DialogResult.OK Then
            'Set the ERD path
            Me.txtERDFile.Text = moFileDialogBox.FileName
        End If
    End Sub

    Private Sub frmUpsizer_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Turn off cross-thread control access errors in IDE
        For Each ctrl As Control In Me.Controls
            ctrl.CheckForIllegalCrossThreadCalls = False
        Next

        'Set default values
        Me.txtERDFile.Text = My.Settings.Default.ERDPath
        Me.txtPassWord.Text = My.Settings.Default.Password
        Me.txtUserName.Text = My.Settings.Default.Username
        Me.txtServer.Text = My.Settings.Default.Server
        Me.txtDatabase.Text = My.Settings.Default.Database
        Me.chkImpDri.Checked = True
        moClientMsgSender = New ClientMsgSender
        msLogPath = My.Application.Info.DirectoryPath & "\Logs"

        'Check to see if connection info to the ActiveNetSites databases exists and if so log to the db
        Try
            If Not ACS.DataAccess.claConnectInfo.Configuration Is Nothing Then
                mblnLogToDB = True
            End If
        Catch ex As Exception
            'Do nothing db logging configuration does not exist
        End Try

    End Sub

    Private Sub TestUpsizer()

        If Not Me.txtERDFile.Text.ToUpper.Contains("\UPSIZERTEST.XML") Then
            MsgBox("Select UpsizerTest.xml for the ERD")
            Return
        End If

        moUpsizerTest = New claUpsizerTest(Me.txtServer.Text, _
            Me.txtUserName.Text, Me.txtPassWord.Text, Me.txtERDFile.Text, moClientMsgSender, _
            Me.chkLogSQL.Checked, msLogPath, False)

        moUpsizerTest.Dotest()

    End Sub

    Private Sub DoUpsize()

        SetFormElementEnabled(False)

        Dim obConnection As ACS.DataAccess.claConnection = Nothing

        If Me.txtDatabase.Text.ToUpper.Contains("UPSIZERTEST") Then
            Try
                TestUpsizer()
                moUpsizerTest = Nothing
                Me.lblStatusMsg1.Text = "Done"
                Me.lblStatusMsg2.Text = ""
            Catch ex As Exception
                Me.txtErrors.Text = ex.ToString
            End Try

        Else
            Try
                'This is a normal Upsize
                'Create DB Connection
                obConnection = DataAccess.claConnectionFactory.CreateSqlConnection(Me.txtServer.Text, _
                     Me.txtDatabase.Text, Me.txtUserName.Text, Me.txtPassWord.Text, False)
                
                'Create the upsizer Object
                moUpsizer = New AnUpsizerLib.claUpsizer(obConnection, Me.txtERDFile.Text, Me.chkImpDri.Checked, _
                Me.chkDrpObsolete.Checked, False, moClientMsgSender, Me.chkLogSQL.Checked, msLogPath, mblnLogToDB, GetCommandTimeOut())

                'do the Upsizing
                moErrorCol = moUpsizer.Upsize()

                For Each sError As AnUpsizerError In moErrorCol
                    'Only show non fatal errors because fatal ones will already be there
                    If Not sError.Fatal Then
                        Me.txtErrors.AppendText(vbCrLf & sError.Value & vbCrLf)
                    End If
                Next


                If moErrorCol.Count > 0 Then
                    MsgBox("Errors occurred")
                Else
                    MsgBox("Done")
                End If

            Catch ex As Exception
                Me.txtErrors.Text = ex.ToString
            Finally
                DoCleanUp()
            End Try
        End If

        SetFormElementEnabled(True)
    End Sub

    'AN-23948 get command time out value. if we set the value as 0, the default value (30s) will be used.
    Private Function GetCommandTimeOut() As Integer
        Dim iTimeOut As Integer = 0

        If IsNumeric(txtTimeOut.Text) Then
            iTimeOut = CInt(txtTimeOut.Text)
        End If

        If iTimeOut < 0 Then iTimeOut = 0

        Return iTimeOut
    End Function

    ' Disable input controls during upsizing
    Private Sub SetFormElementEnabled(ByVal Enable As Boolean)
        Me.txtERDFile.ReadOnly = Not Enable
        Me.btnBrowse.Enabled = Enable
        Me.btnUpsize.Enabled = Enable
        Me.txtServer.ReadOnly = Not Enable
        Me.txtDatabase.ReadOnly = Not Enable
        Me.txtUserName.ReadOnly = Not Enable
        Me.txtPassWord.ReadOnly = Not Enable
        Me.chkImpDri.Enabled = Enable
        Me.chkDrpObsolete.Enabled = Enable
        Me.chkLogSQL.Enabled = Enable
        Me.lblTimeout.Enabled = Enable 'AN-23948
        Me.txtTimeOut.Enabled = Enable 'AN-23948
    End Sub

End Class
