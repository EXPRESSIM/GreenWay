Imports AnUpsizerLib.AnEnums

Public Class DDManager
    Implements IDisposable

#Region " Declarations "

    'Table collection
    Dim mdicTables As Generic.Dictionary(Of String, DDTable)
    'View collection
    Dim mdicViews As Generic.Dictionary(Of String, DDView)
    'Stored Procedure collection
    Dim mdicProcedures As Generic.Dictionary(Of String, DDProcedure)
    'Function collection
    Dim mdicFunctions As Generic.Dictionary(Of String, DDFunction)
    'Indexes collection
    Dim mdicIndexes As Generic.Dictionary(Of String, DDIndex)
    'Holds all columns in the entire database for all tables
    Dim moDataBaseColumns As DataTable
    'Holds DataBase_Attributes (Schema Level and possibly DB Level)
    Dim mdicAttributes As Generic.Dictionary(Of String, String)
    'In some circumstances the DataBase_Attributes table does not exist
    'Like for a Upsizertest or a fresh new DB
    Dim mbAttributesExist As Boolean
    'DBConnection
    Dim moDDDbconn As DDDbConn
    'The parent claUpsizer object
    Dim moUpsizer As claUpsizer
    Dim mstSchemaLevel$
    Dim mstXmlFile$
    Protected disposed As Boolean = False


#End Region

#Region " Constructors "

    'Populate itself via DB connection
    Friend Sub New(ByVal obDDDbConn As DDDbConn, ByVal obclaUpsizerLib As claUpsizer)
        moDDDbconn = obDDDbConn
        moUpsizer = obclaUpsizerLib

        'Get all columns in entire DB
        moDataBaseColumns = Me.DDDBConn.DbConnection.GetSchema(SQLConnMetaDataCollectionNames.Columns.ToString)

        ' Enumerate through all tables in DB
        Dim oTableCollection As DataTable = moDDDbconn.DbConnection.GetSchema(SQLConnMetaDataCollectionNames.Tables.ToString)
        For Each oTableRow As DataRow In oTableCollection.Rows
            Dim stTableName$ = oTableRow("Table_Name").ToString.ToUpper
            Dim stTableType$ = oTableRow("Table_Type").ToString

            If stTableType = "Base Table" AndAlso _
                stTableName <> "dtproperties" Then
                Me.Tables.Add(stTableName, New DDTable(Me, stTableName.ToUpper))
            End If
        Next

        ' Read schema of Database_attributes table
        ReadAttributes()

        Dim oRs As ACS.DataAccess.claRecordSet = Nothing
        Try
            'Add views, stored procedures and functions
            Dim sRestrictions(2) As String
            sRestrictions(1) = "dbo"
            Dim oViewCollection As DataTable = moDDDbconn.DbConnection.GetSchema(SQLConnMetaDataCollectionNames.Views.ToString, sRestrictions)
            For Each oTableRow As DataRow In oViewCollection.Rows
                Dim stViewName$ = oTableRow("Table_Name").ToString.ToUpper
                'Need to check if this is a system view
                If Not moDDDbconn.bQuery(oRs, "select OBJECTPROPERTY( OBJECT_ID( '" & stViewName & "' ), 'IsMSShipped' )", "") Then
                    Throw New Exception("Could not check to see if view " & stViewName & " is system view")
                End If
                If oRs.Read Then
                    'If we can get the object property and it is 0 then it is not a system view so add it
                    If oRs.GetInteger(0) = 0 Then
                        Me.Views.Add(stViewName, New DDView(Me, stViewName.ToUpper))
                    End If
                End If
                If Not oRs Is Nothing Then oRs.Dispose()
            Next
        Finally
            If Not oRs Is Nothing Then oRs.Dispose()
        End Try

        Try
            Dim sRestrictions(2) As String
            sRestrictions(1) = "dbo"
            Dim oProceduresCollection As DataTable = moDDDbconn.DbConnection.GetSchema(SQLConnMetaDataCollectionNames.Procedures.ToString, sRestrictions)
            For Each oTableRow As DataRow In oProceduresCollection.Rows
                Dim stProcedureName$ = oTableRow("Specific_Name").ToString.ToUpper
                Dim stProcedureType As String = oTableRow("Routine_Type").ToString.ToUpper
                'Need to check if this is a system sp or function
                If Not moDDDbconn.bQuery(oRs, "select OBJECTPROPERTY( OBJECT_ID( '" & stProcedureName & "' ), 'IsMSShipped' )", "") Then
                    Throw New Exception("Could not check to see if stored procedure" & stProcedureName & " is system stored procedure")
                End If
                If oRs.Read Then
                    'If we can get the object property and it is 0 then it is not a system sp or function so add it
                    If oRs.GetInteger(0) = 0 Then
                        If stProcedureType.ToUpper = "PROCEDURE" Then
                            Me.Procedures.Add(stProcedureName, New DDProcedure(Me, stProcedureName.ToUpper))
                        ElseIf stProcedureType.ToUpper = "FUNCTION" Then
                            Me.Functions.Add(stProcedureName, New DDFunction(Me, stProcedureName.ToUpper))
                        End If
                    End If
                End If
                If Not oRs Is Nothing Then oRs.Dispose()
            Next
        Finally
            If Not oRs Is Nothing Then oRs.Dispose()
        End Try

    End Sub

    'Reads XML Schema to populate itself
    Friend Sub New(ByVal xmlFile As String, ByVal obclaUpsizerLib As claUpsizer)
        moUpsizer = obclaUpsizerLib
        mstXmlFile = xmlFile

        ' Enumerate through tables
        Dim DomDoctor As New XMLDomDoctor(xmlFile, Me.UpsizerLibParent)
        DomDoctor.GetNode("Tables")
        Dim bNodeFound As Boolean = DomDoctor.GetFirstNode("Table")
        While bNodeFound
            Dim oDDTable As DDTable = New DDTable(Me, DomDoctor)
            Me.Tables.Add(oDDTable.TableName, oDDTable)
            bNodeFound = DomDoctor.GetNextNode("Table")
        End While
        ' Read schema of Database_attributes table
        ReadAttributes()

        'Add views, stored procedures and functions
        Dim sExtraXML As String = xmlFile.Insert(xmlFile.IndexOf(".xml") + 1, "extra.")
        Try
            DomDoctor = New XMLDomDoctor(sExtraXML, Me.UpsizerLibParent)
            DomDoctor.GetNode("Views", False)
            bNodeFound = DomDoctor.GetFirstNode("View")
            While bNodeFound
                'Check for empty elements
                If DomDoctor.CurrentNode.Attributes.Count > 0 Then
                    Dim oDDView As DDView = New DDView(Me, DomDoctor)
                    Me.Views.Add(oDDView.ViewName, oDDView)
                End If
                bNodeFound = DomDoctor.GetNextNode("View")
            End While
            DomDoctor.Pop()
            DomDoctor.GetNode("Stored_Procedures", False)
            bNodeFound = DomDoctor.GetFirstNode("Stored_Procedure")
            While bNodeFound
                'Check for empty elements
                If DomDoctor.CurrentNode.Attributes.Count > 0 Then
                    Dim oDDProcedure As DDProcedure = New DDProcedure(Me, DomDoctor)
                    Me.Procedures.Add(oDDProcedure.ProcedureName, oDDProcedure)
                End If
                bNodeFound = DomDoctor.GetNextNode("Stored_Procedure")
            End While
            DomDoctor.Pop()
            DomDoctor.GetNode("User_Defined_Functions", False)
            bNodeFound = DomDoctor.GetFirstNode("User_Defined_Function")
            While bNodeFound
                'Check for empty elements
                If DomDoctor.CurrentNode.Attributes.Count > 0 Then
                    Dim oDDFunction As DDFunction = New DDFunction(Me, DomDoctor)
                    Me.Functions.Add(oDDFunction.FunctionName, oDDFunction)
                    bNodeFound = DomDoctor.GetNextNode("User_Defined_Function")
                End If
            End While
            DomDoctor.Pop()
            ' ANE-12089 add user customer's index from ActiveNetErd.extra.xml
            DomDoctor.GetNode("Indexes", False)
            bNodeFound = DomDoctor.GetFirstNode("Index")
            While bNodeFound
                'Check for empty elements
                If DomDoctor.CurrentNode.Attributes.Count > 0 Then
                    Dim oDDIndex As DDIndex = New DDIndex(DomDoctor)
                    Me.Indexes.Add(oDDIndex.IndexName.ToUpper, oDDIndex)
                End If
                bNodeFound = DomDoctor.GetNextNode("Index")
            End While
            DomDoctor.Pop()
        Catch ex As Exception
            'could not read extra xml
            UpsizerLibParent.LogUpsizeError("Error reading definitions for views, stored procedures and functions from " & sExtraXML & _
                    " or file does not exist", False)
        End Try
    End Sub

    ' Read the schema of the Database_Attributes table
    ' Populate the internal attributes collection
    Private Sub ReadAttributes()

        Dim oDDTable As DDTable = Table("DATABASE_ATTRIBUTES")
        If Not oDDTable Is Nothing Then
            mbAttributesExist = True
        Else
            'this could be the case if this is a Upsizer test or a blank DB
            mbAttributesExist = False
            Exit Sub
        End If

        For Each pDDColumn As Generic.KeyValuePair(Of String, DDColumn) In oDDTable.Columns
            Dim pcolTokens As Generic.List(Of String) = HelperFuncs.ParseToCollection(pDDColumn.Value.ColumnName, "_")
            If pcolTokens.Count <> 2 Then
                Throw New Exception("Illegal Column in Attributes")
            End If
            Attributes.Add(pcolTokens(0).ToUpper, pcolTokens(1))
        Next

    End Sub

#End Region

#Region " Properties "

    Public ReadOnly Property UpsizerLibParent() As claUpsizer
        Get
            Return moUpsizer
        End Get
    End Property

    'Does this DDManager have a Attributes table?
    Public ReadOnly Property AttributesExist() As Boolean
        Get
            Return mbAttributesExist
        End Get
    End Property

    Public ReadOnly Property SchemaLevel() As Integer
        Get
            Try
                Return CInt(Me.Attributes.Item("SCHEMALEVEL"))
            Catch ex As Exception
                Throw New Exception("Could not obtain SchemaLevel because it was not found in the collection of " & Me.Name)
            End Try
        End Get
    End Property

    Public ReadOnly Property Attributes() As Generic.Dictionary(Of String, String)
        Get
            If mdicAttributes Is Nothing Then
                mdicAttributes = New Generic.Dictionary(Of String, String)
            End If
            Return mdicAttributes
        End Get
    End Property

    Public ReadOnly Property DataBaseColumns() As DataTable
        Get
            Return moDataBaseColumns
        End Get
    End Property

    Public ReadOnly Property Table(ByVal stTableName$) As DDTable
        Get
            Try
                Return Me.Tables.Item(stTableName.ToUpper)
            Catch ex As Exception
                'Was not in collection so return nothing
                Return Nothing
            End Try
        End Get
    End Property
    Public ReadOnly Property View(ByVal stViewName$) As DDView
        Get
            Try
                Return Me.Views.Item(stViewName.ToUpper)
            Catch ex As Exception
                'Was not in collection so return nothing
                Return Nothing
            End Try
        End Get
    End Property
    Public ReadOnly Property Procedure(ByVal stProcedureName$) As DDProcedure
        Get
            Try
                Return Me.Procedures.Item(stProcedureName.ToUpper)
            Catch ex As Exception
                'Was not in collection so return nothing
                Return Nothing
            End Try
        End Get
    End Property

    Public ReadOnly Property UserDefinedFunction(ByVal stFunctionName$) As DDFunction
        Get
            Try
                Return Me.Functions.Item(stFunctionName.ToUpper)
            Catch ex As Exception
                'Was not in collection so return nothing
                Return Nothing
            End Try
        End Get
    End Property

    Public ReadOnly Property UserDefinedIndex(ByVal stIndexName$) As DDIndex
        Get
            Try
                Return Me.Indexes.Item(stIndexName.ToUpper)
            Catch ex As Exception
                'Was not in collection so return nothing
                Return Nothing
            End Try
        End Get
    End Property

    Public ReadOnly Property Tables() As Generic.Dictionary(Of String, DDTable)
        Get
            If mdicTables Is Nothing Then
                mdicTables = New Generic.Dictionary(Of String, DDTable)
            End If
            Return mdicTables
        End Get
    End Property

    Public ReadOnly Property Views() As Generic.Dictionary(Of String, DDView)
        Get
            If mdicViews Is Nothing Then
                mdicViews = New Generic.Dictionary(Of String, DDView)
            End If
            Return mdicViews
        End Get
    End Property

    Public ReadOnly Property Procedures() As Generic.Dictionary(Of String, DDProcedure)
        Get
            If mdicProcedures Is Nothing Then
                mdicProcedures = New Generic.Dictionary(Of String, DDProcedure)
            End If
            Return mdicProcedures
        End Get
    End Property

    Public ReadOnly Property Functions() As Generic.Dictionary(Of String, DDFunction)
        Get
            If mdicFunctions Is Nothing Then
                mdicFunctions = New Generic.Dictionary(Of String, DDFunction)
            End If
            Return mdicFunctions
        End Get
    End Property

    Public Property Indexes() As Generic.Dictionary(Of String, DDIndex)
        Get
            If mdicIndexes Is Nothing Then
                mdicIndexes = New Generic.Dictionary(Of String, DDIndex)
            End If
            Return mdicIndexes
        End Get

        Set(ByVal value As Generic.Dictionary(Of String, DDIndex))
            mdicIndexes = value
        End Set
    End Property

    ' Return a description of this DD
    Public ReadOnly Property Name() As String
        Get
            If Not moDDDbconn Is Nothing Then
                Return "DDManager for Target " & moDDDbconn.DbConnection.ConnectInfo.DataBase
            Else
                Return "DDManager for Source " & mstXmlFile.Substring(mstXmlFile.LastIndexOf("\") + 1)
            End If
        End Get
    End Property

    Public ReadOnly Property DDDBConn() As DDDbConn
        Get
            DDDBConn = moDDDbconn
        End Get
    End Property

#End Region

#Region " Upsize method "

    Public Function Upsize(ByVal pobDDManagerTarget As DDManager, ByVal bDropData As Boolean, _
        ByVal bImplementDRI As Boolean) As Boolean

        Dim obLocalTableTarget As DDTable


        ' Make sure we're not moving backwards in schema level 
        'but don't do this if this if Attributes do not exist
        If pobDDManagerTarget.AttributesExist Then
            If pobDDManagerTarget.SchemaLevel > Me.SchemaLevel Then
                Me.UpsizerLibParent.LogUpsizeError("Data dictionary schema level of " & Me.SchemaLevel & _
                    " is older than the database level of " & pobDDManagerTarget.SchemaLevel, True)
                Return False
            End If

            ' If schema level being changed, drop Database_Attributes table, so it will be rebuilt
            If Me.SchemaLevel <> pobDDManagerTarget.SchemaLevel Then
                pobDDManagerTarget.DropTable("Database_Attributes")
            End If
        End If

        'Drop tables if drop obsolete
        'Need to create a dropped table que to drop after I enumerate through them
        Dim DroppedTables As New Generic.Queue(Of DDTable)
        If bDropData Then
            moUpsizer.UpdateStatusMsg("Dropping obsolete tables", claUpsizer.StatusMsgLevel.Level_2)
            For Each obTableTarget As Generic.KeyValuePair(Of String, DDTable) In pobDDManagerTarget.Tables
                If Me.Table(obTableTarget.Value.TableName) Is Nothing Then
                    DroppedTables.Enqueue(obTableTarget.Value)
                End If
            Next

            If DroppedTables.Count > 0 Then
                For Each DroppedTable As DDTable In DroppedTables
                    pobDDManagerTarget.DropTable(DroppedTable.TableName)
                Next
            End If
        End If

        ' Create new DDRelations table
        moUpsizer.UpdateStatusMsg("Create new DDRelations Table", claUpsizer.StatusMsgLevel.Level_2)
        If pobDDManagerTarget.Tables.ContainsKey("DDRELATIONS") Then
            If Not pobDDManagerTarget.DDDBConn.bExecuteSql("drop table ddrelations", "Dropping table DDRelations") Then
                Throw New Exception("Could not drop DDRelations table")
            End If
        End If
        If Not pobDDManagerTarget.DDDBConn.bExecuteSql("Create table DDRELATIONS (child_table varchar(100) not null, " & _
            "fkey varchar(100) not null, parent_table varchar(100) not null, implemented smallint not null default 0, " & _
            "delete_policy smallint not null default 0, null_policy smallint not null default 0)", _
            "Creating table DDRelations") Then
            Throw New Exception("Could not create table DDRELATIONS")
        End If

        'We need to upsize or Add table if it does not exist
        For Each obTableSource As Generic.KeyValuePair(Of String, DDTable) In Me.Tables

            moUpsizer.UpdateStatusMsg("Upsizing Table " & obTableSource.Value.TableName, claUpsizer.StatusMsgLevel.Level_2)

            obLocalTableTarget = pobDDManagerTarget.Table(obTableSource.Value.TableName)
            'Upsize the table
            obTableSource.Value.Upsize(pobDDManagerTarget, obLocalTableTarget, _
                bImplementDRI, bDropData)
        Next


        ' Create the relations last, because all the tables have to exist first
        moUpsizer.UpdateStatusMsg("Creating relations for tables.", claUpsizer.StatusMsgLevel.Level_2)
        If bImplementDRI Then
            For Each obSourceTable As Generic.KeyValuePair(Of String, DDTable) In Me.Tables

                obLocalTableTarget = pobDDManagerTarget.Table(obSourceTable.Value.TableName)
                If Not obLocalTableTarget Is Nothing Then

                    For Each obDDRelation As Generic.KeyValuePair(Of String, DDRelation) In obSourceTable.Value.Relations
                        Dim oDDRelationTarget As DDRelation
                        oDDRelationTarget = obLocalTableTarget.Relation(obDDRelation.Value.FKey)
                        If oDDRelationTarget Is Nothing Then
                            obDDRelation.Value.CreateRelation(obLocalTableTarget)
                        End If
                    Next
                End If
            Next
        End If

        ' Mark those as implemented which are in DB
        moUpsizer.UpdateStatusMsg("Marking tables as implemented", claUpsizer.StatusMsgLevel.Level_2)
        For Each obTableTarget As Generic.KeyValuePair(Of String, DDTable) In pobDDManagerTarget.Tables

            For Each obRelationTarget As Generic.KeyValuePair(Of String, DDRelation) In obTableTarget.Value.Relations
                ' Unless failed to create cascade delete, in which case, we'll leave it marked unimplemented
                If Not obRelationTarget.Value.CascadeFailed Then
                    If Not pobDDManagerTarget.DDDBConn.bExecuteSql( _
                        "update ddrelations set implemented=1 where child_table=" & HelperFuncs.sQuoteValue(obTableTarget.Value.TableName) & _
                        " and fkey=" & HelperFuncs.sQuoteValue(obRelationTarget.Value.FKey), _
                        "Setting DDRelation " & obRelationTarget.Value.Name & " as implemented") _
                        Then
                        Throw New Exception("Could not Update DDRelations for ChildTable " & obTableTarget.Value.TableName)
                    End If
                End If
            Next
        Next

        'Views, stored procedures and user-defined functions
        Try
            If bDropData Then
                'Drop views
                Dim DroppedViews As New Generic.Queue(Of DDView)
                moUpsizer.UpdateStatusMsg("Dropping obsolete views", claUpsizer.StatusMsgLevel.Level_2)
                For Each obViewTarget As Generic.KeyValuePair(Of String, DDView) In pobDDManagerTarget.Views
                    If Me.View(obViewTarget.Value.ViewName) Is Nothing Then
                        DroppedViews.Enqueue(obViewTarget.Value)
                    End If
                Next

                If DroppedViews.Count > 0 Then
                    For Each DroppedView As DDView In DroppedViews
                        pobDDManagerTarget.DropView(DroppedView.ViewName)
                    Next
                End If

                'Drop stored procedures
                Dim DroppedProcedures As New Generic.Queue(Of DDProcedure)
                moUpsizer.UpdateStatusMsg("Dropping obsolete procedures", claUpsizer.StatusMsgLevel.Level_2)
                For Each obProcedureTarget As Generic.KeyValuePair(Of String, DDProcedure) In pobDDManagerTarget.Procedures
                    If Me.Procedure(obProcedureTarget.Value.ProcedureName) Is Nothing Then
                        DroppedProcedures.Enqueue(obProcedureTarget.Value)
                    End If
                Next

                If DroppedProcedures.Count > 0 Then
                    For Each DroppedProcedure As DDProcedure In DroppedProcedures
                        pobDDManagerTarget.DropProcedure(DroppedProcedure.ProcedureName)
                    Next
                End If

                'Drop user-definede functions
                Dim DroppedFunctions As New Generic.Queue(Of DDFunction)
                moUpsizer.UpdateStatusMsg("Dropping obsolete functions", claUpsizer.StatusMsgLevel.Level_2)
                For Each obFunctionTarget As Generic.KeyValuePair(Of String, DDFunction) In pobDDManagerTarget.Functions
                    If Me.UserDefinedFunction(obFunctionTarget.Value.FunctionName) Is Nothing Then
                        DroppedFunctions.Enqueue(obFunctionTarget.Value)
                    End If
                Next

                If DroppedFunctions.Count > 0 Then
                    For Each DroppedFunction As DDFunction In DroppedFunctions
                        pobDDManagerTarget.DropFunction(DroppedFunction.FunctionName)
                    Next
                End If

                ' no used code, delete it.
                'ANE-12089 Drop user-definede indexes, first get index of need delete
                'Dim DroppedIndexes As New Generic.Queue(Of DDIndex)
                'moUpsizer.UpdateStatusMsg("Dropping obsolete indexes", claUpsizer.StatusMsgLevel.Level_2)
                'For Each obIndexTarget As Generic.KeyValuePair(Of String, DDIndex) In pobDDManagerTarget.Indexes
                'If Me.UserDefinedIndex(obIndexTarget.Value.IndexName) Is Nothing Then
                'DroppedIndexes.Enqueue(obIndexTarget.Value)
                'End If
                'Next
                ' deal drop operation
                'If DroppedIndexes.Count > 0 Then
                'For Each DroppedIndex As DDIndex In DroppedIndexes
                'pobDDManagerTarget.DropIndex(DroppedIndex.IndexName)
                'Next
                'End If
            End If


            Dim obLocalViewTarget As DDView
            For Each obViewSource As Generic.KeyValuePair(Of String, DDView) In Me.Views

                moUpsizer.UpdateStatusMsg("Upsizing View " & obViewSource.Value.ViewName, claUpsizer.StatusMsgLevel.Level_2)

                obLocalViewTarget = pobDDManagerTarget.View(obViewSource.Value.ViewName)
                'Upsize the view
                obViewSource.Value.Upsize(pobDDManagerTarget, obLocalViewTarget)
            Next

            Dim obLocalProcedureTarget As DDProcedure
            For Each obProcedureSource As Generic.KeyValuePair(Of String, DDProcedure) In Me.Procedures

                moUpsizer.UpdateStatusMsg("Upsizing Stored Procedure " & obProcedureSource.Value.ProcedureName, claUpsizer.StatusMsgLevel.Level_2)

                obLocalProcedureTarget = pobDDManagerTarget.Procedure(obProcedureSource.Value.ProcedureName)
                'Upsize the stored procedure
                obProcedureSource.Value.Upsize(pobDDManagerTarget, obLocalProcedureTarget)
            Next

            Dim obLocalFunctionTarget As DDFunction
            For Each obFunctionSource As Generic.KeyValuePair(Of String, DDFunction) In Me.Functions

                moUpsizer.UpdateStatusMsg("Upsizing Function " & obFunctionSource.Value.FunctionName, claUpsizer.StatusMsgLevel.Level_2)

                obLocalFunctionTarget = pobDDManagerTarget.UserDefinedFunction(obFunctionSource.Value.FunctionName)
                'Upsize the table
                obFunctionSource.Value.Upsize(pobDDManagerTarget, obLocalFunctionTarget)
            Next
            ' ANE-12089
            Dim obLocalIndexTarget As DDIndex
            For Each obIndexSource As Generic.KeyValuePair(Of String, DDIndex) In Me.Indexes

                moUpsizer.UpdateStatusMsg("Upsizing Index " & obIndexSource.Value.IndexName, claUpsizer.StatusMsgLevel.Level_2)
                obLocalIndexTarget = pobDDManagerTarget.UserDefinedIndex(obIndexSource.Value.IndexName)
                'Upsize the index
                obIndexSource.Value.Upsize(pobDDManagerTarget, obLocalIndexTarget)
            Next
        Catch ex As Exception
            UpsizerLibParent.LogUpsizeError(ex.ToString, False)
        End Try

    End Function

    'This is used to drop a table in the target If Drop obsolete is true.  It first does DDL then updates 
    'DDManager object
    Friend Sub DropTable(ByVal stTableName$)

        'Make sure the table actually exists
        stTableName = stTableName.ToUpper
        If Me.Table(stTableName) Is Nothing Then Exit Sub

        ' Drop all relations pointing to this table
        For Each obDDTableOther As Generic.KeyValuePair(Of String, DDTable) In Me.Tables
            For Each obDDRelation As KeyValuePair(Of String, DDRelation) In obDDTableOther.Value.Relations
                If obDDRelation.Value.ParentTable = stTableName Then
                    obDDRelation.Value.DropRelation()
                End If
            Next
        Next

        ' Try to drop table
        If Not Me.DDDBConn.bExecuteSql("DROP TABLE " & stTableName, "Dropping table " & stTableName) Then
            Throw New Exception("Could not drop Table " & stTableName)
        End If

        ' Update the DD
        Me.Tables.Remove(stTableName)
    End Sub

    'This is used to drop a view in the target If Drop obsolete is true.  It first does DDL then updates 
    'DDManager object
    Friend Sub DropView(ByVal stViewName$)

        'Make sure the table actually exists
        stViewName = stViewName.ToUpper
        If Me.View(stViewName) Is Nothing Then Exit Sub

        ' Try to drop table
        If Not Me.DDDBConn.bExecuteSql("DROP VIEW " & stViewName, "Dropping view " & stViewName) Then
            Throw New Exception("Could not drop view " & stViewName)
        End If

        ' Update the DD
        Me.Views.Remove(stViewName)
    End Sub

    'This is used to drop a stored procedure in the target If Drop obsolete is true.  It first does DDL then updates 
    'DDManager object
    Friend Sub DropProcedure(ByVal stProcedureName$)

        'Make sure the table actually exists
        stProcedureName = stProcedureName.ToUpper
        If Me.Procedure(stProcedureName) Is Nothing Then Exit Sub

        ' Try to drop table
        If Not Me.DDDBConn.bExecuteSql("DROP PROCEDURE " & stProcedureName, "Dropping procedure " & stProcedureName) Then
            Throw New Exception("Could not drop procedure " & stProcedureName)
        End If

        ' Update the DD
        Me.Procedures.Remove(stProcedureName)
    End Sub

    'This is used to drop a function in the target If Drop obsolete is true.  It first does DDL then updates 
    'DDManager object
    Friend Sub DropFunction(ByVal stFunctionName$)

        'Make sure the table actually exists
        stFunctionName = stFunctionName.ToUpper
        If Me.UserDefinedFunction(stFunctionName) Is Nothing Then Exit Sub

        ' Try to drop table
        If Not Me.DDDBConn.bExecuteSql("DROP FUNCTION " & stFunctionName, "Dropping function " & stFunctionName) Then
            Throw New Exception("Could not drop function " & stFunctionName)
        End If

        ' Update the DD
        Me.Functions.Remove(stFunctionName)
    End Sub

    ' drop the index
    Friend Sub DropIndex(ByVal stIndexName$)

        stIndexName = stIndexName.ToUpper
        If Me.UserDefinedIndex(stIndexName) Is Nothing Then Exit Sub

        ' Try to drop the index
        If Not Me.DDDBConn.bExecuteSql("DROP INDEX " & stIndexName, "Dropping index " & stIndexName) Then
            Throw New Exception("Could not drop index " & stIndexName)
        End If

        ' Update the DD
        Me.Indexes.Remove(stIndexName)
    End Sub
#End Region

#Region "IDisposable Support"
    Protected Overridable Overloads Sub Dispose( _
    ByVal disposing As Boolean)
        If Not Me.disposed Then
            If disposing Then
                If mdicTables IsNot Nothing Then
                    mdicTables.Clear()
                End If
                If moDataBaseColumns IsNot Nothing Then
                    moDataBaseColumns.Dispose()
                End If
                If mdicAttributes IsNot Nothing Then
                    mdicAttributes.Clear()
                End If
                If moDDDbconn IsNot Nothing Then
                    moDDDbconn.Dispose()
                End If
            End If
        End If
        Me.disposed = True
    End Sub

    Public Overloads Sub Dispose() Implements IDisposable.Dispose
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub

    Protected Overrides Sub Finalize()
        Dispose(False)
        MyBase.Finalize()
    End Sub
#End Region

End Class
