Imports ACS.DataAccess
Imports System.Threading
Imports System.Configuration

Public Class claAppLogger
    Implements IDisposable

    Private mblnLogToDB As Boolean
    Private mobSQLLogFileWriter As IO.StreamWriter
    Private mobUpsizerLogFileWriter As IO.StreamWriter
    Private msSQLLog As String
    Private msUpsizeLog As String
    Private mbLogSQL As Boolean
    Private msCurrentServerIP As String = ""
    Protected disposed As Boolean = False

#Region "Constructors"
    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sUpsizeLog As String, ByVal sSQLLog As String, ByVal blnLogToDB As Boolean)
        'If AnUpsizerLib is being called from ActiveNetSites we need to force it to read the correct config file
        AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", "AnUpsizer.exe.config")
        mblnLogToDB = blnLogToDB
        msUpsizeLog = sUpsizeLog
        msSQLLog = sSQLLog
        Dim oHostEntry As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName)
        For Each IPAddress As System.Net.IPAddress In oHostEntry.AddressList
            msCurrentServerIP = IPAddress.ToString
        Next
    End Sub

#End Region
    Public Sub LogDebug(ByVal sMessage As String, Optional ByVal iOrgSiteID As Integer = 0)

        If Not mblnLogToDB Then
            WriteToUpsizerLogFile(sMessage)
            Exit Sub
        End If
        'If log is saved to db do not save to file, only display it
        If Not LogToDB(iOrgSiteID, Date.UtcNow, msCurrentServerIP, _
                   AnEnums.enmAppLogMessageType.Debug, sMessage, "", 0, "") Then
            WriteToUpsizerLogFile(sMessage)
        End If

    End Sub
    'Need to pass in LogEntry to this so we can use log levels to display messages on form
    Public Sub LogInfo(ByVal sMessage As String, Optional ByVal iOrgSiteID As Integer = 0)
        If Not mblnLogToDB Then
            WriteToUpsizerLogFile(sMessage)
            Exit Sub
        End If
        'If log is saved to db do not save to file, only display it
        If Not LogToDB(iOrgSiteID, Date.UtcNow, msCurrentServerIP, _
                   AnEnums.enmAppLogMessageType.Info, sMessage, "", 0, "") Then
            WriteToUpsizerLogFile(sMessage)
        End If

    End Sub

    Public Sub LogWarning(ByVal sMessage As String, Optional ByVal iOrgSiteID As Integer = 0)
        If Not mblnLogToDB Then
            WriteToUpsizerLogFile(sMessage)
            Exit Sub
        End If
        'If log is saved to db do not save to file, only display it
        If Not LogToDB(iOrgSiteID, Date.UtcNow, msCurrentServerIP, _
                   AnEnums.enmAppLogMessageType.Warning, sMessage, "", 0, "") Then
            WriteToUpsizerLogFile(sMessage)
        End If
    End Sub

    Public Sub LogNonFatalError(ByVal sMessage As String, ByVal sCallStack As String, Optional ByVal iOrgSiteID As Integer = 0)
        If Not mblnLogToDB Then
            WriteToUpsizerLogFile(sMessage)
            Exit Sub
        End If
        'If log is saved to db do not save to file, only display it
        If Not LogToDB(iOrgSiteID, Date.UtcNow, msCurrentServerIP, _
                   AnEnums.enmAppLogMessageType.NonFatalError, sMessage, sCallStack, 0, "") Then
            WriteToUpsizerLogFile(sMessage)
        End If
    End Sub

    Public Sub LogFatalError(ByVal sMessage As String, ByVal sCallStack As String, Optional ByVal iOrgSiteID As Integer = 0)
        If Not mblnLogToDB Then
            WriteToUpsizerLogFile(sMessage)
            Exit Sub
        End If
        'If log is saved to db do not save to file, only display it
        If Not LogToDB(iOrgSiteID, Date.UtcNow, msCurrentServerIP, _
                   AnEnums.enmAppLogMessageType.FatalError, sMessage, sCallStack, 0, "") Then
            WriteToUpsizerLogFile(sMessage)
        End If
    End Sub

    Public Sub LogSQLError(ByVal sMessage As String, ByVal sCallStack As String, ByVal iSqlErrCode As Integer, ByVal sSQlCommand As String, _
                        Optional ByVal iOrgSiteID As Integer = 0)
        If Not mblnLogToDB Then
            WriteToUpsizerLogFile(sMessage & " " & CStr(iSqlErrCode) & " " & sSQlCommand)
            WriteToSQLLogFile(sMessage & " " & CStr(iSqlErrCode) & " " & sSQlCommand)
            Exit Sub
        End If
        'If log is saved to db do not save to file, only display it
        If Not LogToDB(iOrgSiteID, Date.UtcNow, msCurrentServerIP, _
                   AnEnums.enmAppLogMessageType.SQLError, sMessage, sCallStack, iSqlErrCode, sSQlCommand) Then
            WriteToUpsizerLogFile(sMessage & " " & CStr(iSqlErrCode) & " " & sSQlCommand)
            WriteToSQLLogFile(sMessage & " " & CStr(iSqlErrCode) & " " & sSQlCommand)
        End If
    End Sub

    Public Sub LogSQLCall(ByVal sSQlCommand As String, Optional ByVal iOrgSiteID As Integer = 0)

        If Not mblnLogToDB Then
            WriteToSQLLogFile(sSQlCommand)
            Exit Sub
        End If
        'If log is saved to db do not save to file, only display it
        If Not LogToDB(iOrgSiteID, Date.UtcNow, msCurrentServerIP, _
                   AnEnums.enmAppLogMessageType.SQLCall, "", "", 0, sSQlCommand) Then
            WriteToSQLLogFile(sSQlCommand)
        End If

    End Sub


    'Create a new application_log entry in the unified log
    Private Function LogToDB(ByVal iOrgSiteID As Integer, _
                                ByVal datEventTimeUTC As Date, _
                                ByVal sIPAddress As String, _
                                ByVal iMessageType As Integer, _
                                ByVal sMessage As String, _
                                ByVal sCallStack As String, _
                                ByVal iSqlErrorCode As Integer, _
                                ByVal sSqlStatement As String) As Boolean


        Try
            'Remove quotes otherwise insert will fail
            sMessage = sMessage.Replace("'", "")
            sMessage = sMessage.Replace(Chr(34), "")
            sCallStack = sCallStack.Replace("'", "")
            sCallStack = sCallStack.Replace(Chr(34), "")
            sSqlStatement = sSqlStatement.Replace("'", "")
            sSqlStatement = sSqlStatement.Replace(Chr(34), "")

            Dim sInsertValues As String
            'Only insert an org site id if there is one otherwise should be null to keep from violating foreign key constraint
            If Not iOrgSiteID > 0 Then
                sInsertValues = "'" & CStr(datEventTimeUTC) & "','" & _
                    sIPAddress & "','" & My.Application.Info.AssemblyName & "','" & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & _
                     "." & My.Application.Info.Version.Revision & "'," & CStr(iMessageType) & ",'" & sMessage & _
                    "','','" & sCallStack & "'," & CStr(iSqlErrorCode) & ",'" & sSqlStatement & "'," & CStr(Thread.CurrentThread.ManagedThreadId)
            Else
                sInsertValues = CStr(iOrgSiteID) & ",'" & CStr(datEventTimeUTC) & "','" & _
                    sIPAddress & "','" & My.Application.Info.AssemblyName & "','" & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & _
                    "." & My.Application.Info.Version.Revision & "'," & CStr(iMessageType) & ",'" & sMessage & _
                    "','','" & sCallStack & "'," & CStr(iSqlErrorCode) & ",'" & sSqlStatement & "'," & CStr(Thread.CurrentThread.ManagedThreadId)

            End If

            If Not InsertAppLogRecord(sInsertValues, iOrgSiteID) Then
                WriteToUpsizerLogFile("Failed to insert record into application log")
                Exit Function
            End If
            LogToDB = True
        Catch ex As Exception
            WriteToUpsizerLogFile(ex.Message & vbCrLf & ex.StackTrace)
        End Try

    End Function



    Private Function InsertAppLogRecord(ByVal sValues As String, ByVal iOrgSiteID As Integer) As Boolean
        Try
            Dim NewID As Integer
            Dim sColumns As String
            If Not iOrgSiteID > 0 Then
                sColumns = "event_time_utc,ip_address,source_application,source_version,message_type,message," & _
                    "exception_class,call_stack,sql_error_code,sql_statement_stack,thread_id"
            Else
                sColumns = "org_site_id,event_time_utc,ip_address,source_application,source_version,message_type,message," & _
                    "exception_class,call_stack,sql_error_code,sql_statement_stack,thread_id"
            End If


            Dim RecordInsert As New ACS.DataAccess.claRecordInsert("application_log", "application_log_id", _
                sColumns, sValues)
            Dim oCommand As ACS.DataAccess.claCommand = DirectCast(RecordInsert.CreateCommand(), ACS.DataAccess.claCommand)
            oCommand.ExecuteNonQuery()

            NewID = Integer.Parse(DirectCast(oCommand.Parameters.Item("@id"), System.Data.IDataParameter).Value.ToString)

            If NewID > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            WriteToUpsizerLogFile(ex.Message & vbCrLf & ex.StackTrace)
            mblnLogToDB = False
        End Try

        Return True

    End Function

    Public Sub WriteToUpsizerLogFile(ByVal Msg$)
        UpsizerLogFileWriter.WriteLine(Msg & vbCrLf)
        UpsizerLogFileWriter.Flush()
    End Sub

    Public Sub WriteToSQLLogFile(ByVal SQL$)
        SQLLogFileWriter.WriteLine(vbCrLf & SQL)
        SQLLogFileWriter.Flush()
    End Sub

    Private ReadOnly Property SQLLogFileWriter() As IO.StreamWriter
        Get
            If mobSQLLogFileWriter Is Nothing Then
                'mobSQLLogFileWriter = New IO.StreamWriter(LogPath & "\AnUpsizer_SQL_" & Now.ToString("u").Replace(":", "_") & ".txt", False)
                'We need to create the Logs folder otherwise we get an error
                If Not System.IO.Directory.Exists(msSQLLog.Substring(0, msSQLLog.LastIndexOf("\"))) Then
                    System.IO.Directory.CreateDirectory(msSQLLog.Substring(0, msSQLLog.LastIndexOf("\")))
                End If
                mobSQLLogFileWriter = New IO.StreamWriter(msSQLLog, False)
                Return mobSQLLogFileWriter
            Else
                Return mobSQLLogFileWriter
            End If
        End Get
    End Property

    Private ReadOnly Property UpsizerLogFileWriter() As IO.StreamWriter
        Get
            If mobUpsizerLogFileWriter Is Nothing Then
                'mobUpsizerLogFileWriter = New IO.StreamWriter(LogPath & "\AnUpsizer_Log_" & Now.ToString("u").Replace(":", "_") & ".txt", False)
                'We need to create the Logs folder otherwise we get an error
                If Not System.IO.Directory.Exists(msUpsizeLog.Substring(0, msUpsizeLog.LastIndexOf("\"))) Then
                    System.IO.Directory.CreateDirectory(msUpsizeLog.Substring(0, msUpsizeLog.LastIndexOf("\")))
                End If
                mobUpsizerLogFileWriter = New IO.StreamWriter(msUpsizeLog, False)
                Return mobUpsizerLogFileWriter
            Else
                Return mobUpsizerLogFileWriter
            End If
        End Get
    End Property
#Region "IDisposable Support"
    'Clean up code for COM. When Upsize is called from VB6 the memory it acquires is
    'is not released. Garbage collection has to be specifically initiated

    Protected Overridable Overloads Sub Dispose( _
    ByVal disposing As Boolean)
        If Not Me.disposed Then
            If disposing Then
                If mobSQLLogFileWriter IsNot Nothing Then
                    mobSQLLogFileWriter.Close()
                    mobSQLLogFileWriter.Dispose()
                End If
                If mobUpsizerLogFileWriter IsNot Nothing Then
                    UpsizerLogFileWriter.Close()
                    UpsizerLogFileWriter.Dispose()
                End If
            End If
        End If
        Me.disposed = True
    End Sub
    'Call this before destroying the AnUpsizerLib object in VB6 code
    Public Overloads Sub Dispose() Implements IDisposable.Dispose
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub

    Protected Overrides Sub Finalize()
        Dispose(False)
        MyBase.Finalize()
    End Sub
#End Region
End Class
