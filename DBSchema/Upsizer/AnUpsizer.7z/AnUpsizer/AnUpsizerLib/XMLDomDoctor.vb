Option Explicit On
Option Strict On

Imports System.xml
Imports AnUpsizerLib.AnEnums
Imports System.Data.SqlDbType

Public Class XMLDomDoctor
    Dim mXmlDoc As XmlDocument
    Dim mCurNode As XmlNode
    Dim mobclaUpsizerLib As claUpsizer

    Public Sub New(ByVal sDocName As String, ByVal obclaUpsizerLib As claUpsizer)
        mobclaUpsizerLib = obclaUpsizerLib
        mXmlDoc = New XmlDocument
        mXmlDoc.Load(sDocName)
        mCurNode = mXmlDoc.FirstChild
    End Sub

    ' Position on the first child node with a given name
    ' If successful, returns true and is positioned on child node
    ' If no matched child nodes, returns false and positioning is unchanged
    Public Function GetFirstNode(ByVal NodeName$) As Boolean

        ' Look for a child with this name
        For Each oNode As XmlNode In mCurNode.ChildNodes
            If oNode.Name = NodeName Then
                mCurNode = oNode
                Return True
            End If
        Next
    End Function

    ' Position on the next childnode with a given name.
    ' Assumes we're already positioned on a child node, so uses nextSibling to walk
    ' If it finds a node, returns true and is positioned on that node
    ' If no node is found, returns false and pops the tree
    Public Function GetNextNode(ByVal vstrName$) As Boolean

        Dim pNode As Xml.XmlNode

        ' Look for a sibling with this name
        pNode = mCurNode.NextSibling
        While Not pNode Is Nothing

            ' Found, position there and return true
            If pNode.Name = vstrName Then
                mCurNode = pNode
                Return True
            End If

            pNode = pNode.nextSibling
        End While

        ' Nothing found, so pop the stack
        pNode = mCurNode.parentNode
        If pNode Is Nothing Then
            Throw New Exception("Attempt to use GetNextNode on top level node")
        End If

        mCurNode = pNode
        Return False

    End Function

    Public Function GetNode(ByVal stNodeName As String, Optional ByVal bRequired As Boolean = True) As Boolean

        Dim FirstChildNode As XmlNode

        If mCurNode Is Nothing Then
            If bRequired Then
                Throw New Exception("Current node is invalid")
            Else
                Return False
            End If
        End If

        FirstChildNode = mCurNode.FirstChild
        'We may already be on it
        If FirstChildNode.Name = stNodeName Then
            mCurNode = FirstChildNode
            Return True
        End If

        Do While FirstChildNode IsNot Nothing
            If FirstChildNode.Name = stNodeName Then
                mCurNode = FirstChildNode
                Return True
            End If
            'go to next sibling
            FirstChildNode = FirstChildNode.NextSibling
        Loop

        If bRequired Then
            Throw New Exception("Unable to find requested node: " & stNodeName)
        Else
            Return False
        End If

    End Function

    Public Function GetSimpleNodeText(ByVal sNodeName As String, Optional ByVal bRequired As Boolean = True) As String
        Dim Node As XmlNode

        If mCurNode Is Nothing Then
            If bRequired Then
                Throw New Exception("Current node is invalid")
            Else
                Return ""
            End If
        End If

        ' Look for a child node with the right name
        Node = mCurNode.FirstChild
        While Not Node Is Nothing
            If Node.Name = sNodeName Then
                Return Node.InnerText
            End If
            Node = Node.NextSibling
        End While

        If bRequired Then
            Throw New Exception("Unable to find requested node: " & sNodeName)
        Else
            Return ""
        End If
    End Function

    Public Sub Pop(Optional ByVal iLevels As Integer = 1)
        Dim Node As XmlNode

        While iLevels > 0
            Node = mCurNode.ParentNode
            If Node Is Nothing Then
                Throw New Exception("Unable to Pop")
            End If

            ' Pop
            mCurNode = Node
            iLevels = iLevels - 1
        End While
    End Sub

    ' Get an attribute value of the current node
    Public Function GetAttribute(ByVal vstrName$, _
            Optional ByVal vblnRequired As Boolean = True) As String
        Dim pNode As XmlNode

        ' Look for a child node with the right name
        For Each pNode In mCurNode.Attributes
            If pNode.Name = vstrName Then

                ' Return the value of that node
                Return GetNodeValue(pNode, En_DataType.enmStringDT)
            End If
        Next

        ' Generate error if not found
        If vblnRequired Then
            mobclaUpsizerLib.LogUpsizeError("Attribute " & vstrName & " not found", False)
        End If

        Return ""

    End Function

    ' Return the .Text property of a node, doing data conversion if necessary
    Private Function GetNodeValue(ByVal vNode As XmlNode, _
            ByVal venmdatatype As En_DataType) As String

        Dim pstrValue$


        If vNode Is Nothing Then
            mobclaUpsizerLib.LogUpsizeError("Attempt to get value of non-existent node", False)
        End If

        ' Only strings are supported now
        pstrValue = vNode.Value
        Select Case venmdatatype
            Case En_DataType.enmStringDT
                GetNodeValue = pstrValue
            Case Else
                mobclaUpsizerLib.LogUpsizeError("Invalid data type = " & venmdatatype, False)
                Return ""
        End Select

    End Function

    Public ReadOnly Property CurrentNode() As XmlNode
        Get
            Return mCurNode
        End Get
    End Property
End Class
