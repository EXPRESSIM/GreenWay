<ComClass(ClientMsgSender.ClassId, ClientMsgSender.InterfaceId, ClientMsgSender.EventsId)> _
Public Class ClientMsgSender

#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "8e54b212-7920-4065-9938-d97c54bc8015"
    Public Const InterfaceId As String = "6819865d-ebc6-4b8a-b86e-f453b39bb040"
    Public Const EventsId As String = "40a48393-97d4-4e57-af2b-d91a872f0de6"
#End Region

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub

    Public Event evSendStatusMsg(ByVal Msg$, ByVal Level As claUpsizer.StatusMsgLevel)
    Public Event evSendErrorText(ByVal Msg$)

    'Send Error to caller by raising event
    Public Sub SendErrorMsg(ByVal ErrorDesc$)
        RaiseEvent evSendErrorText(ErrorDesc)
    End Sub

    'Sends Status Msg to caller by raising event
    Friend Sub SendStatusMsg(ByVal StatusMsg$, ByVal Level As claUpsizer.StatusMsgLevel)
        RaiseEvent evSendStatusMsg(StatusMsg, Level)
    End Sub

End Class


