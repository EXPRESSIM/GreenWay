Imports AnUpsizerLib.AnEnums
Imports System.Data.SqlDbType

<ComClass(claUpsizer.ClassId, claUpsizer.InterfaceId, claUpsizer.EventsId)> _
Public Class claUpsizer
    Implements IDisposable


#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "1970468b-42c2-4864-8373-418623ab65e1"
    Public Const InterfaceId As String = "76bca4a8-dd18-4ee0-ae88-11ecc0d7759f"
    Public Const EventsId As String = "83b6c20a-cbe7-4761-930d-22cc8de8a545"
#End Region

#Region " Declarations "

    'Instance Variables
    Dim mstLogPath$
    'Dim mobSQLLogFileWriter As IO.StreamWriter
    'Dim mobUpsizerLogFileWriter As IO.StreamWriter
    Dim mobDDDbConn As DDDbConn
    Dim mstErdPath$
    Dim mobTargetDDManager As DDManager
    Dim mobSourceDDManager As DDManager
    Dim mbCompare As Boolean
    Dim mbDropObsData As Boolean
    Dim mbImpDri As Boolean
    Dim mobClientMsgSender As ClientMsgSender
    Dim mbLogSQL As Boolean
    Dim mLogFileInited As Boolean
    Dim mobErrorCol As AnUpsizerErrCol
    Dim miInternetSystemUserId As Integer = -1
    Dim miInternetSiteID As Integer = -1
    Dim miInternetProfileID As Integer = -1
    Dim miInternetWorkstationID As Integer = -1
    Dim miDropInCustomerID As Integer = -1
    Dim miOrgSiteID As Integer = 0
    Dim msFixPrefix As String = "    Fix_"
    Dim msIndent As String = "        "
    Protected disposed As Boolean = False
    Private moAppLogger As claAppLogger

    Public Enum StatusMsgLevel
        Level_1 = 0
        Level_2 = 1
    End Enum

#End Region

#Region " Constructors "

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub

    'Constructor FOR .net Upizer Form
    Public Sub New(ByVal obConnection As ACS.DataAccess.claConnection, _
        ByVal stErdPath$, _
        ByVal ImpDRI As Boolean, _
        ByVal DropObsData As Boolean, _
        ByVal CompareOnly As Boolean, _
        ByVal obClientMsgSender As ClientMsgSender, _
        ByVal LogSQL As Boolean, _
        ByVal LogPath$, _
        ByVal blnLogToDB As Boolean, _
        Optional ByVal iTimeout As Integer = 0, _
        Optional ByVal iOrgSiteID As Integer = 0)

        mobClientMsgSender = obClientMsgSender
        ' Up timeout to 10 minutes
        obConnection.CommandTimeout = iTimeout
        mobDDDbConn = New DDDbConn(obConnection, Me, LogSQL)
        mstErdPath = stErdPath
        mbImpDri = ImpDRI
        mbCompare = CompareOnly
        mbDropObsData = DropObsData
        mbLogSQL = LogSQL
        mstLogPath = LogPath
        mobErrorCol = New AnUpsizerErrCol
        moAppLogger = New claAppLogger(LogPath & "\AnUpsizer_Log_" & Me.mobDDDbConn.DbConnection.ConnectInfo.DataBase & ".txt", _
                            LogPath & "\AnUpsizer_SQL_" & Me.mobDDDbConn.DbConnection.ConnectInfo.DataBase & ".txt", blnLogToDB)
        miOrgSiteID = iOrgSiteID
    End Sub

    'Constructor FOR Messi=aging only.  This is only used by UpsizerTest
    Public Sub New(ByVal obClientMsgSender As ClientMsgSender, ByVal LogSQL As Boolean)
        mobClientMsgSender = obClientMsgSender
        mbLogSQL = LogSQL
        mobErrorCol = New AnUpsizerErrCol
    End Sub

    ' Init Code FOR COM (This is kind of like a constructor)
    Public Sub Init(ByVal stErdPath$, _
        ByVal ImpDRI As Boolean, _
        ByVal DropObsData As Boolean, _
        ByVal CompareOnly As Boolean, _
        ByVal Server$, _
        ByVal DataBase$, _
        ByVal User$, _
        ByVal Password$, _
        ByVal obClientMsgSender As ClientMsgSender, _
        ByVal LogSQL As Boolean, _
        ByVal LogPath$, _
        ByVal blnLogToDB As Boolean, _
        Optional ByVal iTimeout As Integer = 0, _
        Optional ByVal iOrgSiteID As Integer = 0)

        'Create DB Connection
        Dim obConnection As ACS.DataAccess.claConnection = ACS.DataAccess.claConnectionFactory.CreateSqlConnection(Server, _
             DataBase, User, Password, False)
        ' Up timeout to 10 minutes
        obConnection.CommandTimeout = iTimeout
        mobClientMsgSender = obClientMsgSender
        mobDDDbConn = New DDDbConn(obConnection, Me, LogSQL)
        mstErdPath = stErdPath
        mbImpDri = ImpDRI
        mbCompare = CompareOnly
        mbDropObsData = DropObsData
        mbLogSQL = LogSQL
        mstLogPath = LogPath
        mobErrorCol = New AnUpsizerErrCol
        moAppLogger = New claAppLogger(LogPath & "\AnUpsizer_Log_" & Me.mobDDDbConn.DbConnection.ConnectInfo.DataBase & ".txt", _
                    LogPath & "\AnUpsizer_SQL_" & Me.mobDDDbConn.DbConnection.ConnectInfo.DataBase & ".txt", blnLogToDB)
        miOrgSiteID = iOrgSiteID
    End Sub

#End Region

#Region " Upsize "

    'This is the top level driver for the Upsize process and it returns a collection of errors
    Public Function Upsize() As AnUpsizerErrCol

        Try
            UpdateStatusMsg("Loading Data Dictionaries", StatusMsgLevel.Level_1)

            UpdateStatusMsg("Loading DDManager Source", StatusMsgLevel.Level_2)
            mobSourceDDManager = New DDManager(mstErdPath, Me)
            UpdateStatusMsg("Loading DDManager Target", StatusMsgLevel.Level_2)
            mobTargetDDManager = New DDManager(mobDDDbConn, Me)
            mobTargetDDManager.Indexes = mobSourceDDManager.Indexes

            'Do some pre-custom Updates.  For now there are none but this is just a shell
            'For future updates.  also there is no need to even try it if there are no
            'Attributes on the target DDmanager
            If mobTargetDDManager.AttributesExist Then

                'Based off of the DBLevel you can do pre-custom updates
                PreCustomUpdates()
            End If

            UpdateStatusMsg("Checking database compatibility mode", StatusMsgLevel.Level_1)
            CheckAndChangeCompatibilityMode() 'ANE-3613

            UpdateStatusMsg("Upsizing", StatusMsgLevel.Level_1)
            'Let's do the upsizing
            mobSourceDDManager.Upsize(mobTargetDDManager, mbDropObsData, mbImpDri)

            'stored procedure and function scripts are now stored in an external file
            'Now add the Stored Procedures and user functions
            'CreateStoredProcedures()
            'CreateUserFunctions()

        Catch ex As Exception
            Me.LogUpsizeError(ex.ToString, True, ex.StackTrace)
            Throw ex
        Finally
            ' Close resources
            If mobDDDbConn IsNot Nothing Then
                'need this as calling dispose twice causes error
                If Not mobDDDbConn.ConnectionDisposed Then
                    mobDDDbConn.DbConnection.Dispose()
                    mobDDDbConn.ConnectionDisposed = True
                End If
            End If

            'If UpsizerLogFileWriter IsNot Nothing Then
            '    UpsizerLogFileWriter.Dispose()
            ''    You have to do this to allow you to re-run upsize without
            '    closing(form)
            '    mobUpsizerLogFileWriter = Nothing
            'End If
            'If SQLLogFileWriter IsNot Nothing Then
            '    SQLLogFileWriter.Dispose()
            '    mobSQLLogFileWriter = Nothing
            'End If
        End Try

        Return mobErrorCol
    End Function

#End Region

#Region " Logging "

    'Write Error to UpsizerLog and Send Error to client if fatal
    'Public Sub LogUpsizeError(ByVal ErrorDesc$, ByVal Fatal As Boolean)
    '    mobErrorCol.Add(New AnUpsizerError(ErrorDesc, Fatal))
    '    WriteToUpsizerLog("***ERROR in AnUpsizer *** " & vbCrLf & ErrorDesc)
    '    'Only send fatal errors to caller
    '    If Fatal Then mobClientMsgSender.SendErrorMsg("(Fatal Error) " & ErrorDesc)
    'End Sub

    Public Sub LogUpsizeError(ByVal ErrorDesc$, ByVal Fatal As Boolean, Optional ByVal sCallStack As String = "")
        mobErrorCol.Add(New AnUpsizerError(ErrorDesc, Fatal))
        If Fatal Then
            'Only send fatal errors to caller
            moAppLogger.LogFatalError("***ERROR in AnUpsizer *** " & vbCrLf & ErrorDesc, sCallStack, miOrgSiteID)
            mobClientMsgSender.SendErrorMsg("(Fatal Error) " & ErrorDesc)
        Else
            moAppLogger.LogNonFatalError("***ERROR in AnUpsizer *** " & vbCrLf & ErrorDesc, sCallStack, miOrgSiteID)
        End If
    End Sub

    'Send Status msg to client and log it
    Friend Sub UpdateStatusMsg(ByVal StatusMsg$, ByVal Level As claUpsizer.StatusMsgLevel)
        WriteToUpsizerLog(StatusMsg)
        mobClientMsgSender.SendStatusMsg(StatusMsg, Level)
    End Sub


    Private ReadOnly Property LogPath() As String
        Get
            If mLogFileInited Then
                Return mstLogPath
            End If

            If mstLogPath Is Nothing Then
                'Ths caller must not have provided me witht a path
                'or there was some kind of exception which prevented claUpsizer to
                'get created in the first place
                mstLogPath = My.Application.Info.DirectoryPath & "\..\Logs"
            End If

            If Not IO.Directory.Exists(mstLogPath) Then
                IO.Directory.CreateDirectory(mstLogPath)
            End If

            mLogFileInited = True
            Return mstLogPath

        End Get
    End Property

    Public Sub WriteToUpsizerLog(ByVal Msg$)
        'UpsizerLogFileWriter.WriteLine(Msg & vbCrLf)
        'UpsizerLogFileWriter.Flush()
        moAppLogger.LogInfo(Msg, miOrgSiteID)
    End Sub

    Public Sub WriteToSQLLog(ByVal SQL$)
        'SQLLogFileWriter.WriteLine(vbCrLf & SQL)
        'SQLLogFileWriter.Flush()
        moAppLogger.LogSQLCall(SQL, miOrgSiteID)
    End Sub

    'Private ReadOnly Property SQLLogFileWriter() As IO.StreamWriter
    '    Get

    '        'No sense in going through initing the SQLLogWriter if we are not logging any SQL
    '        If Not mbLogSQL Then
    '            Return Nothing
    '        End If

    '        If mobSQLLogFileWriter Is Nothing Then
    '            'mobSQLLogFileWriter = New IO.StreamWriter(LogPath & "\AnUpsizer_SQL_" & Now.ToString("u").Replace(":", "_") & ".txt", False)
    '            mobSQLLogFileWriter = New IO.StreamWriter(LogPath & "\AnUpsizer_SQL_" & Me.mobDDDbConn.DbConnection.ConnectInfo.DataBase & ".txt", False)
    '            Return mobSQLLogFileWriter
    '        Else
    '            Return mobSQLLogFileWriter
    '        End If
    '    End Get
    'End Property

    'Private ReadOnly Property UpsizerLogFileWriter() As IO.StreamWriter
    '    Get
    '        If mobUpsizerLogFileWriter Is Nothing Then
    '            'mobUpsizerLogFileWriter = New IO.StreamWriter(LogPath & "\AnUpsizer_Log_" & Now.ToString("u").Replace(":", "_") & ".txt", False)
    '            mobUpsizerLogFileWriter = New IO.StreamWriter(LogPath & "\AnUpsizer_Log_" & Me.mobDDDbConn.DbConnection.ConnectInfo.DataBase & ".txt", False)

    '            Return mobUpsizerLogFileWriter
    '        Else
    '            Return mobUpsizerLogFileWriter
    '        End If
    '    End Get
    'End Property

#End Region
    'Stored procedure and function scripts are now stored externally in an extr.xml file
    '#Region " Create stored procedures "

    '    Private Sub CreateStoredProcedures()
    '        Dim oSb As Text.StringBuilder

    '        UpdateStatusMsg("Writing stored procedures", StatusMsgLevel.Level_2)

    '        ' Attempt to create REC_INSERT
    '        oSb = New Text.StringBuilder
    '        oSb.AppendLine("@tab ntext, @pkeycol ntext, @cols ntext, @vals ntext, @id int output AS ")
    '        oSb.AppendLine("execute ('insert into ' + @tab + ' (' + @cols + ') values (' + @vals + ')')")
    '        oSb.AppendLine("if (@@error<>0) ")
    '        oSb.AppendLine("  set @id=0")
    '        oSb.AppendLine("else")
    '        oSb.AppendLine("  set @id=@@identity")
    '        CreateStoredProcedure(oSb.ToString, "REC_INSERT", True)

    '        ' Attempt to create REC_INSERTX
    '        oSb = New Text.StringBuilder
    '        oSb.AppendLine("@tab ntext, @pkeycol ntext, @cols ntext, @vals ntext, @id int output, @origid ntext  AS ")
    '        oSb.AppendLine("execute ('insert into ' + @tab + ' (' + @cols + ') values (' + @vals + ')')")
    '        oSb.AppendLine("set @id=0")
    '        oSb.AppendLine("if (@@error=0) ")
    '        oSb.AppendLine("  begin")
    '        oSb.AppendLine("    declare @sid char(10)")
    '        oSb.AppendLine("    set @sid=convert(char(10),@@identity)")
    '        oSb.AppendLine("    execute ('update ' + @tab + ' set ' + @origid + '=' + @sid + ' where ' + @pkeycol + '=' + @sid)")
    '        oSb.AppendLine("    if (@@error=0) ")
    '        oSb.AppendLine("      set @id=@@identity")
    '        oSb.AppendLine("  end")
    '        CreateStoredProcedure(oSb.ToString, "REC_INSERTX", True)

    '        ' attempt to create REC_FACROLLUP
    '        oSb = New Text.StringBuilder
    '        oSb.AppendLine("AS")
    '        oSb.AppendLine("-- Wrap this all in a transaction, so no one will see results until done")
    '        oSb.AppendLine("Begin TRAN")
    '        oSb.AppendLine("-- Delete all existing records")
    '        oSb.AppendLine("delete from facilityoverlaprollup")
    '        oSb.AppendLine("-- First create any 'identity' rollups")
    '        oSb.AppendLine("Insert into facilityoverlaprollup (realfacility_id, overlapfacility_id, direction)")
    '        oSb.AppendLine("  select facility_id, facility_id, 'U' from facilities f")
    '        oSb.AppendLine("  where not exists (select * from facilityoverlaprollup r2")
    '        oSb.AppendLine("    where r2.realfacility_id=f.facility_id and r2.overlapfacility_id=f.facility_id)")
    '        oSb.AppendLine("-- Add parents iteratively, until no more get added")
    '        oSb.AppendLine("While 0 = 0 ")
    '        oSb.AppendLine("Begin")
    '        oSb.AppendLine("  insert into facilityoverlaprollup (realfacility_id, overlapfacility_id, direction)")
    '        oSb.AppendLine("    select r.realfacility_id, o.facility_id, 'U'")
    '        oSb.AppendLine("    from facilityoverlaps o, facilityoverlaprollup r")
    '        oSb.AppendLine("    Where r.overlapfacility_id = o.childfacility_id")
    '        oSb.AppendLine("      and not exists (select * from facilityoverlaprollup r2")
    '        oSb.AppendLine("        Where r2.realfacility_id = r.realfacility_id")
    '        oSb.AppendLine("          and r2.overlapfacility_id=o.facility_id)")
    '        oSb.AppendLine("  -- If no records added, we're done with this part")
    '        oSb.AppendLine("  if @@rowcount=0")
    '        oSb.AppendLine("    break")
    '        oSb.AppendLine("End")
    '        oSb.AppendLine("-- Delete duplicates")
    '        oSb.AppendLine("delete from facilityoverlaprollup where exists")
    '        oSb.AppendLine("  (select * from facilityoverlaprollup r2 where ")
    '        oSb.AppendLine("     r2.facilityoverlaprollup_id>facilityoverlaprollup.facilityoverlaprollup_id")
    '        oSb.AppendLine("     and r2.realfacility_id=facilityoverlaprollup.realfacility_id")
    '        oSb.AppendLine("     and r2.overlapfacility_id=facilityoverlaprollup.overlapfacility_id)")
    '        oSb.AppendLine("-- Add 'D' records")
    '        oSb.AppendLine("insert into facilityoverlaprollup (realfacility_id, overlapfacility_id, direction)")
    '        oSb.AppendLine("  select overlapfacility_id, realfacility_id, 'D' from facilityoverlaprollup r1")
    '        oSb.AppendLine("  where r1.realfacility_id<>r1.overlapfacility_id and r1.direction='U'")
    '        oSb.AppendLine("    and not exists (select * from facilityoverlaprollup r2")
    '        oSb.AppendLine("      where r1.overlapfacility_id=r2.realfacility_id and r1.realfacility_id=r2.overlapfacility_id)")
    '        oSb.AppendLine("-- Commit transaction")
    '        oSb.AppendLine("COMMIT TRAN")
    '        CreateStoredProcedure(oSb.ToString, "Rec_FacRollup", True)

    '        ' Create prorate_convenience_fees SP
    '        oSb = New Text.StringBuilder
    '        oSb.AppendLine("AS")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("-- get some FK values we'll need later")
    '        oSb.AppendLine("declare @glcash int, @glabsorb int, @glcust int, @glar int")
    '        oSb.AppendLine("select @glcash = cashglaccount_id from system")
    '        oSb.AppendLine("select @glabsorb = absorbglaccount_id from system")
    '        oSb.AppendLine("select @glcust = customerglaccount_id from system")
    '        oSb.AppendLine("select @glar = arglaccount_id from system")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("-- update all gl_ledger records for which the transaction has no absorbed convenience fee gl_ledgers")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("update gl_ledger set adjusted_amount=amount where not exists ")
    '        oSb.AppendLine("  (select * from receiptdetails rd1")
    '        oSb.AppendLine("     join transactions tr on rd1.transaction_id=tr.transaction_id")
    '        oSb.AppendLine("     join receiptdetails rd2 on rd2.transaction_id=tr.transaction_id")
    '        oSb.AppendLine("     join gl_ledger gl2 on gl2.receiptdetail_id=rd2.receiptdetail_id")
    '        oSb.AppendLine("   where gl_ledger.receiptdetail_id=rd1.receiptdetail_id ")
    '        oSb.AppendLine("     and gl2.glaccount_id=@glabsorb)")
    '        oSb.AppendLine("if @@error<>0 return")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("-- find the next transaction we still need to fixup")
    '        oSb.AppendLine("declare @tid int, @tidprev int")
    '        oSb.AppendLine("set @tidprev=0")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("while 0=0 begin")
    '        oSb.AppendLine("  select @tid = isnull(min(transaction_id),0) from transactions tr where")
    '        oSb.AppendLine("    -- it's past the last one")
    '        oSb.AppendLine("    transaction_id>@tidprev")
    '        oSb.AppendLine("    -- there is some gl_ledger record with a non-zero amount")
    '        oSb.AppendLine("    and exists (select * from gl_ledger gl ")
    '        oSb.AppendLine("      join receiptdetails rd on gl.receiptdetail_id=rd.receiptdetail_id")
    '        oSb.AppendLine("      where rd.transaction_id=tr.transaction_id and gl.amount<>0)")
    '        oSb.AppendLine("    -- but no gl_ledger records have a non-zero adjusted_amount")
    '        oSb.AppendLine("    and not exists (select * from gl_ledger gl ")
    '        oSb.AppendLine("      join receiptdetails rd on gl.receiptdetail_id=rd.receiptdetail_id")
    '        oSb.AppendLine("      where rd.transaction_id=tr.transaction_id and gl.adjusted_amount<>0)")
    '        oSb.AppendLine("  if @@error<>0 return")
    '        oSb.AppendLine("  set @tidprev=@tid")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- if nothing more to fix up, we're done")
    '        oSb.AppendLine("  print 'TID=' + convert(char, @tid)")
    '        oSb.AppendLine("  if @tid=0 return")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- find out how much absorbed fee there is to distribute for this transaction")
    '        oSb.AppendLine("  declare @absorb money, @absorbleft money")
    '        oSb.AppendLine("  select @absorb = isnull(sum(gl.amount),0) from gl_ledger gl")
    '        oSb.AppendLine("    join receiptdetails rd on gl.receiptdetail_id=rd.receiptdetail_id")
    '        oSb.AppendLine("    where rd.transaction_id=@tid and gl.glaccount_id=@glabsorb")
    '        oSb.AppendLine("  if @@error<>0 return")
    '        oSb.AppendLine("  set @absorbleft = @absorb")
    '        oSb.AppendLine("  print '  Absorb=' + ltrim(convert (char, @absorb))")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- if none, just transfer amount to adjusted_amount")
    '        oSb.AppendLine("  -- (Shouldn't actually be the case, since we should have gotten this case at the top)")
    '        oSb.AppendLine("  if @absorb=0 begin")
    '        oSb.AppendLine("    update gl_ledger ")
    '        oSb.AppendLine("      set adjusted_amount=gl_ledger.amount")
    '        oSb.AppendLine("      from receiptdetails rd")
    '        oSb.AppendLine("      where gl_ledger.receiptdetail_id=rd.receiptdetail_id and rd.transaction_id=@tid")
    '        oSb.AppendLine("    if @@error<>0 return")
    '        oSb.AppendLine("    print '  *** wierdness but continue'")
    '        oSb.AppendLine("    continue")
    '        oSb.AppendLine("  end")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- remaining code assumes absorb amount is positive")
    '        oSb.AppendLine("  if @absorb<0 begin")
    '        oSb.AppendLine("    raiserror ('Absorb amount is negative on TID=%d',16,1,@tid)")
    '        oSb.AppendLine("    return")
    '        oSb.AppendLine("  end")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- find out how much the fees total for this transaction (less system accounts)")
    '        oSb.AppendLine("  declare @fees money")
    '        oSb.AppendLine("  select @fees = isnull(sum(gl.amount),0) from gl_ledger gl")
    '        oSb.AppendLine("    join receiptdetails rd on gl.receiptdetail_id=rd.receiptdetail_id")
    '        oSb.AppendLine("    where rd.transaction_id=@tid ")
    '        oSb.AppendLine("      and gl.glaccount_id<>@glabsorb and gl.glaccount_id<>@glcash and gl.glaccount_id<>@glcust and gl.glaccount_id<>@glar")
    '        oSb.AppendLine("      and gl.tax1=0 and gl.tax2=0 and gl.tax3=0 and gl.tax4=0")
    '        oSb.AppendLine("      -- exclude discounts, since they make it harder to prorate")
    '        oSb.AppendLine("      and gl.amount<0")
    '        oSb.AppendLine("      -- include only fees paid partially by customer account, since we'll adjust those ")
    '        oSb.AppendLine("      and exists (select * from gl_ledger gl2 ")
    '        oSb.AppendLine("        where gl2.receiptdetail_id=rd.receiptdetail_id and gl2.glaccount_id=@glcust) ")
    '        oSb.AppendLine("  if @@error<>0 return")
    '        oSb.AppendLine("  print '  Fees=' + ltrim(convert(char, @fees))")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- find out customer account balance for this transaction, so we can test that it")
    '        oSb.AppendLine("  -- is the same afterwards")
    '        oSb.AppendLine("  declare @custbal money")
    '        oSb.AppendLine("  select @custbal = isnull(sum(gl.amount),0) from gl_ledger gl")
    '        oSb.AppendLine("    join receiptdetails rd on gl.receiptdetail_id=rd.receiptdetail_id")
    '        oSb.AppendLine("    where rd.transaction_id=@tid ")
    '        oSb.AppendLine("      and gl.glaccount_id=@glcust")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- all the work on a given 'transaction' is in a 'transaction'")
    '        oSb.AppendLine("  begin transaction")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("/*")
    '        oSb.AppendLine("  There are five types of GL ledger records for these transactions")
    '        oSb.AppendLine("    * Cash account, reflecting actual cash paid -- these will not be changed")
    '        oSb.AppendLine("    * Customer account, which can be either as a result of internal discount handling, ")
    '        oSb.AppendLine("      or payment from account")
    '        oSb.AppendLine("    * Absorbed convenience fee account, which we're going to distribute across the fees accounts")
    '        oSb.AppendLine("    * Fees accounts, defined as anything except the above three accounts")
    '        oSb.AppendLine("    * Tax records")
    '        oSb.AppendLine("  This loop will go through all RDs with actual fees, which should be all except the ")
    '        oSb.AppendLine("  convenience fee RD, and for each")
    '        oSb.AppendLine("    * Determines how much of the absorbed convenience fee to prorate")
    '        oSb.AppendLine("    * Computes adjusted_amount for fee and customer account GLs in that RD by adjusting by that amount")
    '        oSb.AppendLine("    * Copies cash and tax amounts over without change")
    '        oSb.AppendLine("  This should leave the convenience fee RD unprocessed, therefore with adjusted_amount=0 for both GLs")
    '        oSb.AppendLine("*/  ")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- find a gl_ledger for this transaction which needs to be fixed")
    '        oSb.AppendLine("  declare @glidprev int, @glid int, @glamount money, @rdid int")
    '        oSb.AppendLine("  set @glidprev=0")
    '        oSb.AppendLine("  while 0=0 begin")
    '        oSb.AppendLine("    select @glid = isnull(min(gl.gl_ledger_id), 0) from gl_ledger gl")
    '        oSb.AppendLine("      join receiptdetails rd on gl.receiptdetail_id=rd.receiptdetail_id")
    '        oSb.AppendLine("      where rd.transaction_id=@tid")
    '        oSb.AppendLine("        -- and is a 'fee' acount, meaning not a system account and not a tax entry")
    '        oSb.AppendLine("        and gl.glaccount_id<>@glcash and gl.glaccount_id<>@glcust and gl.glaccount_id<>@glabsorb and gl.glaccount_id<>@glar")
    '        oSb.AppendLine("        and tax1=0 and tax2=0 and tax3=0 and tax4=0")
    '        oSb.AppendLine("        -- and it hasn't been messed with yet")
    '        oSb.AppendLine("        and gl.adjusted_amount=0 and gl.amount<>0")
    '        oSb.AppendLine("        -- and it's past the last one we worked on")
    '        oSb.AppendLine("        and gl_ledger_id>@glidprev")
    '        oSb.AppendLine("    if @@error<>0 begin")
    '        oSb.AppendLine("      rollback transaction")
    '        oSb.AppendLine("      return")
    '        oSb.AppendLine("    end")
    '        oSb.AppendLine("    print '  GLID=' + ltrim(convert(char, @glid))")
    '        oSb.AppendLine("    set @glidprev = @glid")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("    -- If none, move one to next transaction")
    '        oSb.AppendLine("    if @glid=0 ")
    '        oSb.AppendLine("      break")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("    -- Get more data from that GL")
    '        oSb.AppendLine("    select @glamount=amount, @rdid=receiptdetail_id from gl_ledger  ")
    '        oSb.AppendLine("      where gl_ledger_id=@glid")
    '        oSb.AppendLine("    if @@rowcount<>1 begin")
    '        oSb.AppendLine("      raiserror ('Wrong number of GLs for GLID=%d', 16, 1, @glid)")
    '        oSb.AppendLine("      rollback transaction")
    '        oSb.AppendLine("      return")
    '        oSb.AppendLine("    end")
    '        oSb.AppendLine("    if @@error<>0 begin")
    '        oSb.AppendLine("      rollback transaction")
    '        oSb.AppendLine("      return")
    '        oSb.AppendLine("    end")
    '        oSb.AppendLine("    print '    Amount=' + ltrim(convert(char, @glamount))")
    '        oSb.AppendLine("    print '    RDID=' + ltrim(convert(char, @rdid))")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("    -- Find out if this GL has customer account charge")
    '        oSb.AppendLine("    declare @glidcustcount int")
    '        oSb.AppendLine("    select @glidcustcount = count(*) from gl_ledger gl")
    '        oSb.AppendLine("      where gl.receiptdetail_id=@rdid and gl.glaccount_id=@glcust")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("    -- if there is exactly one customer account payment on this RD, consider adjusting")
    '        oSb.AppendLine("    if @glidcustcount=1 begin")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("      -- get the customer account record")
    '        oSb.AppendLine("      declare @glidcust int")
    '        oSb.AppendLine("      select @glidcust = gl_ledger_id from gl_ledger gl")
    '        oSb.AppendLine("        where gl.receiptdetail_id=@rdid and gl.glaccount_id=@glcust")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("      -- Compute adjusted fee amount: Prorate and round up, so we don't have pennies left at the end")
    '        oSb.AppendLine("      declare @feeadjust money")
    '        oSb.AppendLine("      if @glamount<0 ")
    '        oSb.AppendLine("        set @feeadjust = ceiling(@glamount * @absorb * 100 /@fees) / 100")
    '        oSb.AppendLine("      -- Don't adjust discounts")
    '        oSb.AppendLine("      else")
    '        oSb.AppendLine("        set @feeadjust=0")
    '        oSb.AppendLine("      -- But make sure we don't overshoot")
    '        oSb.AppendLine("      if @feeadjust>@absorbleft ")
    '        oSb.AppendLine("        set @feeadjust=@absorbleft")
    '        oSb.AppendLine("      print '    FeeAdjust=' + ltrim(convert(char, @feeadjust))")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("      -- Fix this gl_ledger")
    '        oSb.AppendLine("      update gl_ledger set adjusted_amount = amount + @feeadjust where gl_ledger_id=@glid")
    '        oSb.AppendLine("      if @@rowcount<>1 begin")
    '        oSb.AppendLine("        raiserror ('Wrong number of rows (%d) fixed for RID=%d',16,1,@@rowcount,@rdid)")
    '        oSb.AppendLine("        rollback transaction")
    '        oSb.AppendLine("        return")
    '        oSb.AppendLine("      end")
    '        oSb.AppendLine("      if @@error<>0 begin")
    '        oSb.AppendLine("        rollback transaction")
    '        oSb.AppendLine("        return")
    '        oSb.AppendLine("      end")
    '        oSb.AppendLine("      set @absorbleft = @absorbleft-@feeadjust")
    '        oSb.AppendLine("      print '    AbsorbLeft=' + ltrim(convert(char, @absorbleft))")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("      -- Adjust the customer account GL record for this RD")
    '        oSb.AppendLine("      update gl_ledger set adjusted_amount = amount - @feeadjust ")
    '        oSb.AppendLine("        where receiptdetail_id=@rdid and glaccount_id=@glcust")
    '        oSb.AppendLine("      if @@rowcount<>1 begin")
    '        oSb.AppendLine("        -- If there isn't a customer account record, create one, using the fee one as a model")
    '        oSb.AppendLine("        Print '      Inserting customer account record'")
    '        oSb.AppendLine("        insert into gl_ledger ")
    '        oSb.AppendLine("          (receiptdetail_id, artransaction_id, glaccount_id, site_id, station_id, systemuser_id,")
    '        oSb.AppendLine("          fiscalperiod_id, amount, datestamp, hardentry, rciaactivationdate, voided, voidedby, voidedon, ")
    '        oSb.AppendLine("          tax1, tax2, tax3, tax4, rciaposteddate, expensedetail_id, adjusted_amount)")
    '        oSb.AppendLine("        (select ")
    '        oSb.AppendLine("          receiptdetail_id, artransaction_id, @glcust, site_id, station_id, systemuser_id,")
    '        oSb.AppendLine("          fiscalperiod_id, 0, datestamp, hardentry, rciaactivationdate, voided, voidedby, voidedon, ")
    '        oSb.AppendLine("          tax1, tax2, tax3, tax4, rciaposteddate, expensedetail_id, -1*@feeadjust ")
    '        oSb.AppendLine("        from gl_ledger where gl_ledger_id=@glid)")
    '        oSb.AppendLine("      end")
    '        oSb.AppendLine("      if @@error<>0 begin")
    '        oSb.AppendLine("        rollback transaction")
    '        oSb.AppendLine("        return")
    '        oSb.AppendLine("      end")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("      -- transfer cash, A/R and tax records without change")
    '        oSb.AppendLine("      update gl_ledger set adjusted_amount=amount ")
    '        oSb.AppendLine("        where receiptdetail_id=@rdid and (glaccount_id=@glcash or glaccount_id=@glar or tax1<>0 or tax2<>0 or tax3<>0 or tax4<>0)")
    '        oSb.AppendLine("      if @@error<>0 begin")
    '        oSb.AppendLine("        rollback transaction")
    '        oSb.AppendLine("        return")
    '        oSb.AppendLine("      end")
    '        oSb.AppendLine("    end")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("    -- if no customer account record, or more than one, transfer amount to adjusted amount")
    '        oSb.AppendLine("    if @glidcustcount<>1 begin")
    '        oSb.AppendLine("      print '    No customer account'")
    '        oSb.AppendLine("      update gl_ledger set adjusted_amount=amount ")
    '        oSb.AppendLine("        where receiptdetail_id=@rdid")
    '        oSb.AppendLine("    end")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("    -- check total of adjusted_amount for RD; throw error if bad")
    '        oSb.AppendLine("    declare @check int")
    '        oSb.AppendLine("    select @check = sum(adjusted_amount)*100 from gl_ledger gl ")
    '        oSb.AppendLine("      where receiptdetail_id=@rdid")
    '        oSb.AppendLine("    if @@error<>0 begin")
    '        oSb.AppendLine("      rollback transaction")
    '        oSb.AppendLine("      return")
    '        oSb.AppendLine("    end")
    '        oSb.AppendLine("    if @check<>0 begin")
    '        oSb.AppendLine("      raiserror (' Total adjusted amount*100=%d for RID=%d', 16, 1, @check, @rdid)")
    '        oSb.AppendLine("      rollback transaction")
    '        oSb.AppendLine("      return")
    '        oSb.AppendLine("    end")
    '        oSb.AppendLine("    print '    RD total checked'")
    '        oSb.AppendLine("  end")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- if @absorbleft didn't go to zero, then don't do all this fancy adjustment")
    '        oSb.AppendLine("  -- this will happen with a convenience fee on $0 receipt")
    '        oSb.AppendLine("  if @absorbleft<>0 begin")
    '        oSb.AppendLine("    Print 'Absorbleft<>0 -- doing stupid transfer'")
    '        oSb.AppendLine("    update gl_ledger set adjusted_amount=amount where receiptdetail_id in")
    '        oSb.AppendLine("      (select receiptdetail_id from receiptdetails where transaction_id=@tid)")
    '        oSb.AppendLine("  end")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- check total of adjusted_amount for transaction; throw error if bad")
    '        oSb.AppendLine("  select @check = sum(adjusted_amount)*100 from gl_ledger gl ")
    '        oSb.AppendLine("    join receiptdetails rd on gl.receiptdetail_id=rd.receiptdetail_id")
    '        oSb.AppendLine("    where rd.transaction_id=@tid")
    '        oSb.AppendLine("  if @@error<>0 begin")
    '        oSb.AppendLine("    rollback transaction")
    '        oSb.AppendLine("    return")
    '        oSb.AppendLine("  end")
    '        oSb.AppendLine("  if @check<>0 begin")
    '        oSb.AppendLine("    raiserror (' Total adjusted amount*100=%d for TID=%d', 16, 1, @check, @tid)")
    '        oSb.AppendLine("    rollback transaction")
    '        oSb.AppendLine("    return")
    '        oSb.AppendLine("  end")
    '        oSb.AppendLine("  print '  TR total checked'")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- Check that customer balance didn't change")
    '        oSb.AppendLine("  declare @custbal2 money")
    '        oSb.AppendLine("  select @custbal2 = isnull(sum(gl.amount),0) from gl_ledger gl")
    '        oSb.AppendLine("    join receiptdetails rd on gl.receiptdetail_id=rd.receiptdetail_id")
    '        oSb.AppendLine("    where rd.transaction_id=@tid ")
    '        oSb.AppendLine("      and gl.glaccount_id=@glcust")
    '        oSb.AppendLine("  if @custbal<>@custbal2 begin")
    '        oSb.AppendLine("    raiserror (' Customer balance mismatch on TID=%d', 16, 1, @tid)")
    '        oSb.AppendLine("    rollback transaction")
    '        oSb.AppendLine("    return")
    '        oSb.AppendLine("  end")
    '        oSb.AppendLine("")
    '        oSb.AppendLine("  -- commit the work on this transaction, and move on to the next")
    '        oSb.AppendLine("  commit transaction")
    '        oSb.AppendLine("end")

    '        CreateStoredProcedure(oSb.ToString, "prorate_convenience_fees", True)
    '    End Sub

    '    ' Create or alter a stored procedure
    '    Private Sub CreateStoredProcedure(ByVal vstrSql$, ByVal vstrProcName$, ByVal bSqlServer As Boolean)
    '        Dim oRs As ACS.DataAccess.claRecordSet = Nothing
    '        Dim oSb As New Text.StringBuilder

    '        'If sp already exists drop it
    '        Try
    '            If Not mobDDDbConn.bQuery(oRs, "SELECT name FROM sysobjects where name = '" & vstrProcName & "'", "") Then
    '                Throw New Exception("Could not look up sp " & vstrProcName)
    '            End If

    '            ' If proc already exists, do an ALTER rather than CREATE
    '            If oRs.Read Then
    '                oSb.Append("alter")
    '            Else
    '                oSb.Append("create")
    '            End If

    '        Finally
    '            If oRs IsNot Nothing Then oRs.Dispose()
    '        End Try

    '        oSb.Append(" procedure ").Append(vstrProcName).Append(" ").Append(vstrSql)
    '        UpdateStatusMsg("Creating " + vstrProcName, StatusMsgLevel.Level_2)

    '        If Not mobDDDbConn.bExecuteSql(oSb.ToString, "Executing ") Then
    '            Throw New Exception("Could not execute " & vstrSql)
    '        End If
    '    End Sub

    '#End Region

    '#Region " Create user functions"

    '    Private Sub CreateUserFunctions()
    '        Dim osb As Text.StringBuilder

    '        ' Attempt to create function maximum
    '        osb = New Text.StringBuilder
    '        osb.AppendLine("(@x money, @y money) returns money as")
    '        osb.AppendLine("Begin ")
    '        osb.AppendLine("  if @x > @y ")
    '        osb.AppendLine("    return @x")
    '        osb.AppendLine("  return @y")
    '        osb.AppendLine("End")
    '        CreateUserFunction(osb.ToString, "maximum", True)

    '        ' Attempt to create function payment_plan_overdue
    '        osb = New Text.StringBuilder
    '        osb.AppendLine("(@arscheduleheader_id int, @curdate datetime) returns money as ")
    '        osb.AppendLine("Begin")
    '        osb.AppendLine("  return dbo.maximum(")
    '        osb.AppendLine("    (select isnull(sum(amount),0) from artransactions")
    '        osb.AppendLine("     where arscheduleheader_id=@arscheduleheader_id and voided=0)")
    '        osb.AppendLine("  - (select isnull(sum(amountdue),0) from arscheduledetail")
    '        osb.AppendLine("     where arscheduleheader_id=@arscheduleheader_id and datedue>@curdate and voided=0)")
    '        osb.AppendLine("  , 0)")
    '        osb.AppendLine("End")
    '        CreateUserFunction(osb.ToString, "payment_plan_overdue", True)

    '        ' Create SubSystemCode user function
    '        osb = New Text.StringBuilder
    '        osb.AppendLine("(@TransactionType INT, @OriginalTransactionType INT) RETURNS INT AS ")
    '        osb.AppendLine("Begin ")
    '        osb.AppendLine("  return case @TransactionType ")
    '        osb.AppendLine("    -- 1 = payment ")
    '        osb.AppendLine("    when 0 then 1 -- AR payment ")
    '        osb.AppendLine("    when 21 then 1 -- overpayment ")
    '        osb.AppendLine("    when 23 then 1 -- customer account debit ")
    '        osb.AppendLine("    when 24 then 1 -- customer account refund balance ")
    '        osb.AppendLine("    when 38 then 1 -- paid out expense ")
    '        osb.AppendLine("-- 2 = reg ")
    '        osb.AppendLine("    when 1 then 2 -- regular enrollment ")
    '        osb.AppendLine("    when 2 then 2 -- withdraw refund ")
    '        osb.AppendLine("    when 3 then 2 -- withdraw credit ")
    '        osb.AppendLine("    when 4 then 2 -- withdraw transfer ")
    '        osb.AppendLine("    when 5 then 2 -- transfer ")
    '        osb.AppendLine("    when 6 then 2 -- deleted due to refund ")
    '        osb.AppendLine("    when 7 then 2 -- deleted due to credit ")
    '        osb.AppendLine("    when 8 then 2 -- deleted due to transfer ")
    '        osb.AppendLine("    when 9 then 2 -- place deposit hold ")
    '        osb.AppendLine("    when 10 then 2 -- place deposit no hold ")
    '        osb.AppendLine("    when 11 then 2 -- enroll from deposit ")
    '        osb.AppendLine("    when 12 then 2 -- refunded deposit ")
    '        osb.AppendLine("    when 14 then 2 -- waitlist no hold ")
    '        osb.AppendLine("    when 15 then 2 -- enroll from waitlist ")
    '        osb.AppendLine("    when 16 then 2 -- delete from waitlist ")
    '        osb.AppendLine("    when 17 then 2 -- enroll from direct ")
    '        osb.AppendLine("    when 20 then 2 -- deleted due to enroll from deposit ")
    '        osb.AppendLine("    when 28 then 2 -- withdraw deposit ")
    '        osb.AppendLine("    when 27 then 2 -- lottery ")
    '        osb.AppendLine("-- 3 = POS ")
    '        osb.AppendLine("    when 19 then 3 -- POS sale ")
    '        osb.AppendLine("    -- 4 = Fac ")
    '        osb.AppendLine("    when 22 then 4 -- Fac res ")
    '        osb.AppendLine("    when 25 then 4 -- permit unassigned charges ")
    '        osb.AppendLine("    when 26 then 4 -- permit refund charges ")
    '        osb.AppendLine("    when 36 then 4 -- permit placeholder ")
    '        osb.AppendLine("    -- 5 = Mem ")
    '        osb.AppendLine("    when 29 then 5 -- membership sale ")
    '        osb.AppendLine("    when 30 then 5 -- membership refund ")
    '        osb.AppendLine("    when 31 then 5 -- membership transfer sale ")
    '        osb.AppendLine("    when 32 then 5 -- membership transfer refund ")
    '        osb.AppendLine("    when 33 then 5 -- membership renewal ")
    '        osb.AppendLine("-- 6 = Daycare ")
    '        osb.AppendLine("    when 35 then 6 -- daycare enroll ")
    '        osb.AppendLine("    when 39 then 6 -- daycare refund ")
    '        osb.AppendLine("    when 40 then 6 -- daycare waitlist ")
    '        osb.AppendLine("    when 41 then 6 -- daycare enroll from wait list ")
    '        osb.AppendLine("    -- 0 = doesn't count as a transaction ")
    '        osb.AppendLine("    when 18 then 0 -- voided ")
    '        osb.AppendLine("    when 34 then 0 -- proactive no hold ")
    '        osb.AppendLine("    when 37 then 0 -- locker rental ")
    '        osb.AppendLine("    when 42 then 0 -- journal entry ")
    '        osb.AppendLine("    -- For voids, look at originaltransactiontype ")
    '        osb.AppendLine("    when 18 then dbo.subsystemcode(@originaltransactiontype, @originaltransactiontype) ")
    '        osb.AppendLine("    else 0 ")
    '        osb.AppendLine("  End ")
    '        osb.AppendLine("End ")
    '        CreateUserFunction(osb.ToString, "SUBSYSTEMCODE", True)
    '    End Sub

    '    Private Sub CreateUserFunction(ByVal vstrSql$, ByVal vstrFuncName$, ByVal bSqlServer As Boolean)
    '        Dim oRs As ACS.DataAccess.claRecordSet = Nothing
    '        Dim oSb As New Text.StringBuilder

    '        'If function already exists drop it
    '        Try
    '            If Not mobDDDbConn.bQuery(oRs, "SELECT name FROM sysobjects where name = '" & vstrFuncName & "'", "") Then
    '                Throw New Exception("Could not look up sp " & vstrFuncName)
    '            End If

    '            ' If function already exists, do an ALTER rather than CREATE
    '            If oRs.Read Then
    '                oSb.Append("alter")
    '            Else
    '                oSb.Append("create")
    '            End If

    '        Finally
    '            If oRs IsNot Nothing Then oRs.Dispose()
    '        End Try

    '        UpdateStatusMsg("Creating " & vstrFuncName, StatusMsgLevel.Level_2)
    '        oSb.Append(" function ").Append(vstrFuncName).Append(" ").Append(vstrSql)
    '        If Not mobDDDbConn.bExecuteSql(oSb.ToString, "Creating function " & vstrFuncName) Then
    '            Throw New Exception("Could not create function " & vstrFuncName)
    '        End If

    '    End Sub

    '#End Region

#Region " Custom updates "

    'This is just a shell for future precustom updates
    Private Sub PreCustomUpdates()

        'Put all sorts of cool complicated pre-custom update code here

        'Temporary code to clean up site db referential integrity problems
        'FixDRI()


    End Sub
    

    'to obtain the DB Level for a DB used in conjunction with custom updates
    Private Function GetDBLevel() As Integer

        Dim oRs As ACS.DataAccess.claRecordSet = Nothing

        Try
            If Not mobDDDbConn.bQuery(oRs, _
                "Select DatabaseLevel from system", "Retrieving DBLevel from System Table") Then
                Throw New Exception("Could not get DBLevel from System Table")
            End If

            If oRs.Read Then
                Return CInt(oRs.IDataReader_Item("DatabaseLevel"))
            End If

        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try
    End Function
    Private Sub CheckAndChangeCompatibilityMode()

        If mobSourceDDManager.AttributesExist AndAlso mobSourceDDManager.SchemaLevel >= 1523 Then '1523 is the min-level for 12.1
            If mstErdPath.IndexOf("ActiveNetErd", StringComparison.CurrentCultureIgnoreCase) < 0 Then 'We currently only do the change for ActiveNet database
                Exit Sub
            End If

            Dim oRs As ACS.DataAccess.claRecordSet = Nothing
            Try
                Dim sCompatibilityMode As String = String.Empty
                Dim iMode As Integer = 0
                Dim sDataBase As String = mobDDDbConn.DbConnection.ConnectInfo.DataBase
                If Not mobDDDbConn.bQuery(oRs, String.Format("SELECT compatibility_level FROM sys.databases WHERE name = '{0}'", sDataBase), "Check existing compatibility level") Then
                    LogUpsizeError("Error occurs when getting compatibility level", False)
                End If

                If oRs.Read Then
                    sCompatibilityMode = CStr(oRs.IDataReader_Item(0))
                    oRs.Dispose()
                End If

                If Integer.TryParse(sCompatibilityMode, iMode) Then
                    If iMode < enmDatabaseCompatibilityLevel.SQLServer2008 Then
                        Dim bOk As Boolean = True

                        '1. set to single-user mode
                        bOk = mobDDDbConn.bExecuteSql(String.Format("ALTER DATABASE {0} SET SINGLE_USER WITH ROLLBACK IMMEDIATE", sDataBase), "Set the database to be single-user mode")
                        '2. change compatibility level to 100
                        If bOk Then
                            UpdateStatusMsg("Updating database compatibility level to 100...", StatusMsgLevel.Level_2)
                            bOk = mobDDDbConn.bExecuteSql(String.Format("ALTER DATABASE {0} SET COMPATIBILITY_LEVEL = {1}", sDataBase, CInt(enmDatabaseCompatibilityLevel.SQLServer2008)), "Set the compatibility level to 100")
                        End If

                        '3. change back to multiple-user mode.
                        If bOk Then
                            bOk = mobDDDbConn.bExecuteSql(String.Format("ALTER DATABASE {0} SET MULTI_USER", sDataBase), "Change the database back to multi-user mode")
                        End If

                        If Not bOk Then
                            LogUpsizeError("Error occurs when setting the database compatibility level to 100", False)
                        End If
                    End If
                Else
                    LogUpsizeError(String.Format("Invalid compatibility mode : {0}", sCompatibilityMode), False)
                End If
            Catch ex As Exception
                LogUpsizeError(ex.Message, True)
            Finally
                If oRs IsNot Nothing AndAlso Not oRs.IsClosed Then oRs.Dispose()
            End Try
        End If
    End Sub
    'For REQ 28166 - Cleanup DRI in production DBs
    Private Sub FixDRI()

        'Cannot check for unimplemented relationships first since some new ones may be
        'about to be implemented in the upsize run
        ' - also some are not supposed to implemented?  why no error msg but flag set to 0 in ddrelations?

        UpdateStatusMsg("Foreign key relationship checks for '" & mobDDDbConn.Database & "' -- " & Now(), StatusMsgLevel.Level_1)
        WriteToUpsizerLog("....check done only if relationship in DDRelations table is not flagged as implemented")
        If Not FixDRI_SetDefaultIds() Then
            WriteToUpsizerLog("Cannot continue with foreign key relationship fixes - not all default ids found")
            Return
        End If

        'One for each relationship that had an error during upsize

        'USER_ID - use internet system user id for most, delete records from a few, set to null for one
        Fix_CENTERS__SYSTEMUSER_ID("CENTERS", "SYSTEMUSER_ID")
        Fix_COMPANYCONSOLIDATIONLOG__SYSTEMUSER_ID("COMPANYCONSOLIDATIONLOG", "SYSTEMUSER_ID")
        Fix_CUSTCONSOLIDATIONEXCLUDES__EXCLUDEDBYUSER_ID("CUSTCONSOLIDATIONEXCLUDES", "EXCLUDEDBYUSER_ID")
        Fix_FACILITIES__SYSTEMUSER_ID("FACILITIES", "SYSTEMUSER_ID")
        Fix_FACILITY_SCHEDULES__HOLDUSERID("FACILITY_SCHEDULES", "HOLDUSERID")
        Fix_FACILITYUSERS__SYSTEMUSER_ID("FACILITYUSERS", "SYSTEMUSER_ID")
        Fix_FAVORITEITEMS__SYSTEMUSER_ID("FAVORITEITEMS", "SYSTEMUSER_ID")
        Fix_LOCKER_SCHEDULES__SYSTEMUSER_ID("LOCKER_SCHEDULES", "SYSTEMUSER_ID")
        Fix_MESSAGEQUEUES__SYSTEMUSER_ID("MESSAGEQUEUES", "SYSTEMUSER_ID")
        Fix_POPULATIONCONSOLIDATIONLOG__SYSTEMUSER_ID("POPULATIONCONSOLIDATIONLOG", "SYSTEMUSER_ID")
        Fix_STAGES__APPROVALSYSTEMUSER_ID("STAGES", "APPROVALSYSTEMUSER_ID")
        Fix_TRANSACTIONS__SYSTEMUSER_ID("TRANSACTIONS", "SYSTEMUSER_ID")
        Fix_TRANSACTIONSTAGES__APPROVALSYSTEMUSER_ID("TRANSACTIONSTAGES", "APPROVALSYSTEMUSER_ID")

        'STATION_ID - use workstation id from a workstation record for the internet site
        Fix_ARSCHEDULEDETAIL__STATION_ID("ARSCHEDULEDETAIL", "STATION_ID")
        Fix_ARSCHEDULEHEADER__STATION_ID("ARSCHEDULEHEADER", "STATION_ID")
        Fix_ARTRANSACTIONS__STATION_ID("ARTRANSACTIONS", "STATION_ID")
        Fix_COUPON_PENDINGADDS__WORKSTATION_ID("COUPON_PENDINGADDS", "WORKSTATION_ID")
        Fix_CUSTOMERACCOUNTS__STATION_ID("CUSTOMERACCOUNTS", "STATION_ID")
        Fix_FACILITY_SCHEDULES__STATION_ID("FACILITY_SCHEDULES", "STATION_ID")
        Fix_GL_LEDGER__STATION_ID("GL_LEDGER", "STATION_ID")
        Fix_ICVERIFYLOG__STATION_ID("ICVERIFYLOG", "STATION_ID")
        Fix_LOCKER_SCHEDULES__STATION_ID("LOCKER_SCHEDULES", "STATION_ID")
        Fix_PENDINGADDS__WORKSTATION_ID("PENDINGADDS", "WORKSTATION_ID")
        Fix_PRODUCTORDERS__STATION_ID("PRODUCTORDERS", "STATION_ID")
        Fix_RECEIPTDETAILS__STATION_ID("RECEIPTDETAILS", "STATION_ID")
        Fix_RECEIPTHEADERS__STATION_ID("RECEIPTHEADERS", "STATION_ID")
        Fix_RECEIPTPAYMENTS__STATION_ID("RECEIPTPAYMENTS", "STATION_ID")
        Fix_RSERVERLOG__WORKSTATION_ID("RSERVERLOG", "WORKSTATION_ID")
        Fix_SYSTEMUSAGELOG__WORKSTATION_ID("SYSTEMUSAGELOG", "WORKSTATION_ID")
        Fix_TEAMPENDINGADDS__WORKSTATION_ID("TEAMPENDINGADDS", "WORKSTATION_ID")
        Fix_TRANSACTIONS__STATION_ID("TRANSACTIONS", "STATION_ID")

        'SITE_ID - use internet site id from the SYSTEM table
        Fix_CENTERS__SITE_ID("CENTERS", "SITE_ID")
        Fix_INSTRUCTORTYPES__SITE_ID("INSTRUCTORTYPES", "SITE_ID")
        Fix_PENDINGCUSTOMERS__SITE_ID("PENDINGCUSTOMERS", "SITE_ID")
        Fix_TRANSACTIONS__REVENUESITE_ID("TRANSACTIONS", "REVENUESITE_ID")
        FIX_WORKSTATIONS__SITE_ID("WORKSTATIONS", "SITE_ID")

        'GLACCOUNT_ID - set to null where possible
        Fix_ACTIVITY_FEES__GLACCOUNT_ID("ACTIVITY_FEES", "GLACCOUNT_ID")
        Fix_CHARGES__GLACCOUNT_ID("CHARGES", "GLACCOUNT_ID")
        'Fix_EXPENSES__GLACCOUNT_ID("EXPENSES", "GLACCOUNT_ID")
        '       Minicourses - 1 record for id 0 
        'Fix_GL_LEDGER__GLACCOUNT_ID("GL_LEDGER", "GLACCOUNT_ID")
        '       Sunrise - 10 records for id 0 
        Fix_POSPRODUCTS__GLACCOUNT_ID("POSPRODUCTS", "GLACCOUNT_ID")
        'Fix_RECEIPTDETAILS__GLACCOUNT_ID("RECEIPTDETAILS", "GLACCOUNT_ID")
        '       40 dbs - from 1 to 306 records each - all for id 0
        Fix_RG_CATEGORY__GLACCOUNT_ID("RG_CATEGORY", "GLACCOUNT_ID")

        'CHARGE_ID
        Fix_ACTIVITY_FEES__CHARGE_ID("ACTIVITY_FEES", "CHARGE_ID") 'set to null BUT SO MANY FOR Venture db!!!
        'new relationship- Fix_CUSTOMERSCHOLARSHIP__CHARGE_ID("CUSTOMERSCHOLARSHIP","CHARGE_ID")
        '       Howell - 2 records for id 100 
        'Fix_DCPROGRAMFEES__CHARGE_ID("DCPROGRAMFEES", "CHARGE_ID")
        '       Burnaby10 - 1 record for id 10 
        'Fix_PACKAGE_FEES__CHARGE_ID("PACKAGE_FEES", "CHARGE_ID")'      
        '       Grandtraverse - 42 records total for 4 different ids
        Fix_RECEIPTDETAILS__CHARGE_ID("RECEIPTDETAILS", "CHARGE_ID")
        'Fix_STANDARDCHARGES__CHARGE_ID("STANDARDCHARGES", "CHARGE_ID")    
        '       19 dbs affected
        Fix_SYSTEM__ABSORBCHARGE_ID("SYSTEM", "ABSORBCHARGE_ID")

        'TRANSACTION_ID 
        Fix_ACTIVITYATTENDANCE__TRANSACTION_ID("ACTIVITYATTENDANCE", "TRANSACTION_ID")
        Fix_ARSCHEDULEHEADER__TRANSACTION_ID("ARSCHEDULEHEADER", "TRANSACTION_ID")
        Fix_FACILITY_SCHEDULES__TRANSACTION_ID("FACILITY_SCHEDULES", "TRANSACTION_ID")

        'COMPANY_ID - strange merge table records - same ids in mergedcompany and newcompany id columns!
        '             so the problems cannot be fixed by using companyconsolidationlog table
        '             leaving the code in here so that the upsize log shows where problems occur
        Fix_ARSCHEDULEDETAIL__COMPANY_ID("ARSCHEDULEDETAIL", "COMPANY_ID")
        Fix_ARSCHEDULEHEADER__COMPANY_ID("RSCHEDULEHEADER", "COMPANY_ID")
        Fix_ARTRANSACTIONS__COMPANY_ID("ARTRANSACTIONS", "COMPANY_ID")
        Fix_ARTRANSACTIONS__TRANSACTIONCOMPANY_ID("ARTRANSACTIONS", "TRANSACTIONCOMPANY_ID")
        Fix_CUST_COMP_LINK__COMPANY_ID("CUST_COMP_LINK", "COMPANY_ID")
        Fix_CUSTOMERACCOUNTS__COMPANY_ID("CUSTOMERACCOUNTS", "COMPANY_ID")
        Fix_PERMITS__COMPANY_ID("PERMITS", "COMPANY_ID")
        Fix_RECEIPTPAYMENTS__COMPANY_ID("RECEIPTPAYMENTS", "COMPANY_ID")
        Fix_TRANSACTIONS__COMPANY_ID("TRANSACTIONS", "COMPANY_ID")

        'CUSTOMER_ID
        Fix_ARSCHEDULEDETAIL__CUSTOMER_ID("ARSCHEDULEDETAIL", "CUSTOMER_ID")
        '      Some not from merge - these were left orphaned for now
        Fix_ARSCHEDULEHEADER__AUTO_PAY_FOR_CUSTOMER_ID("ARSCHEDULEHEADER", "AUTO_PAY_FOR_CUSTOMER_ID")
        '      Some not from merge - these were left orphaned for now
        Fix_ARSCHEDULEHEADER__CUSTOMER_ID("ARSCHEDULEHEADER", "CUSTOMER_ID")
        '      Some not from merge - these were left orphaned for now
        Fix_ARTRANSACTIONS__CUSTOMER_ID("ARTRANSACTIONS", "CUSTOMER_ID")
        '      Some not from merge - these were left orphaned for now
        Fix_ARTRANSACTIONS__TRANSACTIONCUSTOMER_ID("ARTRANSACTIONS", "TRANSACTIONCUSTOMER_ID")
        '      Some not from merge - these were left orphaned for now
        Fix_BULKEMAILRECIPIENTS__CUSTOMER_ID("BULKEMAILRECIPIENTS", "CUSTOMER_ID")
        Fix_CUSTOMER_DEMOGRAPHICS__CUSTOMER_ID("CUSTOMER_DEMOGRAPHICS", "CUSTOMER_ID")
        Fix_CUSTOMER_MAIL__CUSTOMER_ID("CUSTOMER_MAIL", "CUSTOMER_ID")
        Fix_CUSTOMER_MEMBERSHIP_DATES__CUSTOMER_ID("CUSTOMER_MEMBERSHIP_DATES", "CUSTOMER_ID")
        '      Some not from merge - these were left orphaned for now
        'new relationship?? CUSTOMERCUSTOMQUESTIONS__CUSTOMER_ID  - BUG! - All records have ids of -1  
        Fix_CUSTOMERLOGINS__CUSTOMER_ID("CUSTOMERLOGINS", "CUSTOMER_ID")
        Fix_CUSTOMERS__LASTPAYEE_ID("CUSTOMERS", "LASTPAYEE_ID")
        Fix_CUSTOMERSCHOLARSHIP__CUSTOMER_ID("CUSTOMERSCHOLARSHIP", "CUSTOMER_ID")
        Fix_DCPICKUPAUTHORIZATIONS__PICKUPCUSTOMER_ID("DCPICKUPAUTHORIZATIONS", "PICKUPCUSTOMER_ID")
        Fix_DELAYEDREFUNDS__CUSTOMER_ID("DELAYEDREFUNDS", "CUSTOMER_ID")
        Fix_FAMILYMEMBERS__CUSTOMER_ID("FAMILYMEMBERS", "CUSTOMER_ID")
        Fix_ICVERIFYLOG__CUSTOMER_ID("ICVERIFYLOG", "CUSTOMER_ID")
        'Fix_INSTRUCTORS__CUSTOMER_ID("INSTRUCTORS", "CUSTOMER_ID")
        '       many '0' id records - Bendleainsworth 159, Chelseacommunityeducation 262, 
        '       Hydepark 8, WashingtonNCRec 18 
        Fix_MEMBERSHIP_USAGES__CUSTOMER_ID("MEMBERSHIP_USAGES", "CUSTOMER_ID")
        '       Athensrec 580 records for id 8696 - not from merge - these were left orphaned for now
        Fix_MEMBERSHIPS__PRIMARYMEMBERCUSTOMER_ID("MEMBERSHIPS", "PRIMARYMEMBERCUSTOMER_ID")
        '       Some not from merge - these were left orphaned for now
        'Fix_OFFICIALS__CUSTOMER_ID("OFFICIALS", "CUSTOMER_ID")
        '       a bunch of common '0' id records for in house dbs
        Fix_PASSES__CUSTOMER_ID("PASSES", "CUSTOMER_ID")
        '       Some not from merge - these were left orphaned for now
        Fix_PENDINGCUSTOMERS__CUSTOMER_ID("PENDINGCUSTOMERS", "CUSTOMER_ID")
        'Fix_PERMITS__CUSTOMER_ID("PERMITS", "CUSTOMER_ID")
        '       LJSupport04 - 2 records not from merge
        Fix_PLAYERS__CUSTOMER_ID("PLAYERS", "CUSTOMER_ID")
        Fix_RECEIPTPAYMENTS__CUSTOMER_ID("RECEIPTPAYMENTS", "CUSTOMER_ID")
        '       Some not from merge - these were left orphaned for now
        Fix_TEAMCONTACTS__CUSTOMER_ID("TEAMCONTACTS", "CUSTOMER_ID")
        Fix_TRANSACTIONS__CUSTOMER_ID("TRANSACTIONS", "CUSTOMER_ID")
        '       Some not from merge - these were left orphaned for now

        'CUSTOMERTYPE_ID - set to null since all allow nulls
        Fix_COMPANIES__CUSTOMERTYPE_ID("COMPANIES", "CUSTOMERTYPE_ID")
        Fix_CUSTOMERS__CUSTOMERTYPE_ID("CUSTOMERS", "CUSTOMERTYPE_ID")
        Fix_FACILITYGROUPS__CUSTOMERTYPE_ID("FACILITYGROUPS", "CUSTOMERTYPE_ID")
        Fix_STANDARDCHARGES__CUSTOMERTYPE_ID("STANDARDCHARGES", "CUSTOMERTYPE_ID")

        'ACTIVITY_ID
        Fix_ACTIVITY_FEES__ACTIVITY_ID("ACTIVITY_FEES", "ACTIVITY_ID")
        Fix_ACTIVITY_INSTRUCTORS__ACTIVITY_ID("ACTIVITY_INSTRUCTORS", "ACTIVITY_ID")
        Fix_ACTIVITYCUSTOMQUESTIONS__ACTIVITY_ID("ACTIVITYCUSTOMQUESTIONS", "ACTIVITY_ID")
        Fix_ATTACHEDCHECKLISTITEMS__ACTIVITY_ID("ATTACHEDCHECKLISTITEMS", "ACTIVITY_ID")
        Fix_FACILITY_SCHEDULES__ACTIVITY_ID("FACILITY_SCHEDULES", "ACTIVITY_ID")
        Fix_PENDINGADDS__ACTIVITY_ID("PENDINGADDS", "ACTIVITY_ID")
        Fix_TEAMS__ACTIVITY_ID("TEAMS", "ACTIVITY_ID")
        'Fix_TRANSACTIONS__ACTIVITY_ID("TRANSACTIONS", "ACTIVITY_ID")  
        '       Caldwell - 1 2212 
        '       Eauclaire - 1 459 
        '       Pacifica - 1 1026 
        '       SCSLearn - 1 record each for 2336,3417 
        '       Sunrise - 1 record each for 795, 796,797 
        '       LJSupport 02,03,04 - same 5 ids each

        'DCPROGRAM_ID
        Fix_ATTACHEDCHECKLISTITEMS__DCPROGRAM_ID("ATTACHEDCHECKLISTITEMS", "DCPROGRAM_ID")
        Fix_DCPROGRAM_MAIL__DCPROGRAM_ID("DCPROGRAM_MAIL", "DCPROGRAM_ID")
        Fix_DCPROGRAMFEES__DCPROGRAM_ID("DCPROGRAMFEES", "DCPROGRAM_ID")

        'FACILITY_ID
        Fix_ACTIVITY_DATES__FACILITY_ID("ACTIVITY_DATES", "FACILITY_ID")
        Fix_FACILITY_MAIL__FACILITY_ID("FACILITY_MAIL", "FACILITY_ID")
        Fix_FACILITYEVENTCAPACITY__FACILITY_ID("FACILITYEVENTCAPACITY", "FACILITY_ID")
        Fix_FACILITYGROUPFACILITIES__FACILITY_ID("FACILITYGROUPFACILITIES", "FACILITY_ID")
        Fix_FACILITYOVERLAPROLLUP__OVERLAPFACILITY_ID("FACILITYOVERLAPROLLUP", "OVERLAPFACILITY_ID")
        Fix_FACILITYOVERLAPROLLUP__REALFACILITY_ID("FACILITYOVERLAPROLLUP", "REALFACILITY_ID")
        Fix_FACILITYUSERS__FACILITY_ID("FACILITYUSERS", "FACILITY_ID")
        Fix_STANDARDCHARGES__FACILITY_ID("STANDARDCHARGES", "FACILITY_ID")
        'Fix_TRANSACTIONS__FACILITY_ID("TRANSACTIONS", "FACILITY_ID") 
        '       Cottagegrovemn - 2 records for id 2 
        '       Pvrpd - 6 for id 190 
        '       Sunrise - 1 for id 13 , 4 for id 30
        '       Tigard - 1 for id 60 

        'TEAM_ID
        Fix_LEAGUESCHEDULEPAIRINGS__AWAYTEAM_ID("LEAGUESCHEDULEPAIRINGS", "AWAYTEAM_ID")
        Fix_LEAGUESCHEDULEPAIRINGS__HOMETEAM_ID("LEAGUESCHEDULEPAIRINGS", "HOMETEAM_ID")
        Fix_PLAYERS__TEAM_ID("PLAYERS", "TEAM_ID")
        Fix_TEAMCONTACTS__TEAM_ID("TEAMCONTACTS", "TEAM_ID")
        'Fix_TRANSACTIONS__TEAM_ID("TRANSACTIONS", "TEAM_ID") 
        '       - per Jack - set to null is okay if not team only enrollment 
        '       - id tem only enrollment, have to set a different dummy team for each different activity!

        'PERMIT_ID
        'Fix_PERMIT_DISCLAIMERS__PERMIT_ID("PERMIT_DISCLAIMERS", "PERMIT_ID")
        '       Onalaskaparkrec - 1 record each for ids 12 to 17
        'Fix_PERMITCHANGES__PERMIT_ID("PERMITCHANGES", "PERMIT_ID")
        '       Tigard 1 record refers to id -1 
        'Fix_PERMITUSERS__PERMIT_ID("PERMITUSERS", "PERMIT_ID")
        '       Burnaby01,08 have 2 records each,   LJSupport has 4 records

        'PACKAGE_ID
        'Fix_CUSTOMER_MEMBERSHIP_DATES__PACKAGE_ID("CUSTOMER_MEMBERSHIP_DATES", "PACKAGE_ID")
        '       Athensrec - 4 records for id 38
        '       Grandtraverse - 202 records for numerous different ids     
        Fix_MEMBERSHIPPREREQUISITES__PACKAGE_ID("MEMBERSHIPPREREQUISITES", "PACKAGE_ID")
        'Fix_MEMBERSHIPS__PACKAGE_ID("MEMBERSHIPS__PACKAGE", "PACKAGE_ID")
        '       Athensrec - 4 records for id 38
        '       Conroe - 1 for id 0
        '       Grandtraverse - 170 records for numerous different ids     
        Fix_PACKAGE_ENTRY_POINTS__PACKAGE_ID("PACKAGE_ENTRY_POINTS", "PACKAGE_ID")
        Fix_PACKAGE_FEES__PACKAGE_ID("PACKAGE_FEES", "PACKAGE_ID")
        Fix_PACKAGECUSTOMQUESTIONS__PACKAGE_ID("PACKAGECUSTOMQUESTIONS", "PACKAGE_ID")
        'Fix_TRANSACTIONS__PACKAGE_ID("TRANSACTIONS", "PACKAGE_ID")  
        '       Athensrec - 4 records for id 38
        '       Grandtraverse - 235 records for numerous different ids

        'ENTRYPOINT_ID
        Fix_MEMBERSHIP_USAGES__ENTRYPOINT_ID("MEMBERSHIP_USAGES", "ENTRYPOINT_ID")
        Fix_PACKAGE_ENTRY_POINTS__ENTRYPOINT_ID("PACKAGE_ENTRY_POINTS", "ENTRYPOINT_ID")
        Fix_PACKAGE_ENTRY_POINT_TIMES__PACKAGEENTRYPOINT_ID("PACKAGE_ENTRY_POINT_TIMES", "PACKAGEENTRYPOINT_ID")

        'PASS_ID
        'Fix_MEMBERSHIP_PASSES__PASS_ID("MEMBERSHIP_PASSES", "PASS_ID")
        '       Athensrec - 955 records for numerous different ids
        Fix_MEMBERSHIP_USAGES__PASS_ID("MEMBERSHIP_USAGES", "PASS_ID")

        'POSPRODUCT_ID
        Fix_MEMBERSHIP_USAGES__POSPRODUCT_ID("MEMBERSHIP_USAGES", "POSPRODUCT_ID")
        Fix_POS_GROUP_PRODUCT_LINK__POSPRODUCT_ID("POS_GROUP_PRODUCT_LINK", "POSPRODUCT_ID")
        Fix_POSPRODUCTFEES__POSPRODUCT_ID("POSPRODUCTFEES", "POSPRODUCT_ID")
        'Fix_TRANSACTIONS__POSPRODUCT_ID("TRANSACTIONS", "POSPRODUCT_ID")   
        '       Beaverdamrec - 5 records for id 25 
        '       Burnaby08 - 1 record for id 24 
        '       EDHCSD - 24 records total for 5 different ids
        '       Grandtraverse 2 records for id 12 
        '       Hermiston - 3 records total for 3 different ids
        '       LJSupport06 - 44 records total for 2 different ids
        '       Marinwood 1 record for id 15 
        '       Newtonrec 26 records total for 2 ids
        '       Wildirisrecreation 1 record for id 31 

        'POSGROUPS_ID
        Fix_POSLAYOUTPROPERTIES__GROUP_ID("POSLAYOUTPROPERTIES", "GROUP_ID")
        Fix_TSBUTTONS__POSGROUP_ID("TSBUTTONS", "POSGROUP_ID")

        'SKILL_ID
        Fix_ACTIVITYSKILL__SKILL_ID("ACTIVITYSKILL", "SKILL_ID")
        Fix_INSTRUCTORSKILL__SKILL_ID("INSTRUCTORSKILL", "SKILL_ID")
        Fix_OFFICIALSKILL__SKILL_ID("OFFICIALSKILL", "SKILL_ID")

        'LEAGUESCHEDULE_ID
        Fix_FACILITY_SCHEDULES__LEAGUESCHEDULE_ID("FACILITY_SCHEDULES", "LEAGUESCHEDULE_ID")
        Fix_LEAGUESCHEDULEFACILITIES__LEAGUESCHEDULE_ID("LEAGUESCHEDULEFACILITIES", "LEAGUESCHEDULE_ID")
        Fix_LEAGUESCHEDULEPAIRINGS__LEAGUESCHEDULE_ID("LEAGUESCHEDULEPAIRINGS", "LEAGUESCHEDULE_ID")
        Fix_LEAGUESCHEDULETIMESLOTS__LEAGUESCHEDULE_ID("LEAGUESCHEDULETIMESLOTS", "LEAGUESCHEDULE_ID")
        'Fix_TRANSACTIONS__LEAGUESCHEDULE_ID("TRANSACTIONS", "LEAGUESCHEDULE_ID") 'to john
        '       Isleofwight 42 records 2 ids
        '       Moundsview 8 records for id 2
        '       Newtonrec 173 records for 6 ids
        '       Burnaby01,05,06,08, SacTest03

        'EVENTTYPE_ID
        Fix_ATTACHEDCHECKLISTITEMS__EVENTTYPE_ID("ATTACHEDCHECKLISTITEMS", "EVENTTYPE_ID")
        Fix_EVENTTYPECUSTOMQUESTIONS__EVENTTYPE_ID("EVENTTYPECUSTOMQUESTIONS", "EVENTTYPE_ID")
        'Fix_TRANSACTIONS__EVENTTYPE_ID("TRANSACTIONS","EVENTTYPE_ID") 'to john
        '       Kennesaw 1 for id 15 , 8 for id 12, 4 for id 9 

        'STAGE_ID
        Fix_ATTACHEDCHECKLISTITEMS__STAGE_ID("ATTACHEDCHECKLISTITEMS", "STAGE_ID")
        'Fix_TRANSACTIONSTAGES__STAGE_ID("TRANSACTIONSTAGES","STAGE_ID")
        '       lots of problems including - lots of 0's - 13 db's with non 0's

        'FACILITY SCHEDULE_ID
        Fix_ACTIVITY_DATES__FACILITY_SCHEDULE_ID("ACTIVITY_DATES", "FACILITY_SCHEDULE_ID")
        Fix_DCSESSIONDATES__FACILITY_SCHEDULE_ID("DCSESSIONDATES", "FACILITY_SCHEDULE_ID")
        Fix_LEAGUESCHEDULEPAIRINGS__FACILITYSCHEDULE_ID("LEAGUESCHEDULEPAIRINGS", "FACILITYSCHEDULE_ID")

        'BULKEMAILTASK_ID 
        Fix_BULKEMAILATTACHMENTS__BULKEMAILTASK_ID("BULKEMAILATTACHMENTS", "BULKEMAILTASK_ID")
        Fix_BULKEMAILRECIPIENTS__BULKEMAILTASK_ID("BULKEMAILRECIPIENTS", "BULKEMAILTASK_ID")
        Fix_OPTOUTHISTORY__BULKEMAILTASK_ID("OPTOUTHISTORY", "BULKEMAILTASK_ID")

        'RECEIPTHEADER_ID  - set to null for all three cases  - check with john if this is okay...
        Fix_ICVERIFYLOG__RECEIPTHEADER_ID("ICVERIFYLOG", "RECEIPTHEADER_ID")
        Fix_MEMBERSHIPAUTORENEWAL__RECEIPTHEADER_ID("MEMBERSHIPAUTORENEWAL", "RECEIPTHEADER_ID")
        Fix_TRANSACTIONS__RECEIPTHEADER_ID("TRANSACTIONS", "RECEIPTHEADER_ID")

        'PROFILE_ID
        Fix_PROFILEOPTIONS__PROFILE_ID("PROFILEOPTIONS", "PROFILE_ID")
        '???how to fix??Fix_SYSTEM_USERS__PROFILE_ID("SYSTEM_USERS", "PROFILE_ID")   
        '     ' 8 db - how to fix? set up a dummy empty profile?

        '============================
        Fix_ACTIVITIES__SUPERVISOR_ID("ACTIVITIES", "SUPERVISOR_ID")
        Fix_ACTIVITIES__PREPCODE_ID("ACTIVITIES", "PREPCODE_ID")
        Fix_ACTIVITIES__PRIMARYINSTRUCTOR_ID("ACTIVITIES", "PRIMARYINSTRUCTOR_ID")
        Fix_ACTIVITIES__RG_CATEGORY_ID("ACTIVITIES", "RG_CATEGORY_ID")
        Fix_ACTIVITIES__SEASON_ID("ACTIVITIES", "SEASON_ID")
        'Fix_ACTIVITYATTENDANCE__ACTIVITY_DATE_ID("ACTIVITYATTENDANCE","ACTIVITY_DATE_ID")  
        '       AARecEd,Athensparks,Chanhassen,Conroe,FerndaleRec  
        '       Burnaby06,LJSupport06
        'Fix_ACTIVITYCUSTOMQUESTIONS__CUSTOMQUESTION_ID("ACTIVITYCUSTOMQUESTIONS","CUSTOMQUESTION_ID")  
        '       CampCo - 53 of id 4 and 1 of id 6
        '       Chanhassen - 1 record each for ids 1-2
        '       Gears 1 record for each of ids 1-3

        ''''''Ignore'''''Fix_ACTIVITYFEEPACKAGES__ACTIVITY_FEE_ID("ACTIVITYFEEPACKAGES","ACTIVITY_FEE_ID")
        ''''''Ignore'''''cannot find any problems now - Burnaby05,11 were reported in the upsizeerror log

        Fix_BULKEMAILACKNOWLEDGEMENTS__BULKEMAILRECIPIENT_ID("BULKEMAILACKNOWLEDGEMENTS", "BULKEMAILRECIPIENT_ID")
        Fix_BULKEMAILATTACHMENTS__UPLOADEDFILE_ID("BULKEMAILATTACHMENTS", "UPLOADEDFILE_ID")

        Fix_CUSTOMERS__GEOGRAPHIC_AREA_ID("CUSTOMERS", "GEOGRAPHIC_AREA_ID")

        Fix_CUSTOMLISTINCLUDES__REPORT_DEFINITION_ID("CUSTOMLISTINCLUDES", "REPORT_DEFINITION_ID")
        Fix_DCSESSIONDATES__DCSESSION_ID("DCSESSIONDATES", "DCSESSION_ID")

        'Fix_EXPORTTEMPLATEDETAILS__EXPORTTEMPLATEHEADER_ID("EXPORTTEMPLATEDETAILS","EXPORTTEMPLATEHEADER_ID")
        '       CampCo - 1 record for id 1
        '       Centralpointrec 3 records for id 2 
        '       Kennesaw - 1 record for id 1, 2 records each for ids 2-3, 3 records for id 4, 1 record for id 8 
        '       LJSupport06 - 8 records for ids 1 and 8, 5 records for id 11, 3 records for id 12
        'Fix_EXPORTTRANSLATIONRULES__EXPORTTEMPLATEDETAIL_ID("EXPORTTRANSLATIONRULES","EXPORTTEMPLATEDETAIL_ID")
        '       Oconee - 2 records for id 0
        '       Petalumarec - 1 record for id 1 
        '       Burnaby10 - 1 record for id 15
        '       LJSupport06 1 record for each of ids 0, 15, 26 

        Fix_FACILITIES__FACILITYTYPE_ID("FACILITIES", "FACILITYTYPE_ID")
        'Fix_FACILITYGROUPFACILITIES__FACILITYGROUP_ID("FACILITYGROUPFACILITIES","FACILITYGROUP_ID") 
        '       LJSupport06 - 26 records missing ids 1 to 6
        Fix_WORKSTATIONS__FACILITYGROUP_ID("WORKSTATIONS", " FACILITYGROUP_ID")

        Fix_LEAGUESCHEDULEPAIRINGS__POSTPONEREASON_ID("LEAGUESCHEDULEPAIRINGS", "POSTPONEREASON_ID")
        Fix_LOCKERFEES__LOCKERGROUP_ID("LOCKERFEES", "LOCKERGROUP_ID")

        ''''''Ignore'''''locker table will not have transaction_id column after upsize so ignore any problems here
        ''''''Ignore'''''LOCKERS__TRANSACTION_ID 

        'Fix_MEMBERSHIPAUTORENEWAL__MEMBERSHIP_ID("MEMBERSHIPAUTORENEWAL","MEMBERSHIP_ID") 
        '       Burnaby08 - missing 4 ids - from 5 to 22 records of each

        Fix_PACKAGES__PACKAGECATEGORY_ID("PACKAGES", "PACKAGECATEGORY_ID")
        Fix_PASSLAYOUTS__BACKGROUNDFILE_ID("PASSLAYOUTS", "BACKGROUNDFILE_ID")
        Fix_PASSLAYOUTS__LOGOFILE_ID("PASSLAYOUTS", "LOGOFILE_ID")
        Fix_PASSES__PASSLAYOUT_ID("PASSES", "PASSLAYOUT_ID")

        Fix_POSPRODUCTS__UPLOADEDFILE_ID("POSPRODUCTS", "UPLOADEDFILE_ID")

        Fix_RECEIPTPAYMENTS__CARDTYPE_ID("RECEIPTPAYMENTS", "CARDTYPE_ID") 'set to null

        Fix_STAGES__UPLOADEDFILE_ID("STAGES", "UPLOADEDFILE_ID")
        Fix_STAGESEQUENCESTAGEDETAILS__DETAILCHILD_ID("STAGESEQUENCESTAGEDETAILS", "DETAILCHILD_ID")  
        Fix_STAGESEQUENCESTAGEDETAILS__STAGESEQUENCESTAGE_ID("STAGESEQUENCESTAGEDETAILS", "STAGESEQUENCESTAGE_ID")
        Fix_STAGESEQUENCESTAGES__STAGESEQUENCE_ID("STAGESEQUENCESTAGES", "STAGESEQUENCE_ID")

        'Fix_TEAMS__LEAGUE_ID("TEAMS","LEAGUE_ID")  '??set to null?? 
        '       ask Jack first if it is okay for a team to have neither an activity or a league
        '       Burnaby01 -  1 record each for ids 2,9,11 and 5 records for id 5 
        '       Isleofwight -  2 records for id 1 
        '       Newtonrec - 3 records for id 22, 1 record for id 23 

        'Fix_TRANSACTIONS__SCHEDULETYPE_ID("TRANSACTIONS","SCHEDULETYPE_ID")  
        '       AARecEd - 2 records for id 3 

        WriteToUpsizerLog("Foreign key relationship fixes ended at " & Now())
  End Sub

    'Check if relationhsip flagged as implemented 
    Private Function FixDRI_FKAlreadyImplemented(ByVal sChildTable As String, _
                                                 ByVal sFKeyField As String) _
                                                 As Boolean

        Dim bImplemented As Boolean = False

        If mobTargetDDManager.Tables.ContainsKey("DDRELATIONS") Then
            Dim oRs As ACS.DataAccess.claRecordSet = Nothing
            Try
                If mobDDDbConn.bQuery(oRs, "select * from ddrelations where child_table='" _
                    & sChildTable & "' and fkey='" & sFKeyField & "' and implemented <> 0", "") Then
                    If oRs.Read Then
                        bImplemented = True
                    ElseIf Not mobTargetDDManager.Tables.ContainsKey(sChildTable) Then
                        bImplemented = True     'no point checking for existing foreign key problems!
                    End If
                End If

            Finally
                If oRs IsNot Nothing Then oRs.Dispose()
            End Try
        End If

        If Not bImplemented Then
            UpdateStatusMsg("    Checking: " & sChildTable & "__" & sFKeyField & " -- " & FormatDateTime(Now(), DateFormat.LongTime), StatusMsgLevel.Level_2)
        End If

        Return bImplemented

    End Function

    'Set internet site id, internet profile id, internet systemuser id, internet workstation
    Private Function FixDRI_SetDefaultIds() As Boolean

        Dim sSql As String
        Dim bAllOkay As Boolean = True
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing

        Try
            sSql = "select INTERNETSITE_ID from SYSTEM"
            If mobDDDbConn.bQuery(oRs, sSql, "") Then
                If oRs.Read Then
                    miInternetSiteID = CInt(oRs.IDataReader_Item("INTERNETSITE_ID"))
                    WriteToUpsizerLog(msIndent & "Default site id = " & miInternetSiteID)
                Else
                    bAllOkay = False
                    LogUpsizeError("SYSTEM record not found - cannot determine the InternetSiteId", False)
                End If
            End If
            If oRs IsNot Nothing Then oRs.Dispose()

            sSql = "select PROFILE_ID from PROFILES where NAME = 'Internet'"
            If mobDDDbConn.bQuery(oRs, sSql, "") Then
                If oRs.Read Then
                    miInternetProfileID = CInt(oRs.IDataReader_Item("PROFILE_ID"))
                    WriteToUpsizerLog(msIndent & "Default profile id = " & miInternetProfileID)
                Else
                    bAllOkay = False
                    LogUpsizeError("Profile record with name of 'Internet' not found", False)
                End If
            End If
            If oRs IsNot Nothing Then oRs.Dispose()

            sSql = "select systemuser_id from SYSTEM_USERS where profile_id = " _
                      & miInternetProfileID & " and site_id = " & miInternetSiteID
            If mobDDDbConn.bQuery(oRs, sSql, "") Then
                If oRs.Read Then
                    miInternetSystemUserId = CInt(oRs.IDataReader_Item("systemuser_id"))
                    WriteToUpsizerLog(msIndent & "Default system user id = " & miInternetSystemUserId)
                Else
                    bAllOkay = False
                    LogUpsizeError("SystemUser_id for internet user not found", False)
                End If
            End If
            If oRs IsNot Nothing Then oRs.Dispose()

            sSql = "select max(workstation_id) as ws_id from WORKSTATIONS where site_id = " & miInternetSiteID
            If mobDDDbConn.bQuery(oRs, sSql, "") Then
                If oRs.Read Then
                    miInternetWorkstationID = CInt(oRs.IDataReader_Item("ws_id"))
                    WriteToUpsizerLog(msIndent & "Default workstation id = " & miInternetWorkstationID)
                Else
                    bAllOkay = False
                    LogUpsizeError("Internet workstation id not found", False)
                End If
            End If
            If oRs IsNot Nothing Then oRs.Dispose()

            'sSql = "select customer_id from customers where lastname = 'Customer' and firstname = 'Drop-in'"
            sSql = "select cashcustomer_id from SYSTEM"
            If mobDDDbConn.bQuery(oRs, sSql, "") Then
                If oRs.Read Then
                    miDropInCustomerID = CInt(oRs.IDataReader_Item("cashcustomer_id"))
                    WriteToUpsizerLog(msIndent & "Default customer id = " & miDropInCustomerID)
                Else
                    bAllOkay = False
                    LogUpsizeError("Default customer id (SYSTEM.cashcustomer_id) not found", False)
                End If
            End If

        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

        Return bAllOkay

    End Function

    'Scope:
    '   63 dbs - all have some id=0
    '   Caldwell missing id 6, City of Claremont missing id 6, Sunrise missing id 2
    '
    ' Solution:
    '   insert default id into all problem records
    Private Sub Fix_CENTERS__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   1 db - LJSupport06 - missing id = 0
    '
    ' Solution:
    '   insert default id into all problem records
    Private Sub Fix_COMPANYCONSOLIDATIONLOG__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   2 dbs 
    '       Dyersvilleparkandrec - 5 records for id= 5 
    '       Fruitarecreation      -1 record for id= 9 
    '
    ' Solution:
    '   insert default id into all problem records
    Private Sub Fix_CUSTCONSOLIDATIONEXCLUDES__EXCLUDEDBYUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   71 dbs - all have some id=0
    '   City of Claremont missing id 6, Sunrise missing id 2
    '
    ' Solution:
    '   insert default id into all problem records
    Private Sub Fix_FACILITIES__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   1 db - Snoco - missing id = 14
    '
    ' Solution:
    '   delete the record since facilityuser_id is not used in any other tables
    Private Sub Fix_FACILITYUSERS__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID")

    End Sub

    'Scope:
    '   6 dbs - each has 1 id missing (17 records total)
    '   Bremerton, Cityofepa, FairOaksPark, HighPrairie, RochesterCE, Venture

    ' Solution:
    '   delete the records favorite_id is not used in any other tables
    Private Sub Fix_FAVORITEITEMS__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID")

    End Sub


    'Scope:
    '   no bad data exists reported since it is a newly identified relationship
    '
    ' Solution:
    '   insert default id into any problem records so upsize can implement the relationship
    Private Sub Fix_LOCKER_SCHEDULES__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   4 dbs 
    '       LJSupport, LJSupport02,03,04 - all have same 8 occurrences each of user id 79 
    '
    ' Solution:
    '   set to null
    Private Sub Fix_FACILITY_SCHEDULES__HOLDUSERID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID")

    End Sub

    'Scope:
    '   2 dbs 
    '   Holmenwirec, Petalumarec - each has 1 id missing - 1 record each

    ' Solution:
    '   delete the record since the user is no longer there to see the message
    Private Sub Fix_MESSAGEQUEUES__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID")

    End Sub

    'Scope:
    '   1 db - LJSupport06 - missing id = 0 
    '
    ' Solution:
    '   insert the default id into all problem records
    Private Sub Fix_POPULATIONCONSOLIDATIONLOG__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   1 db - Oxfordparkcommission - missing id = 10  for stage id = 3
    '
    ' Solution:
    '   insert the default id into all problem records
    Private Sub Fix_STAGES__APPROVALSYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   2 dbs 
    '       Dcparksandrec - missing id ids 5,8 - several transactions each - all for stage id = 6
    '       Oxfordparkcommission - missing id = 0  - for one transaction -  for stage id = 3
    '
    ' Solution:
    '   insert the default id into all problem records
    Private Sub Fix_TRANSACTIONSTAGES__APPROVALSYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   21 dbs 
    '       Petalumarec - missing id 9 - for numerous transactions for activity id = 636 taken prior to noon
    '                     similar transactions taken after 1pm from save station have systemuser id = 4 
    '                     so change the others to match
    '       other dbs's are "non-site dbs" with missing id = 0  - for many transations each
    '
    ' Solution:
    '   insert the default id into all problem records
    Private Sub Fix_TRANSACTIONS__SYSTEMUSER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SYSTEM_USERS", "SYSTEMUSER_ID", miInternetSystemUserId)

    End Sub

    'Scope:
    '   2 dbs - Frrpd 12 ids, Linolakes 9 ids but one of them was in 283 records
    '
    ' Solution:
    '   null allowed so set to null.
    Private Sub Fix_ACTIVITY_FEES__GLACCOUNT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "GLACCOUNTS", "GLACCOUNT_ID")

    End Sub

    'Scope:
    '   3 dbs - Dcparksandrec 1 id, Frrpd 2 ids, Mabparksrec 1 id
    '
    ' Solution:
    '   null allowed so set to null.
    Private Sub Fix_CHARGES__GLACCOUNT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "GLACCOUNTS", "GLACCOUNT_ID")

    End Sub

    'Scope:
    '   1 db - Minicourses 1 id
    '
    ' Solution:
    '   ?? nulls not allowed
    Private Sub Fix_EXPENSES__GLACCOUNT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        '??? how to fix?

    End Sub

    'Scope:
    '   4 dbs - Burnaby08, FPDWCD, SunPrairiePRF, Waunakee - all hve id = 0 in 1 to 3 records
    '
    ' Solution:
    '   null allowed so set to null.  But not until after the upsize!! 
    Private Sub Fix_POSPRODUCTS__GLACCOUNT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        'set to allwo null first!
        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "GLACCOUNTS", "GLACCOUNT_ID", True)

    End Sub

    'Scope:
    '   1 site dbs - Frrpd, 8 different records affected - 8 different ids
    '
    ' Solution:
    '   null allowed so set to null.
    Private Sub Fix_RG_CATEGORY__GLACCOUNT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "GLACCOUNTS", "GLACCOUNT_ID")

    End Sub

    'Scope:
    '   5 site dbs
    '       Bmrc 9 2 
    '       Grandtraverse 66 1 
    '       Pvrpd 1 3 
    '       Seaside 7       3 
    '       Venture 394     4 
    '       Venture 139     3 
    '       Venture 1158    26 
    '       Venture 143     2 
    '       Venture 3130    1 
    '       Venture 2       8 
    '
    ' Solution:
    '   null allowed so set to null.
    Private Sub Fix_ACTIVITY_FEES__CHARGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "CHARGES", "CHARGE_ID")

    End Sub

    'Scope:
    '   7 site dbs - 
    '       CampCo          2       287 
    '       Dcparksandrec   7465    2 
    '       Eauclaire       1877    2 
    '       EDHCSD          974     2 
    '       Pvrpd           11 different ids - approx 120 records total
    '       Rosevillemn     6       119 
    '       Venture         4831    1 

    '   17 in house ones - all have some id = 1 records

    ' Solution:
    '   null allowed so set to null.
    Private Sub Fix_RECEIPTDETAILS__CHARGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "CHARGES", "CHARGE_ID")

    End Sub

    'Scope:
    '   1 db - FairOaksPark 

    ' Solution:
    '   null allowed so set to null.
    Private Sub Fix_SYSTEM__ABSORBCHARGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "CHARGES", "CHARGE_ID")

    End Sub

    'Scope:
    '   3 dbs - all non-site dbs -  Burnaby01,08,LJSupport06 

    ' Solution:
    '   just delete the records 
    Private Sub Fix_ACTIVITYATTENDANCE__TRANSACTION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "TRANSACTIONS", "TRANSACTION_ID")

    End Sub

    'Scope:
    '   1 db - non-site SacTest03  4 records - arscheduleheader_ids 279,280,281,282

    ' Solution:
    '   null allowed so set to null.
    Private Sub Fix_ARSCHEDULEHEADER__TRANSACTION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "TRANSACTIONS", "TRANSACTION_ID")

    End Sub

    'Scope:
    '   4 dbs - all non-site dbs - Burnaby09,10, LJSupport06, Activation

    ' Solution:
    '   null allowed so set to null.
    Private Sub Fix_FACILITY_SCHEDULES__TRANSACTION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "TRANSACTIONS", "TRANSACTION_ID")

    End Sub

    'Scope: 
    '   No existing orphans can be fixed by looking at merged companies  - BUG??
    '           Concordparksrec 2, Pacifica 1, Tigard 3  
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARSCHEDULEDETAIL__COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   No existing orphans can be fixed by looking at merged companies  - BUG??
    '           Concordparksrec 2, Pacifica 1, Tigard 3  
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARSCHEDULEHEADER__COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   ??can any be fixed by merge??
    '           Concordparksrec 2, Pacifica 1, Tigard 3  
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARTRANSACTIONS__COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   No existing orphans can be fixed by looking at merged companies  - BUG??
    '      
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARTRANSACTIONS__TRANSACTIONCOMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   No existing orphans can be fixed by looking at merged companies  - BUG?? 
    '       - Concordparksrec 2, Pacifica 1, Tigard 3  
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_CUST_COMP_LINK__COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   No existing orphans can be fixed by looking at merged companies  - BUG?? 
    '       - Concordparksrec 2, Pacifica 1, Tigard 3  
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_CUSTOMERACCOUNTS__COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   No existing orphans can be fixed by looking at merged companies  - BUG??
    '       Centralpointrec 1, Concordparksrec 4, Inghamcounty 1, Pacifica 1, 
    '       Roanokerec 1, Tigard 3  
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_PERMITS__COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   No existing orphans can be fixed by looking at merged companies  - BUG??
    '       AARecEd 3, Concordparksrec 4, Pacifica 1, 
    '       RochesterCE 1, Tigard 3,  Waunakee 1
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_RECEIPTPAYMENTS__COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   No existing orphans can be fixed by looking at merged companies  - BUG??
    '       AARecEd 1, Centralpointrec 1, Concordparksrec 4, Inghamcounty 1, Pacifica 1, Tigard 3
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_TRANSACTIONS__COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CompanyID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   19 dbs - 15 site dbs 4 other dbs 

    ' Solution:
    '   delete the records 
    Private Sub Fix_TSBUTTONS__POSGROUP_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "POSGROUPS", "POSGROUP_ID")

    End Sub

    'Scope:
    '   19 dbs - 15 site dbs 4 other dbs  

    ' Solution:
    '   delete the records 
    Private Sub Fix_POSLAYOUTPROPERTIES__GROUP_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "POSGROUPS", "POSGROUP_ID")

    End Sub

    'Scope:
    '   45 dbs - passlayout_id is set to 0 in PASSES table
    '
    ' Solution:
    '   All the tables except 2 have a standard layout with id = 1 and all records with id - 0 will be set to 1.
    '   for 'Venture' there are no layouts in the db and the single pass in the db will be deleted
    '   for 'LJSupport06' the standard layout id = 4 and the records with id = 0 will be set to 4.
    Private Sub Fix_PASSES__PASSLAYOUT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        Dim sFKRelationship As String = sChildTable & "__" & sFKeyField
        Dim sDesc As String = "Fixing " & sFKRelationship
        Dim iRecordsAffected As Integer
        Dim iNewID As Integer
        Dim sSQL As String
        Dim sMsg As String

        Try
            If FixDRI_FKAlreadyImplemented(sChildTable, sFKeyField) Then
                Return
            End If

            If mobDDDbConn.Database = "Venture" Then
                sSQL = "Delete from " & sChildTable & " where " & sFKeyField & _
                        " not in (Select " & sFKeyField & " from PASSLAYOUTS)"
                sMsg = " records deleted"
            ElseIf mobDDDbConn.Database = "LJSupport06" Then
                iNewID = 4
                sSQL = "update " & sChildTable & " set " & sFKeyField & " = " & iNewID _
                        & " where " & sFKeyField & " not in (select " & sFKeyField & " from PASSLAYOUTS)"
                sMsg = " records updated to " & sFKeyField & " '" & iNewID & "'"
            Else
                iNewID = 1
                sSQL = "update " & sChildTable & " set " & sFKeyField & " = " & iNewID _
                        & " where " & sFKeyField & " not in (select " & sFKeyField & " from PASSLAYOUTS)"
                sMsg = " records updated to " & sFKeyField & " '" & iNewID & "'"
            End If

            If mobDDDbConn.bExecuteSql(sSQL, sDesc, iRecordsAffected) Then
                WriteToUpsizerLog(msIndent & iRecordsAffected & sMsg)
            Else
                LogUpsizeError(sChildTable & " table: failed fixing data for " _
                    & sFKeyField & "......SQL = " & sSQL, False)
            End If

        Catch ex As Exception
            LogUpsizeError("Fix_" & sFKRelationship & " - " & ex.Message & ".", False, ex.StackTrace)
        End Try
    End Sub

    'Scope:
    '   24 dbs - stranded PACAKGE_ENTRY_POINT_TIMES records for deleted PACKAGE_ENTRY_POINTS
    '
    ' Solution:
    '   With no package entry point attached to these records, it's safe to delete them.
    Private Sub Fix_PACKAGE_ENTRY_POINT_TIMES__PACKAGEENTRYPOINT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "PACKAGE_ENTRY_POINTS", "PACKAGEENTRYPOINT_ID")

    End Sub

    'Scope:
    '   2 dbs - stranded PACAKGE_ENTRY_POINT records for deleted ENTRY_POINTS
    '
    ' Solution:
    '   With no entry point attached to these records, it's safe to delete them.
    Private Sub Fix_PACKAGE_ENTRY_POINTS__ENTRYPOINT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "ENTRY_POINTS", "ENTRYPOINT_ID")

    End Sub

    Private Sub FixDRI_ReplaceIDs(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                  ByVal sParentTable As String, ByVal sParentKeyField As String, _
                                  ByVal iNewID As Integer)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, sParentTable, sParentKeyField, iNewID.ToString)

    End Sub


    Private Sub FixDRI_ReplaceWithNulls(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                        ByVal sParentTable As String, ByVal sParentKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, sParentTable, sParentKeyField, "Null")

    End Sub

    Private Sub FixDRI_ReplaceWithNulls(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                        ByVal sParentTable As String, ByVal sParentKeyField As String, _
                                        ByVal bSetColumnToAllowNullFirst As Boolean)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, sParentTable, sParentKeyField, "Null", bSetColumnToAllowNullFirst)

    End Sub

    Private Sub FixDRI_ReplaceIDs(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                  ByVal sParentTable As String, ByVal sParentKeyField As String, _
                                  ByVal sNewID As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, sParentTable, sParentKeyField, sNewID, False)

    End Sub

    Private Sub FixDRI_ReplaceIDs(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                  ByVal sParentTable As String, ByVal sParentKeyField As String, _
                                  ByVal sNewID As String, ByVal bSetColumnToAllowNullFirst As Boolean)

        Dim sFKRelationship As String = sChildTable & "__" & sFKeyField
        Dim sDesc As String = "Checking " & sFKRelationship
        Dim iRecordsAffected As Integer
        Dim sSql As String = ""

        Try
            If FixDRI_FKAlreadyImplemented(sChildTable, sFKeyField) Then
                Return
            End If

            If bSetColumnToAllowNullFirst Then
                'don't bother setting column to null if there are no orphans that need it
                If FixDRI_GetOrphanCount(sChildTable, sFKeyField, sParentTable, sParentKeyField) > 0 Then
                    WriteToUpsizerLog(msIndent & "Changing " & sChildTable & " to allow null in column " & sFKeyField)

                    sSql = "alter table " & sChildTable & " alter column " & sFKeyField & " int NULL"
                    If mobDDDbConn.bExecuteSql(sSql, sDesc) Then
                        WriteToUpsizerLog(msIndent & sFKeyField & " successfully updated to allow null")
                     Else
                        LogUpsizeError(sChildTable & "..." & sFKeyField & ": failed setting column to allow null" _
                            & "......SQL = " & sSql, False)
                    End If
                End If
            End If

            sSql = "update " & sChildTable & " set " & sFKeyField & " = " & sNewID _
                    & " where " & sFKeyField & " not in (select " & sParentKeyField _
                    & " from " & sParentTable & ")"
            If sNewID.ToUpper.CompareTo("NULL") = 0 Then
                sSql += " and " & sFKeyField & " is not null"       'no need to set null columns to null
            End If
            If mobDDDbConn.bExecuteSql(sSql, sDesc, iRecordsAffected) Then
                If iRecordsAffected > 0 Then
                    WriteToUpsizerLog(msIndent & iRecordsAffected & _
                        " records updated to id '" & sNewID & "'")
                 Else
                    WriteToUpsizerLog(msIndent & "No problem found")
                End If
            Else
                LogUpsizeError(sChildTable & " table: failed fixing data for " _
                    & sFKeyField & "......SQL = " & sSql, False)
            End If

        Catch ex As Exception
            LogUpsizeError("Fix_" & sFKRelationship & " - " & ex.Message & ".", False)
        End Try
    End Sub

    Private Sub FixDRI_DeleteRecords(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                     ByVal sParentTable As String, ByVal sParentKeyField As String)

        Dim sFKRelationship As String = sChildTable & "__" & sFKeyField
        Dim sDesc As String = "Fixing " & sFKRelationship
        Dim iRecordsAffected As Integer

        Try
            If FixDRI_FKAlreadyImplemented(sChildTable, sFKeyField) Then
                Return
            End If

            Dim sSql As String = "Delete from " & sChildTable & " where " & sFKeyField & _
                    " not in (select " & sParentKeyField & " from " & sParentTable & ")"
            If mobDDDbConn.bExecuteSql(sSql, sDesc, iRecordsAffected) Then
                If iRecordsAffected > 0 Then
                    WriteToUpsizerLog(msIndent & iRecordsAffected & " records deleted")
                Else
                    WriteToUpsizerLog(msIndent & "No problem found")
                End If
            Else
                LogUpsizeError(msIndent & sChildTable & " table: failed fixing data for " _
                            & sFKeyField & "......SQL = " & sSql, False)
            End If

        Catch ex As Exception
            LogUpsizeError("Fix_" & sFKRelationship & " - " & ex.Message & ".", False, ex.StackTrace)
        End Try

    End Sub

    Private Function FixDRI_GetOrphanCount(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                           ByVal sParentTable As String, ByVal sParentKeyField As String) _
                                           As Integer

        Dim oRs As ACS.DataAccess.claRecordSet = Nothing
        Dim sSql As String
        Dim iCount As Integer = 0

        Try
            sSql = "select count(*) as NumOrphans from " & sChildTable _
                   & " where " & sFKeyField & " not in (select " & sParentKeyField _
                   & " from " & sParentTable & ") and " & sFKeyField & " is not null"

            If mobDDDbConn.bQuery(oRs, sSql, "") Then
                If oRs.Read Then
                    iCount = CInt(oRs.IDataReader_Item("NumOrphans"))
                End If
            Else
                LogUpsizeError("Problem during check for orphaned records.  SQL = " & sSql, False)
            End If

        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

        Return iCount

    End Function

    'Scope:
    '   17 dbs - Some membership usage records are missing the related passes record
    '
    ' Solution:
    '   With POS usages being recorded in this table the pass_id is not always available
    '   so all records that doesn't have a related pass record would be set to null to enforce the fkey relationship.
    Private Sub Fix_MEMBERSHIP_USAGES__PASS_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "PASSES", "PASS_ID")

    End Sub

    'Scope:
    '   2 dbs - Some membership usage records are missing the related pos product record
    '
    ' Solution:
    '   POS product id field is nullable.
    '   so all records that doesn't have a related pos product record would be set to null to enforce the fkey relationship.
    Private Sub Fix_MEMBERSHIP_USAGES__POSPRODUCT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "POSPRODUCTS", "POSPRODUCT_ID")

    End Sub

    'Scope:
    '   40 dbs affected - when the scan was overridden the entrypoint_id was set to -1
    '
    ' Solution:
    '   With POS usages being recorded in this table the entrypoint_id is not always available
    '   so all records with -1 or 0 would be set to null to enforce the fkey relationship.
    Private Sub Fix_MEMBERSHIP_USAGES__ENTRYPOINT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "ENTRY_POINTS", "ENTRYPOINT_ID")

    End Sub

    'Scope:
    '   25 dbs- all have some id=0, some (non-site dbs) have lots of ids=58,59 
    '   Lincolnshire, Moundsview, Waunakee - have just 1 or 2 records each missing id=0
    '   all other dbs are 'non-site' dbs with similar missing 58,59 ids - some of which also are missing id=0
    '
    ' Solution:
    '   insert default id for all problem records
    Private Sub Fix_TRANSACTIONS__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   24 dbs 
    '   Estevan, Lincolnshire, Moundsview, Saintpeter - each has 1 record with id = 0
    '   Waunakee has 6 with id = 0 - from two separate receipts
    '   all other dbs are 'non-site' dbs - most with similar 58,59 ids 
    '   Burnaby01 and LJSupport06 have many '0' id's
    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_RECEIPTDETAILS__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   24 dbs 
    '   Ann Arbor has 10, Lincolnshire has 1, Moundsview has 1, Waunakee has 2 --- id = 0
    '   all other dbs are 'non-site' dbs - most with similar 58,59 ids 
    '   Burnaby01, Burnaby08 and LJSupport06 have many '0' id's
    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_RECEIPTHEADERS__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   23 dbs 
    '   Lincolnshire, Moundsview, Waunakee - each with 1 or 2 records with '0' id
    '   rest are 'non-site' dbs with common 58,59 ids
    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_RECEIPTPAYMENTS__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   17 dbs - all 'non-site' dbs with identical 58,59 ids 
    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_ARSCHEDULEDETAIL__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   17 dbs - all 'non-site' dbs 
    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_ARSCHEDULEHEADER__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   17 dbs affected 
    '   Estevan, Saintpeter - each has 1 record with id = 0
    '   Waunakee has 4 with id = 0 - from two separate receipts
    '   all other dbs are 'non-site' dbs - most with identical 58,59 ids 
    '   LJSupport06 has 1 record with id=0
    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_ARTRANSACTIONS__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '    some in house dbs affected already
    '
    ' Solution:
    '   delete all the orphaned records
    Private Sub Fix_COUPON_PENDINGADDS__WORKSTATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID")

    End Sub

    'Scope:
    '   24 dbs affected 
    '   Estevan, Lincolnshire, Moundsview, Saintpeter - each has 2 records with id = 0
    '   Waunakee has 12 with id = 0 - from two separate receipts
    '   all other dbs are 'non-site' dbs - most with similar 58,59 ids 
    '   Burnaby01 and LJSupport06 have many '0' id's
    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_GL_LEDGER__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   9 site dbs affected with id=0
    '   Ann Arbor, Cwpd, Dbparkrec, Lincolnshire, Moundsview, Wahoo all have 1
    '   Wahoo has 2
    '   Eauclaire has 10
    '   one non-site db  Burnaby07 has 1 

    '   Suspect a bug in some scenario of refunding to an account - INVESTIGATE?

    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_CUSTOMERACCOUNTS__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   1 db affected - Burnaby10 (in house db) missing id 68
    '
    ' Solution:
    '   insert default id for all problem records 
    Private Sub Fix_SYSTEMUSAGELOG__WORKSTATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub


    'Scope:
    '   3 non-site dbs affected - Burnaby01, Burnaby08, LJSupport06 all have id=0
    '
    ' Solution:
    '   insert default id for all problem records
    Private Sub Fix_ICVERIFYLOG__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   9 site db�s have 0�s and no sites have anything else so a BUG??
    '       BurlingtonRec, cabotparksandrecreation, Conroe, CVSC, Franklinparksandrecreation, 
    '       Grandtraverse, Newtonrec, Northlibertycommctr, Wahoo
    '   7 in house dbs have same problem
    '
    ' Solution:
    '   insert default id for all problem records
    Private Sub Fix_LOCKER_SCHEDULES__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   9 site dbs affected - all have different ids orphaned - some with just one, others with several
    '   MySwimClass has about 50 different ids orphaned
    '   Waunakee has only one orphan - it has id=0

    ' Solution:
    '   insert default id for all problem records
    Private Sub Fix_RSERVERLOG__WORKSTATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   2 dbs affected - 
    '       Cudahy      8 records for id = 15 
    '       Pvkansas    3 records for id = 12 
    '
    ' Solution:
    '   delete all the orhpaned records
    Private Sub Fix_PENDINGADDS__WORKSTATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID")

    End Sub

    'Scope:
    '   1 site db - FPDWC - 8 records with id = 0 
    '   all other dbs are 'non-site' dbs with 0�s
    '
    ' Solution:
    '   insert default id for all problem records
    Private Sub Fix_PRODUCTORDERS__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   24 dbs affected 
    '   Commerce has 11 records with id = 0
    '   all other dbs are 'non-site' dbs with similar number of missing id = 59
    '
    ' Solution:
    '   insert default id for all problem records
    Private Sub Fix_FACILITY_SCHEDULES__STATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID", miInternetWorkstationID)

    End Sub

    'Scope:
    '   no dbs affected yet - but put in just in case....
    '
    ' Solution:
    '   delete all the orhpaned records
    Private Sub Fix_TEAMPENDINGADDS__WORKSTATION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "WORKSTATIONS", "WORKSTATION_ID")

    End Sub

    'Scope:
    '   4 site dbs affected - Bremerton,Concordparksrec,LosBanos,Sunrise
    '   1 other db - LJSupport06
    '
    ' Solution:  
    '   set to the site associated with the activity/dcprogram
    Private Sub Fix_TRANSACTIONS__REVENUESITE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        Dim sFKRelationship As String = sChildTable & "__" & sFKeyField
        Dim sDesc As String = "Fixing " & sFKRelationship
        Dim iRecordsAffected As Integer

        Try
            If FixDRI_FKAlreadyImplemented(sChildTable, sFKeyField) Then
                Return
            End If

            Dim sSql As String = "update TRANSACTIONS set revenuesite_id = " & _
                    "(select ACTIVITIES.site_id from ACTIVITIES " & _
                    "where ACTIVITIES.activity_id = TRANSACTIONS.activity_id) " & _
                    "where TRANSACTIONS.activity_id is not null and " & _
                    "TRANSACTIONS.revenuesite_id not in (select site_id from SITES)"
            If mobDDDbConn.bExecuteSql(sSql, sDesc, iRecordsAffected) Then
                If iRecordsAffected > 0 Then
                    WriteToUpsizerLog(msIndent & iRecordsAffected & " activity transaction records updated")
                Else
                    WriteToUpsizerLog(msIndent & "No problem records found for any activity transaction")
                End If
            Else
                LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField _
                        & "......SQL = " & sSql, False)
            End If
            sSql = "update TRANSACTIONS set revenuesite_id = " & _
                    "(select DCPROGRAMS.site_id from DCPROGRAMS " & _
                    "where DCPROGRAMS.dcprogram_id = TRANSACTIONS.dcprogram_id) " & _
                    "where TRANSACTIONS.dcprogram_id is not null and " & _
                    "TRANSACTIONS.revenuesite_id not in (select site_id from SITES)"
            If mobDDDbConn.bExecuteSql(sSql, sDesc, iRecordsAffected) Then
                If iRecordsAffected > 0 Then
                    WriteToUpsizerLog(msIndent & iRecordsAffected & " dcprogram transaction records updated")
                Else
                    WriteToUpsizerLog(msIndent & "No problem records found for any dcprogram transaction")
                End If
            Else
                LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField _
                        & "......SQL = " & sSql, False)
            End If

        Catch ex As Exception
            LogUpsizeError("Fix_" & sFKRelationship & " - " & ex.Message & ".", False, ex.StackTrace)
        End Try
    End Sub

    'Scope:
    '   1 site db - ?? Fair Oaks Park  
    '
    ' Solution:
    '   replace with Internet site id
    Private Sub Fix_CENTERS__SITE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SITES", "SITE_ID", miInternetSiteID)

    End Sub

    'Scope:
    '   11 dbs  
    '
    ' Solution:
    '   replace with Internet site id
    Private Sub Fix_INSTRUCTORTYPES__SITE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SITES", "SITE_ID", miInternetSiteID)

    End Sub

    'Scope:
    '   13 dbs  
    '
    ' Solution:
    '   replace with Internet site id
    Private Sub Fix_PENDINGCUSTOMERS__SITE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SITES", "SITE_ID", miInternetSiteID)

    End Sub

    'Scope:
    '   1 site db - Fair Oaks Park  
    '
    ' Solution:
    '   replace with Internet site id
    Private Sub FIX_WORKSTATIONS__SITE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceIDs(sChildTable, sFKeyField, "SITES", "SITE_ID", miInternetSiteID)

    End Sub

    'Scope:
    '   1 dbs -  FPDWC - 1 record id = 40
    '
    ' Solution:
    '   set to null
    Private Sub Fix_COMPANIES__CUSTOMERTYPE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "CUSTOMERTYPES", "CUSTOMERTYPE_ID")

    End Sub

    'Scope:
    '   1 non-site db -  LJSupport - has 387 records with ids 9,10,11
    '
    ' Solution:
    '   set to null
    Private Sub Fix_CUSTOMERS__CUSTOMERTYPE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "CUSTOMERTYPES", "CUSTOMERTYPE_ID")

    End Sub

    'Scope:
    '   1 dbs - Southlake - 1 record for id = 3
    '
    ' Solution:
    '   set to null
    Private Sub Fix_FACILITYGROUPS__CUSTOMERTYPE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "CUSTOMERTYPES", "CUSTOMERTYPE_ID")

    End Sub

    'Scope:
    '   2 dbs -  Suisunrec - 9 for id 1, 3 for id 2 , 3 for id 3 , 10 for id 4 , 8 for id 5 
    '            WashingtonNCRec - 2 for id 5,  9 for id 6 
    '
    ' Solution:
    '   set to null
    Private Sub Fix_STANDARDCHARGES__CUSTOMERTYPE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "CUSTOMERTYPES", "CUSTOMERTYPE_ID")

    End Sub

    'Scope:
    '   1 site db -  LincolnLakes - LOTS of ids! max id = 687 for all activity_fees_id up to 2453
    '   4 other dbs - each has same common records
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_ACTIVITY_FEES__ACTIVITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "ACTIVITIES", "ACTIVITY_ID")

    End Sub

    'Scope:
    '   5 site dbs -  Brisbane, Colton, HesperiaParks, NorthCounty, Patterson all have lots of orphans
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_ACTIVITY_INSTRUCTORS__ACTIVITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "ACTIVITIES", "ACTIVITY_ID")

    End Sub

    'Scope:
    '   2 site dbs -  Aquaresource - 24 records, Sunrise 2 records
    '   1 in house -  LJSupport06 - 3 records
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_ACTIVITYCUSTOMQUESTIONS__ACTIVITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "ACTIVITIES", "ACTIVITY_ID")

    End Sub

    'Scope:
    '   9 site dbs -  not many records each - two have nulls
    '   1 in house -  Burnaby05 - 1 records
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_ATTACHEDCHECKLISTITEMS__ACTIVITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "ACTIVITIES", "ACTIVITY_ID")

    End Sub

    'Scope:
    '   1 in house -  Burnaby06 - 3 records
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_PENDINGADDS__ACTIVITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "ACTIVITIES", "ACTIVITY_ID")

    End Sub

    'Scope:
    '   1 site db -  Sunrise - 3 ids - 19 records each
    '   3 in house - LJSupport,02,03,04 - same 10 records each
    '
    ' Solution:
    '   set to null - INVESTIGATE - although set to cascade delete - cannot due to leagueschedulepairings???
    Private Sub Fix_FACILITY_SCHEDULES__ACTIVITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "ACTIVITIES", "ACTIVITY_ID")

    End Sub

    'Scope:
    '   4 site dbs -  RochesterCE, Rosemead, Sampsonco, Tollandrecreation
    '   1 in house - LJSupport06
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_TEAMS__ACTIVITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "ACTIVITIES", "ACTIVITY_ID")

    End Sub

    'Scope:
    '   2 site dbs -  Commerce 1 each of 8 sepearate ids, CPRD
    '   1 in house -  Burnaby08 - 1 records
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_ATTACHEDCHECKLISTITEMS__DCPROGRAM_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "DCPROGRAMS", "DCPROGRAM_ID")

    End Sub

    'Scope:
    '   2 site dbs -  Centralpointrec - 1 record, Oriontwp - 2 records
    '   2 in house dbs -  Burnaby08, LJSupport06 
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_DCPROGRAM_MAIL__DCPROGRAM_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "DCPROGRAMS", "DCPROGRAM_ID")

    End Sub

    'Scope:
    '   1 in house db - LJSupport06 BUG?? id of -1??
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_DCPROGRAMFEES__DCPROGRAM_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "DCPROGRAMS", "DCPROGRAM_ID")

    End Sub

    'Scope:
    '   11 site dbs - Colton, Cottagegrovemn, Frrpd, Mhrd, Oconomowoc, Pvrpd, RochesterCE, 
    '                 Rosevillemn, Seaside, Stephenvillerecdept (128 records with id=0), Venture
    '                 anywhere from 1 record to thousands per db
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_ACTIVITY_DATES__FACILITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "FACILITIES", "FACILITY_ID")

    End Sub

    'Scope:
    '   2 site dbs - few records each
    '       Beavercreek, Beaverdamrec, Conroe, Onondagacountyparks, Pvkansas, Snocoa 
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_FACILITY_MAIL__FACILITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "FACILITIES", "FACILITY_ID")

    End Sub

    'Scope:
    '   2 site dbs - 6 records each - 1 or 2 ids
    '       Conroe, Onondagacountyparks
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_FACILITYEVENTCAPACITY__FACILITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "FACILITIES", "FACILITY_ID")

    End Sub

    'Scope:
    '   1 site db - Centralpointrec - 1 record for each of 2 ids   
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_FACILITYGROUPFACILITIES__FACILITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "FACILITIES", "FACILITY_ID")

    End Sub

    'Scope:
    '   1 site db - Linolakes 1 record 
    '       
    ' Solution:
    '   delete the records
    Private Sub Fix_FACILITYOVERLAPROLLUP__OVERLAPFACILITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "FACILITIES", "FACILITY_ID")

    End Sub

    'Scope:
    '   1 site db - Linolakes 1 record 
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_FACILITYOVERLAPROLLUP__REALFACILITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "FACILITIES", "FACILITY_ID")

    End Sub

    'Scope:
    '   1 site db - Conroe - 5 records for 1 id
    '
    ' Solution:
    '   delete the records
    Private Sub Fix_FACILITYUSERS__FACILITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "FACILITIES", "FACILITY_ID")

    End Sub

    'Scope:
    '   5 site dbs -  CWPD,Dcparksandrec, Grandtraverse, Inghamcounty, Owatonna
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_STANDARDCHARGES__FACILITY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "FACILITIES", "FACILITY_ID")

    End Sub

    'Scope:
    '   1 in house db -  SacTest - team ids 1 thru 8 missing
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_LEAGUESCHEDULEPAIRINGS__AWAYTEAM_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "TEAMS", "TEAM_ID")

    End Sub

    'Scope:
    '   1 in house db -  SacTest - team ids 1 thru 8 missing
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_LEAGUESCHEDULEPAIRINGS__HOMETEAM_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "TEAMS", "TEAM_ID")

    End Sub

    'Scope:
    '   1 site db -  Fitchburg - 6 records with id = -1
    '   2 in house dbs -  Burnaby01,06 - missing ids = -1 (2, 5 records)
    '   the -1's must be a BUG!
    '
    ' Solution:
    '   delete the orphaned records 
    Private Sub Fix_PLAYERS__TEAM_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "TEAMS", "TEAM_ID")

    End Sub

    'Scope:
    '   9 site dbs -  Bremerton, Corinthrec, EDHCSD, Longmeadow, Onondagacountyparks
    '                 Rexburgparksandrec, Rosemead, Southwindsor, Sunrise
    '   1 in house db -  Burnaby01 
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_TEAMCONTACTS__TEAM_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "TEAMS", "TEAM_ID")

    End Sub

    'Scope:
    '   3 site dbs -  CPRD, Fortmorgan, RantoulRec
    '   1 in house db -  Burnaby08 
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_PACKAGECUSTOMQUESTIONS__PACKAGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "PACKAGES", "PACKAGE_ID")

    End Sub

    'Scope:
    '   1 in house db -  Burnaby10 
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_PACKAGE_FEES__PACKAGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "PACKAGES", "PACKAGE_ID")

    End Sub

    'Scope:
    '   1 in house db - Burnaby11 1 record for id 13 
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_MEMBERSHIPPREREQUISITES__PACKAGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "PACKAGES", "PACKAGE_ID")

    End Sub

    'Scope:
    '   1 in house db -  Burnaby10 
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_PACKAGE_ENTRY_POINTS__PACKAGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "PACKAGES", "PACKAGE_ID")

    End Sub

    'Scope:
    '   1 in house db - LJSupport06
    '
    ' Solution:
    '   delete orphaned record
    Private Sub Fix_POS_GROUP_PRODUCT_LINK__POSPRODUCT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "POSPRODUCTS", "POSPRODUCT_ID")

    End Sub

    'Scope:
    '   1 site db - Marinwood - missing 1 record for each of 6 ids
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_POSPRODUCTFEES__POSPRODUCT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "POSPRODUCTS", "POSPRODUCT_ID")

    End Sub

    'Scope:
    '   1 site db - Moundsview - missing id=2 for 90 records
    '   1 in house db - Burnaby08 - missing ids 3 and 4 (72 records each)
    '
    ' Solution:
    '   set to null
    Private Sub Fix_FACILITY_SCHEDULES__LEAGUESCHEDULE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "LEAGUESCHEDULES", "LEAGUESCHEDULE_ID")

    End Sub

    'Scope:
    '   1 site db - Moundsview - missing 1 record 
    '   1 in house db - Burnaby08 - missing 2 ids (6 records total)
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_LEAGUESCHEDULEFACILITIES__LEAGUESCHEDULE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "LEAGUESCHEDULES", "LEAGUESCHEDULE_ID")

    End Sub

    'Scope:
    '   1 site db - Moundsview - missing id '2' (72 records) 
    '   2 in house db - Burnaby06 - missing ids  '3', '4' (2 records each) 
    '                   Burnaby08 - missing ids  '0','37' (72 records each)
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_LEAGUESCHEDULEPAIRINGS__LEAGUESCHEDULE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "LEAGUESCHEDULES", "LEAGUESCHEDULE_ID")

    End Sub

    'Scope:
    '   1 site db - Moundsview - missing id 2 - 6 records 
    '   1 in house db - Burnaby08 - missing id 3 (12 records), 4 (6 records)
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_LEAGUESCHEDULETIMESLOTS__LEAGUESCHEDULE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "LEAGUESCHEDULES", "LEAGUESCHEDULE_ID")

    End Sub

    'Scope:
    '   1 in house db - Burnaby03 - ids 6,7,8
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_ATTACHEDCHECKLISTITEMS__EVENTTYPE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "EVENTTYPES", "EVENTTYPE_ID")

    End Sub

    'Scope:
    '   5 site dbs - FerndaleRec 2 records for id 12, Mabparksrec 1 for id 5, Onondagacountyparks 1 for id 42 
    '                Shelbyparks 5 records for id 4, Southwindsor 3 for id 2 
    '   1 in house db - Burnaby08 - 2 each for ids 4 and 5
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_EVENTTYPECUSTOMQUESTIONS__EVENTTYPE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "EVENTTYPES", "EVENTTYPE_ID")

    End Sub

    'Scope:
    '   5 site dbs - Estevan 1 record for 1d 4, FerndaleRec 5 records for id 7, Grantrec 410 for id 4,  
    '                Isleofwight 2 for id 10, TownofHighRiver 1 for id 4
    '   2 in house dbs - Burnaby03 - 3 each for ids 4 and 6, LJSupport06 8 7 
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_ATTACHEDCHECKLISTITEMS__STAGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "STAGES", "STAGE_ID")

    End Sub

    'Scope:
    '   1 site dbs - Bremerton 5,  Caldwell 1, Kennesaw 3, Minicourses 1, RochesterCE 5, 
    '                SCSLearn 38, Sunrise 265, Venture 1
    '   2 in house dbs - Burnaby08 1885, LJSupport06 1 
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_ACTIVITY_DATES__FACILITY_SCHEDULE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "FACILITY_SCHEDULES", "FACILITY_SCHEDULE_ID")

    End Sub

    'Scope:
    '   1 in house db - Burnaby08 - 1 record for each of 12 consecutive ids
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_DCSESSIONDATES__FACILITY_SCHEDULE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "FACILITY_SCHEDULES", "FACILITY_SCHEDULE_ID")

    End Sub

    'Scope:
    '   1 in house db - SacTest02 - 1 record each for lots of consecutive ids
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_LEAGUESCHEDULEPAIRINGS__FACILITYSCHEDULE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "FACILITY_SCHEDULES", "FACILITYSCHEDULE_ID")

    End Sub

    'Scope:
    '  no longer found in any db - due to missing primary key in FPDWC, not bad data
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_BULKEMAILATTACHMENTS__BULKEMAILTASK_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "BULKEMAILTASKS", "BULKEMAILTASK_ID")

    End Sub

    'Scope:
    '  no longer found in any db - due to missing primary key in FPDWC, not bad data
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_BULKEMAILRECIPIENTS__BULKEMAILTASK_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "BULKEMAILTASKS", "BULKEMAILTASK_ID")

    End Sub

    'Scope:
    '  no longer found in any db - due to missing primary key in FPDWC, not bad data
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_OPTOUTHISTORY__BULKEMAILTASK_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "BULKEMAILTASKS", "BULKEMAILTASK_ID")

    End Sub

    'Scope:
    '   1 site db - Sunrise - has about 30 instances - different missing ids
    '   1 in house db - Burnaby08 -  about 15 missing ids - and 14 '0' ids
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_ICVERIFYLOG__RECEIPTHEADER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "RECEIPTHEADERS", "RECEIPTHEADER_ID")

    End Sub

    'Scope:
    '   1 in house db -  Burnaby08 - id '0' 465 records, also  about 56 missing other ids - 1 record each
    '
    ' Solution:
    '   set to null  - but does not allow null until after the upsize!!
    Private Sub Fix_MEMBERSHIPAUTORENEWAL__RECEIPTHEADER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        'set to allow null here since column changed to allow null later on in this upsize run anyway
        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "RECEIPTHEADERS", "RECEIPTHEADER_ID", True)

    End Sub

    'Scope:
    '   1 in house db -  Burnaby08 - one record with an orhpan id
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_TRANSACTIONS__RECEIPTHEADER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "RECEIPTHEADERS", "RECEIPTHEADER_ID")

    End Sub

    'Scope:
    '   8 site dbs -  Cwpd, Genevieve, Howell, Oriontwp, Pvrpd, Rosevillemn, Seaside, Stephenvillerecdept
    '                 from 1 to 18 missing ids with 1 to over 500 records for each id
    ' Solution:
    '   set to null 
    Private Sub Fix_ACTIVITIES__SUPERVISOR_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "SUPERVISORS", "SUPERVISOR_ID")

    End Sub

    'Scope:
    '   16 site dbs - various numbers if missing ids
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_ACTIVITIES__PRIMARYINSTRUCTOR_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "INSTRUCTORS", "INSTRUCTOR_ID")

    End Sub

    'Scope:
    '   1 site db - CityOfParkland - 1 record for id = 2
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_ACTIVITIES__PREPCODE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "PREPCODES", "PREPCODE_ID")

    End Sub

    'Scope:
    '   6 site dbs - Frrpd 1 for id 15, Mhrd 2 for id 13, Pvrpd 1 for id 27, 15 for id 32, 4 for id 33,  
    '                RochesterCE 72 for id 87, Rosevillemn 15 for id 42 , Seaside 6 for id 7 
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_ACTIVITIES__RG_CATEGORY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "RG_CATEGORY", "RG_CATEGORY_ID")

    End Sub

    'Scope:
    '   10 site dbs - various number of ids missing with various numbers of records each
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_ACTIVITIES__SEASON_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "SEASONS", "SEASON_ID")

    End Sub

    'Scope:
    '  1 site db - Sunrise 36 records for id 7 
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_PROFILEOPTIONS__PROFILE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "PROFILES", "PROFILE_ID")

    End Sub

    'Scope:
    '   7 dbs have from 1 to 8 occurrences of id = 0 - how to fix?
    '       Brisbane 1, Burnaby10 1, FairOaksPark 7, Fortmorgan 8, 
    '       Howell 3, Middletonrec 1, RochesterCE 2 
    '
    ' Solution:
    '   ??create a dummy record with no options and assign it in place of the orphaned id?? 
    '   or delete the system user if not used ??  not very likely!
    '   or have the site manually go in and fix before upsizing??
    Private Sub Fix_SYSTEM_USERS__PROFILE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        'FixDRI_DeleteRecords(sChildTable, sFKeyField, "PROFILES", "PROFILE_ID")

    End Sub

    'Scope:
    '  no dbs currently affected - one was documented in the upsizererror logs
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_BULKEMAILACKNOWLEDGEMENTS__BULKEMAILRECIPIENT_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "BULKEMAILRECIPIENTS", "BULKEMAILRECIPIENT_ID")

    End Sub

    'Scope:
    '   1 site db - Fitchburg - 1 record for id 38 
    '   1 in house db - SacTest03 - 12 records total for 4 ids 
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_BULKEMAILATTACHMENTS__UPLOADEDFILE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "UPLOADEDFILES", "UPLOADEDFILE_ID")

    End Sub

    'Scope:
    '  1 in house db - LJSupport04 - hundreds of records for many missing ids
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_CUSTOMERS__GEOGRAPHIC_AREA_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "GEOGRAPHIC_AREAS", "GEOGRAPHIC_AREA_ID")

    End Sub

    'Scope:
    '   no longer found in any db - due to missing primary key in FPDWC, not bad data
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_CUSTOMLISTINCLUDES__REPORT_DEFINITION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "REPORTDEFINITION", "REPORTDEFINITION_ID")

    End Sub

    'Scope:
    '  2 site dbs - Brisbane 1 record for id 112, NorthCounty 1 record for id 23 
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_FACILITIES__FACILITYTYPE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "FACILITYTYPES", "FACILITYTYPE_ID")

    End Sub

    'Scope:
    '  1 in house db - Burnaby08 - 1 record each for ids 6,7
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_PACKAGES__PACKAGECATEGORY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "PACKAGE_CATEGORIES", "PACKAGECATEGORY_ID")

    End Sub

    'Scope:
    '  1 site db - Papillionrecdept 2 records for id 1 
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_PASSLAYOUTS__BACKGROUNDFILE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "UPLOADEDFILES", "UPLOADEDFILE_ID")

    End Sub

    'Scope:
    '  2 site dbs - Concordparksrec 1 record for id 10, Papillionrecdept 2 records for id 1 
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_PASSLAYOUTS__LOGOFILE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "UPLOADEDFILES", "UPLOADEDFILE_ID")

    End Sub

    'Scope:
    '  1 in house db - Burnaby08 - 12 cases of id = 0
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_DCSESSIONDATES__DCSESSION_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "DCSESSIONS", "DCSESSION_ID")

    End Sub

    'Scope:
    '  it should allow nulls - most records have id = 0
    '
    ' Solution:
    '   set to null
    Private Sub Fix_POSPRODUCTS__UPLOADEDFILE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        'change column to allow null, then replace the orphaned records with null
        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "UPLOADEDFILES", "UPLOADEDFILE_ID", True)

    End Sub

    'Scope:
    '   Caldwell 1 record , CityOfParkland 4 records - for first records in system
    '
    ' Solution:
    '   set to null
    Private Sub Fix_RECEIPTPAYMENTS__CARDTYPE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "CARDTYPES", "CARDTYPE_ID")

    End Sub

    'Scope:
    '  3 site dbs - Corinthrec '5,'6' - Oconomowoc '5', Southorange '16'
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_STAGES__UPLOADEDFILE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "UPLOADEDFILES", "UPLOADEDFILE_ID")

    End Sub

    'Scope:
    '   Ccparksandrec,Commerce,Frrpd,Newtonrec,Petalumarec,Roanokerec,Tigard
    '   Burnaby01,LJSupport03,06
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_STAGESEQUENCESTAGEDETAILS__DETAILCHILD_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "STAGESEQUENCESTAGES", "STAGESEQUENCESTAGE_ID")

    End Sub

    'Scope:
    '   Ccparksandrec,Commerce,Frrpd,Newtonrec,Petalumarec,Roanokerec,Tigard
    '   LJSupport03,06
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_STAGESEQUENCESTAGEDETAILS__STAGESEQUENCESTAGE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "STAGESEQUENCESTAGES", "STAGESEQUENCESTAGE_ID")

    End Sub

    'Scope:
    '  1 in house db - LJSupport06 - 3 records for id 32 
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_STAGESEQUENCESTAGES__STAGESEQUENCE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "STAGESEQUENCES", "STAGESEQUENCE_ID")

    End Sub

    'Scope:
    '   only 11 sites have records with valid ids - rest have 0�s ?it should allow null
    '
    ' Solution:
    '   set to null after changing db column to allow it - as will get done later in the upsize anyway
    Private Sub Fix_WORKSTATIONS__FACILITYGROUP_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        'set to null first if necessary
        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "WORKSTATIONS", "FACILITYGROUP_ID", True)

    End Sub

    'Scope:
    '  1 site db - FPDWC - due to missing primary key, not bad data
    '
    ' Solution:
    '   set to null 
    Private Sub Fix_LEAGUESCHEDULEPAIRINGS__POSTPONEREASON_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_ReplaceWithNulls(sChildTable, sFKeyField, "POSTPONEREASONS", "POSTPONEREASON_ID")

    End Sub

    'Scope:
    '  11 in house dbs - all hve 40 occurrences of 0's
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_LOCKERFEES__LOCKERGROUP_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "LOCKERGROUPS", "LOCKERGROUP_ID")

    End Sub

    'Scope:
    '  1 site db - FPDWC - due to missing primary key, not bad data
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_ACTIVITYSKILL__SKILL_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "SKILLS", "SKILL_ID")

    End Sub

    'Scope:
    '  1 site db - FPDWC - due to missing primary key, not bad data
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_INSTRUCTORSKILL__SKILL_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "SKILLS", "SKILL_ID")

    End Sub

    'Scope:
    '  1 site db - FPDWC - due to missing primary key, not bad data
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_OFFICIALSKILL__SKILL_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "SKILLS", "SKILL_ID")

    End Sub

    'Scope: 
    '  LJSupport04 - 1 record each for ids 40 and 81 - not from merge
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARSCHEDULEDETAIL__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '  Burnaby10 - 4 records for id 0, LJSupport06 - 4 for 0, SacTest03 - 10  for 0 -- not from merge
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARSCHEDULEHEADER__AUTO_PAY_FOR_CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   LJSupport04 - 1 record each for ids 40 and 81 -- not from merge
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARSCHEDULEHEADER__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   AARecEd, FairOaksPark, SCSLearn, Sunrise, LJSupport, 02,03 - all from merge
    '   LJSupport04 - 2 record each for ids 40 and 81 -- not from merge
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARTRANSACTIONS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '   Sunrise - from merge
    '   LJSupport04 - 2 record each for ids 40 and 81 -- not from merge  
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_ARTRANSACTIONS__TRANSACTIONCUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope: 
    '  1. Having BulkEmailRecipients.customer_id = 0
    '  2. Having BulkEmailRecipients.customer_id = some customer_id that is no longer existed.
    '
    'Solutions:
    '  1. Change all customer_id = 0 => null
    '  2. Search for customer_id that are no longer valid in PopulationConsolidationLog and find out the new customer_id
    Private Sub Fix_BULKEMAILRECIPIENTS__CUSTOMER_ID(ByVal sChildTable As String, _
                                                     ByVal sFKeyField As String)

        Dim sFKRelationship As String = sChildTable & "__" & sFKeyField
        Dim sDesc As String = "Fixing " & sFKRelationship
        Dim iRecordsAffected As Integer

        Try
            If FixDRI_FKAlreadyImplemented(sChildTable, sFKeyField) Then
                Return
            End If

            ' Updating all 0 to null
            If mobDDDbConn.bExecuteSql("update " & sChildTable & " set " & sFKeyField & " = Null" _
                                        & " where " & sFKeyField & "=0", _
                                        sDesc, iRecordsAffected) Then
                WriteToUpsizerLog(msIndent & iRecordsAffected & _
                    " records updated to " & sFKeyField & " 'Null'")
            End If

            ' Fix invalid Customer_ID caused by customer consolidation
            FixDRI_Replace_Merged_CUSTOMER_ID(sChildTable, sFKeyField)

            ' Fix some special cases
            If mobDDDbConn.Database = "Newtonrec" Then
                If mobDDDbConn.bExecuteSql("delete from " & sChildTable & " where " & sFKeyField & " = 4853", sDesc, iRecordsAffected) Then
                    WriteToUpsizerLog(msIndent & iRecordsAffected & _
                        " records deleted for " & sFKeyField & " = 4853")
                Else
                    LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField, False)
                End If
            ElseIf mobDDDbConn.Database = "Onalaskaparkrec" Then
                If mobDDDbConn.bExecuteSql("delete from " & sChildTable & " where " & sFKeyField & " = 3762", sDesc, iRecordsAffected) Then
                    WriteToUpsizerLog(msIndent & iRecordsAffected & _
                        " records deleted for " & sFKeyField & " = 3762")
                Else
                    LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField, False)
                End If
            ElseIf mobDDDbConn.Database = "SacTest03" Then
                If mobDDDbConn.bExecuteSql("delete from " & sChildTable & " where " & sFKeyField & " not in (select customer_id from CUSTOMERS)", sDesc, iRecordsAffected) Then
                    WriteToUpsizerLog(msIndent & iRecordsAffected & _
                        " records deleted for " & sFKeyField & " = 3762")
                Else
                    LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField, False)
                End If
            End If
        Catch ex As Exception
            LogUpsizeError("Fix_" & sFKRelationship & " - " & ex.Message & ".", False, ex.StackTrace)
        End Try

    End Sub

    Private Sub FixDRI_AssignDropInCustomerID(ByVal sChildTable As String, ByVal sFKeyField As String)

        Dim iRecordsAffected As Integer = 1
        Dim sSql As String

        WriteToUpsizerLog(msIndent & "Assigning drop-in customer id to remaining orphan records")
        sSql = "update " & sChildTable & " set " & sFKeyField & " = " & miDropInCustomerID _
                & " where " & sFKeyField & " not in (select customer_id from CUSTOMERS)"
        If mobDDDbConn.bExecuteSql(sSql, "Assigning drop-in cusotmer id" & sChildTable, iRecordsAffected) Then
            WriteToUpsizerLog(msIndent & iRecordsAffected & " records updated to drop-in customer_id")
        Else
            LogUpsizeError(sChildTable & " table: failed assigning drop-in cusotmer id", False)
        End If

    End Sub

    Private Sub FixDRI_Replace_Merged_CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        Dim iRecordsAffected As Integer = 1
        Dim sSql As String = ""
        Dim bFirstTime As Boolean = True

        Do While (iRecordsAffected > 0)
            sSql = "update " & sChildTable & " set " & sFKeyField & "=(select newcustomer_id from POPULATIONCONSOLIDATIONLOG where mergedcustomer_id=" & sChildTable & "." & sFKeyField & ")" _
                                        & " where (" & sFKeyField & " > 0)" _
                                        & " AND " & sFKeyField & " not in (select customer_id from customers)" _
                                        & " AND " & sFKeyField & " in (select mergedcustomer_id from POPULATIONCONSOLIDATIONLOG)"
            If mobDDDbConn.bExecuteSql(sSql, "Fixing merged customer_id in table " & sChildTable, iRecordsAffected) Then
                If bFirstTime Or iRecordsAffected > 0 Then
                    bFirstTime = False
                    WriteToUpsizerLog(msIndent & iRecordsAffected & " records fixed using POPULATIONCONSOLIDATIONLOG table")
                End If
            Else
                LogUpsizeError(sChildTable & " table: failed replacing merged customer_id. SQL =" & sSql, False)
                Exit Do
            End If
        Loop

    End Sub

    'Scope:
    '   Athensrec 580 records for id 8696 - not from merge
    '   3 other dbs - 11 records total from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_MEMBERSHIP_USAGES__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   Athensrec 1 8696, Conroe 6 0 , Southorange 2 0 - not from merge
    '   10 dbswith records from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_MEMBERSHIPS__PRIMARYMEMBERCUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   lots from merge
    '   Conroe 2, Cwpd 1, Inghamcounty 1, Mabparksrec 1 - not from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_PASSES__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '  52 dbs
    '
    ' Solution:
    '   delete orphaned records
    Private Sub Fix_PENDINGCUSTOMERS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_DeleteRecords(sChildTable, sFKeyField, "CUSTOMERS", "CUSTOMER_ID")

    End Sub

    'Scope: 
    '   None of the following from the merge:
    '   Brisbane, CampCo, Cityofyankton, Colton, CPRD, Dbqparkrec, EDHCSD, Fitchburg, HesperiaParks,
    '   Moorhead, MySwimClass, NorthCounty, Oconee, Patterson, Phoenixgymnastics, Pvrpd, RochesterCE, 
    '   Rutgersrec, Sunrise
    '   And many in house dbs
    '
    'Solutions:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. Delete the other invalid records.

    Private Sub Fix_FAMILYMEMBERS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, True, False)

    End Sub

    'Scope: 
    '  8 site dbs - only  - only 4 records not fixed by merge  
    '       Oconee 3 7228, Petalumarec 1 -1 , Sunrise 1 40466 , TownofHighRiver 1 -1 
    '       the -1's must be a BUG!
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. Delete the other invalid records.
    Private Sub Fix_ICVERIFYLOG__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, True, False)

    End Sub

    'Scope:
    '   1 site db - AARecEd 1 12391 - from merge
    '   Not fixed by merge - Petalumarec - 2 records for id 0, LJSupport04 - 2 each of 10 different ids 
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. Delete the other invalid records.
    Private Sub Fix_PLAYERS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, True, False)

    End Sub

    'Scope:
    '   EDHCSD, LJSupport04, Sunrise all have some records not from merge
    '   4 other dbs all from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_RECEIPTPAYMENTS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   1 site db - Caldwell 1 4213 - from merge
    '   LJSupport04 1 32, 1 51 - not from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. Delete the other invalid records.
    Private Sub Fix_TEAMCONTACTS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, True, False)

    End Sub

    'Scope:
    '   AARecEd 1 , Athensrec 1 , Cityofepa, LJSupport04, Sunrise - with some records not from merge
    '   8 other dbs all from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_TRANSACTIONS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   1 site db - Sunrise - has some from merged customers and 14 from missing customers
    '   2 in house dbs - LJSupport02, LJSupport06 each have one missing id
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. Delete the other invalid records.
    Private Sub Fix_CUSTOMERLOGINS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)
        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, True, False)
    End Sub

    'Scope:
    '   The problems for all the site dbs are from merged customers
    '       AARecEd - 4 records for id 12391, 5 for id 40192 
    '       Chanhassen 1 for id 203, Gears 1 for id 607, Snoco 1 for id 9860  
    '
    '   The problems for in house dbs are missing ids
    '       LJSupport04 - 10 records - 1 each for different ids, LJSupport06 - 1 record
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. Delete the other invalid records.
    Private Sub Fix_CUSTOMER_MAIL__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, True, False)

    End Sub

    'Scope:
    '   lots of db from merge
    '   only 1 record from each of Eauclaire and Grandtraverse not from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. LEAVE the others for now
    Private Sub Fix_CUSTOMER_MEMBERSHIP_DATES__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   Brisbane and Caldwell each had one problem from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    Private Sub Fix_CUSTOMERS__LASTPAYEE_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   WashingtonNCRec, Waunakee each had one problem from merge 
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    Private Sub Fix_DELAYEDREFUNDS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   Sunrise, LJSupport03  all from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    Private Sub Fix_DCPICKUPAUTHORIZATIONS__PICKUPCUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    'Scope:
    '   Concordparksrec - one record from merge
    Private Sub Fix_CUSTOMERSCHOLARSHIP__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        FixDRI_Simple_CustomerID_CleanUP(sChildTable, sFKeyField, False, False)

    End Sub

    ' Fix invalid Customer_ID caused by customer consolidation
    ' Optionally, for remaining orphans:
    '   delete the records  OR 
    '   assign the drop-in customer_id
    Private Sub FixDRI_Simple_CustomerID_CleanUP(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                                 ByVal bDeleteInvalidRecords As Boolean, _
                                                 ByVal bUseDropInCustomer As Boolean)

        Dim sFKRelationship As String = sChildTable & "__" & sFKeyField
        Dim sDesc As String = "Fixing " & sFKRelationship
        Dim iRecordsAffected As Integer
        Dim iOrphanCount As Integer = 0

        Try
            If FixDRI_FKAlreadyImplemented(sChildTable, sFKeyField) Then
                Return
            End If

            ' Fix invalid Customer_ID caused by customer consolidation
            FixDRI_Replace_Merged_CUSTOMER_ID(sChildTable, sFKeyField)

            If bDeleteInvalidRecords Then
                ' Delete records that are not valid
                If mobDDDbConn.bExecuteSql("delete from " & sChildTable & " where " & sFKeyField & " not in (select customer_id from CUSTOMERS)", sDesc, iRecordsAffected) Then
                    If iRecordsAffected > 0 Then
                        WriteToUpsizerLog(msIndent & iRecordsAffected & " records deleted for invalid " & sFKeyField)
                    Else
                        WriteToUpsizerLog(msIndent & "No further problem records found")
                    End If
                Else
                    LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField, False)
                End If
            End If

            If bUseDropInCustomer Then
                FixDRI_AssignDropInCustomerID(sChildTable, sFKeyField)
            ElseIf Not bDeleteInvalidRecords Then
                iOrphanCount = FixDRI_GetOrphanCount(sChildTable, sFKeyField, "CUSTOMERS", "CUSTOMER_ID")
                If iOrphanCount > 0 Then
                    WriteToUpsizerLog(msIndent & iOrphanCount & _
                        " records cannot be fixed using the POPULATIONCONSOLIDATIONLOG table")
                End If

            End If

        Catch ex As Exception
            LogUpsizeError("Fix_" & sFKRelationship & " - " & ex.Message & ".", False, ex.StackTrace)
        End Try
    End Sub

    'Scope:
    '   LJSupport04 - not from merge
    '
    'Solution:
    '  1. Replace with correct id if old customer_id is merged.
    '  2. Delete renaing records after deleting CustomQuestionAnswers.
    Private Sub Fix_CUSTOMER_DEMOGRAPHICS__CUSTOMER_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        Dim sFKRelationship As String = sChildTable & "__" & sFKeyField
        Dim sDesc As String = "Fixing " & sFKRelationship
        Dim iRecordsAffected As Integer

        Try
            If FixDRI_FKAlreadyImplemented(sChildTable, sFKeyField) Then
                Return
            End If

            ' Fix invalid Customer_ID caused by customer consolidation
            FixDRI_Replace_Merged_CUSTOMER_ID(sChildTable, sFKeyField)

            ' Delete answer records that are associated with invalid customer_demographic records 
            If mobDDDbConn.bExecuteSql("delete from CustomQuestionAnswers where customer_demographics_id in (select customer_demographics_id from " & sChildTable & " where " & sFKeyField & " not in (select customer_id from CUSTOMERS))", sDesc, iRecordsAffected) Then
                WriteToUpsizerLog(msIndent & iRecordsAffected & _
                            " records deleted for associating with customer_demographics record that have invalid customer_ID")
            Else
                LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField, False)
            End If

            ' Delete records that are not valid
            If mobDDDbConn.bExecuteSql("delete from " & sChildTable & " where " & sFKeyField & " not in (select customer_id from CUSTOMERS)", sDesc, iRecordsAffected) Then
                WriteToUpsizerLog(msIndent & iRecordsAffected & _
                            " records deleted for invalid " & sFKeyField)
            Else
                LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField, False)
            End If

        Catch ex As Exception
            LogUpsizeError("Fix_" & sFKRelationship & " - " & ex.Message & ".", False, ex.StackTrace)
        End Try
    End Sub

    ' Fix orphaned Company_ID caused by company consolidation
    ' Optionally, for remaining orphans:
    '   delete the records  OR  - not implemented at this point
    '   assign the dummy company_id - not implemented at this point
    Private Sub FixDRI_Simple_CompanyID_CleanUP(ByVal sChildTable As String, ByVal sFKeyField As String, _
                                                ByVal bDeleteOrphanRecords As Boolean, _
                                                ByVal bUseDummyCompany As Boolean)

        Dim sFKRelationship As String = sChildTable & "__" & sFKeyField
        Dim sDesc As String = "Fixing " & sFKRelationship
        Dim iRecordsAffected As Integer
        Dim iOrphanCount As Integer = 0

        Try
            If FixDRI_FKAlreadyImplemented(sChildTable, sFKeyField) Then
                Return
            End If

            ' Fix orphaned Company_ID caused by company consolidation
            FixDRI_Replace_Merged_COMPANY_ID(sChildTable, sFKeyField)

            'If bDeleteOrphanRecords Then
            '    ' Delete records that are not valid
            '    If mobDDDbConn.bExecuteSql("delete from " & sChildTable & " where " & sFKeyField _
            '        & " not in (select company_id from COMPANIES)", sDesc, iRecordsAffected) Then
            '        WriteToUpsizerLog(msIndent & iRecordsAffected & _
            '                    " records deleted for invalid " & sFKeyField)
            '    Else
            '        LogUpsizeError(sChildTable & " table: failed fixing data for " & sFKeyField, False)
            '    End If
            'End If

            If bUseDummyCompany Then
                'FixDRI_AssignDummyCompanyID(sChildTable, sFKeyField)
            ElseIf Not bDeleteOrphanRecords Then
                iOrphanCount = FixDRI_GetOrphanCount(sChildTable, sFKeyField, "COMPANIES", "COMPANY_ID")
                If iOrphanCount > 0 Then
                    WriteToUpsizerLog(msIndent & iOrphanCount & _
                        " records cannot be fixed using the COMPANYCONSOLIDATIONLOG table")
                End If

            End If

        Catch ex As Exception
            LogUpsizeError("Fix_" & sFKRelationship & " - " & ex.Message & ".", False, ex.StackTrace)
        End Try
    End Sub

    Private Sub FixDRI_Replace_Merged_COMPANY_ID(ByVal sChildTable As String, ByVal sFKeyField As String)

        Dim iRecordsAffected As Integer = 1
        Dim sSql As String = ""
        Dim bFirstTime As Boolean = True

        'there are strange cases in the log table for several sites where the new and merged 
        'company ids are the same causing endless loop if that id happens to be orphaned in another table
        'unless these records are ignored in the log table - attempt made in sql below to do that
        'why? no idea - possible BUG to be investigated - btw, this does not occur in population consolidation log

        Do While (iRecordsAffected > 0)
            sSql = "update " & sChildTable & " set " & sFKeyField _
                    & "=(select newcompany_id from COMPANYCONSOLIDATIONLOG where mergedcompany_id =" _
                    & sChildTable & "." & sFKeyField & ")" _
                    & " where (" & sFKeyField & " > 0)" _
                    & " AND " & sFKeyField & " not in (select company_id from companies)" _
                    & " AND " & sFKeyField & " in" _
                    & " (select mergedcompany_id from COMPANYCONSOLIDATIONLOG where " _
                    & " (newcompany_id > mergedcompany_id OR newcompany_id < mergedcompany_id))" '  <--ignore strange records

            If mobDDDbConn.bExecuteSql(sSql, "Fixing merged company_id in table " & sChildTable, iRecordsAffected) Then
                If bFirstTime Or iRecordsAffected > 0 Then
                    bFirstTime = False
                    WriteToUpsizerLog(msIndent & iRecordsAffected & " records fixed using COMPANYCONSOLIDATIONLOG table")
                End If
            Else
                LogUpsizeError(sChildTable & " table: failed replacing merged company_id. SQL =" & sSql, False)
                Exit Do
            End If
        Loop

    End Sub

#End Region

#Region "IDisposable Support"
    'Clean up code for COM. When Upsize is called from VB6 the memory it acquires is
    'is not released. Garbage collection has to be specifically initiated

    Protected Overridable Overloads Sub Dispose( _
    ByVal disposing As Boolean)
        If Not Me.disposed Then
            If disposing Then
                If mobTargetDDManager IsNot Nothing Then
                    mobTargetDDManager.Dispose()
                End If
                If mobSourceDDManager IsNot Nothing Then
                    mobSourceDDManager.Dispose()
                End If
                If mobDDDbConn IsNot Nothing Then
                    mobDDDbConn.Dispose()
                End If
                If mobClientMsgSender IsNot Nothing Then
                    mobClientMsgSender = Nothing
                End If
                If mobErrorCol IsNot Nothing Then
                    mobErrorCol.Dispose()
                End If
                If moAppLogger IsNot Nothing Then
                    moAppLogger.Dispose()
                End If
                System.GC.Collect()
            End If
        End If
        Me.disposed = True
    End Sub
    'Call this before destroying the AnUpsizerLib object in VB6 code
    Public Overloads Sub Dispose() Implements IDisposable.Dispose
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub

    Protected Overrides Sub Finalize()
        Dispose(False)
        MyBase.Finalize()
    End Sub
#End Region
End Class

