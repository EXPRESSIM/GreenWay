Public Class DDIndex

#Region " Declarations "

    Dim moDDTable As DDTable
    Dim msIndexName$ = ""
    Dim mbUnique As Boolean
    Dim msExpression$ = ""
    Dim msIndexStatement$   'The sql to create the index
    Dim msTableName$

#End Region

#Region " Constructors "

    ' Construct from XML
    Friend Sub New(ByVal oDDTable As DDTable, ByVal oDomDoctor As XMLDomDoctor)
        moDDTable = oDDTable

        'Init the column by reading XML
        msExpression = oDomDoctor.GetAttribute("Expression")
        Dim stUnique$ = oDomDoctor.GetAttribute("Unique", False)
        mbUnique = CBool(IIf(stUnique <> "", True, False))
    End Sub

    ' Construct from DB schema
    Friend Sub New(ByVal oDDTable As DDTable, _
        ByVal IndexName$, _
        ByVal Unique As Boolean, _
        ByVal Expression$)

        moDDTable = oDDTable
        msIndexName = IndexName
        mbUnique = Unique
        msExpression = Expression
    End Sub

    ' ANE-12089 Construct from Index Statement
    Friend Sub New(ByVal oDomDoctor As XMLDomDoctor)
        msIndexName = oDomDoctor.GetAttribute("Name")
        msTableName = oDomDoctor.GetAttribute("Table")
        mbUnique = True
        'Get the statement
        Me.msIndexStatement = oDomDoctor.GetSimpleNodeText("Statement", True)
    End Sub

#End Region

#Region " Properties "

    Public ReadOnly Property DDTable() As DDTable
        Get
            Return moDDTable
        End Get
    End Property

    Public ReadOnly Property IndexName() As String
        Get
            If msIndexName = "" Then
                msIndexName = Me.moDDTable.TableName & "__" & msExpression
                msIndexName = HelperFuncs.ReplaceDelimiters(msIndexName, ",", "_")
                Return msIndexName.Trim.ToUpper
            Else
                Return msIndexName.Trim.ToUpper
            End If
        End Get
    End Property

    Public ReadOnly Property Unique() As Boolean
        Get
            Return mbUnique
        End Get
    End Property

    ' This is the Key for the collection
    Public Property Expression() As String
        Get
            Return msExpression.Trim.ToUpper
        End Get

        ' To allow DDTable to build up expression
        Friend Set(ByVal value As String)
            msExpression = value.Trim.ToUpper
        End Set
    End Property

#End Region

#Region " Upsizer support "

    ' Return whether a particular column is used in an index
    Public ReadOnly Property UsesColumn(ByVal sColumn$) As Boolean
        Get
            'We need to strip out the column name from the expression to compare
            Dim colTokens As Generic.List(Of String) = HelperFuncs.ParseToCollection(UCase(Me.Expression), ",")

            For Each sCol As String In colTokens
                If sCol = sColumn Then
                    Return True
                End If
            Next

            Return False
        End Get

    End Property

    ' Create new index
    Friend Function CreateIndex(ByVal oDDTableTarget As DDTable) As Boolean
        ' ANE-12089 if index Statement is not null, then execute it.
        If msIndexStatement <> "" Then
            oDDTableTarget.DDManager.DDDBConn.bExecuteSql(msIndexStatement, "Creating customer's index " & Me.IndexName)
            Return True
        End If

        Dim sSql$ = ""
        Dim oDdIndexTarget As DDIndex

        sSql = "create " & IIf(Me.Unique, "unique ", "").ToString & "index " & Me.IndexName & " on " & oDDTableTarget.TableName & _
            " (" & Me.Expression & ")"
        If oDDTableTarget.DDManager.DDDBConn.bExecuteSql(sSql, "Creating unique index " & Me.IndexName) Then

            oDdIndexTarget = New DDIndex(oDDTableTarget, Me.IndexName, Me.Unique, Me.Expression)
            oDDTableTarget.Indexes.Add(oDdIndexTarget.Expression, oDdIndexTarget)

            Return True
            ' If failed to create a unique index, try a non-unique one
        Else
            If Me.Unique Then

                sSql = "create index " & Me.IndexName & " on " & oDDTableTarget.TableName & _
                    " (" & Me.Expression & ")"
                If oDDTableTarget.DDManager.DDDBConn.bExecuteSql(sSql, "Creating index " & Me.IndexName) Then

                    oDdIndexTarget = New DDIndex(oDDTableTarget, Me.IndexName, Me.Unique, Me.Expression)

                    oDDTableTarget.Indexes.Add(oDdIndexTarget.Expression, oDdIndexTarget)

                    Me.DDTable.DDManager.UpsizerLibParent.LogUpsizeError(Me.IndexName & " on table " & _
                        Me.DDTable.TableName & " was created, but not as a unique index", False)
                    Return True
                End If
            End If
        End If

    End Function

    ' Drop existing index
    Friend Function DropIndex() As Boolean
        ' ANE-12089 if statement is null, then don't delete the index
        ' If msIndexStatement Is Nothing Then
        ' Return True
        'End If

        Return Me.DDTable.DDManager.DDDBConn.bExecuteSql("drop index " & _
            Me.DDTable.TableName & "." & Me.IndexName, "Dropping index " & Me.IndexName)
    End Function

    ' upsize the customer's index
    ' 
    Public Sub Upsize(ByVal oDDManagerTarget As DDManager, ByVal obDDIndexTarget As DDIndex)
        ' If the index already exists, first delete this index
        If Not obDDIndexTarget Is Nothing Then
            oDDManagerTarget.DDDBConn.bExecuteSql("drop index " & _
             Me.msTableName & "." & Me.msIndexName, "Dropping index " & Me.IndexName)
        End If

        If Not oDDManagerTarget.DDDBConn.bExecuteSql(msIndexStatement, "Creating customer's index " & Me.IndexName) Then
            Throw New Exception("Could not execute " & msIndexStatement)
        End If
    End Sub

#End Region
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class
