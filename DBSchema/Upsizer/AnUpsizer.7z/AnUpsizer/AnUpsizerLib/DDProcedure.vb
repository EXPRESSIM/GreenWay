Public Class DDProcedure
#Region " Declarations "

    Dim moDDManager As DDManager
    Dim msProcedureName$       ' Name of procedure
    Dim msPrefix$              ' Prefix to get fully qualified procedure name
    Dim mbHasParameters As Boolean        ' Whether the XML specified a parameters collection (old style)
    Dim msExecuteStatement$    ' The sql for the procedure to execute
    Dim mdicParameters As Generic.Dictionary(Of String, DDParameter)
#End Region

#Region " Constructors "

    ' Construct from DB schema
    Friend Sub New(ByVal oDDManager As DDManager, ByVal ProcedureName$)
        oDDManager = oDDManager
        msProcedureName = ProcedureName
    End Sub

    ' Construct from XML
    Friend Sub New(ByVal oDDManager As DDManager, ByVal oDomDoctor As XMLDomDoctor)
        Dim bFound As Boolean

        moDDManager = oDDManager

        ' Get procedure-level data
        msProcedureName = oDomDoctor.GetAttribute("Name")
        ' See if there is a parameters collection
        mbHasParameters = oDomDoctor.GetFirstNode("Parameters")
        If mbHasParameters Then
            bFound = oDomDoctor.GetFirstNode("Parameter")
            While bFound
                Dim oProcedureParam As DDParameter = New DDParameter(oDomDoctor.GetAttribute("Name"), oDomDoctor.GetAttribute("DataType"), CBool(oDomDoctor.GetAttribute("Output")))
                Me.Parameters.Add(oProcedureParam.ParameterName, oProcedureParam)
                bFound = oDomDoctor.GetNextNode("Parameter")
            End While
            oDomDoctor.Pop()
        End If

        'Get the sql
        Me.ExecuteStatement = oDomDoctor.GetSimpleNodeText("Statement", True)
    End Sub
#End Region
#Region " Properties "

    Public Property ExecuteStatement() As String
        Get
            Return msExecuteStatement
        End Get
        Set(ByVal value As String)
            msExecuteStatement = value
        End Set
    End Property

    Public Property ProcedureName() As String
        Get
            Return msProcedureName
        End Get
        Set(ByVal value As String)
            msProcedureName = value
        End Set
    End Property

    Public ReadOnly Property Parameters() As Generic.Dictionary(Of String, DDParameter)
        Get
            If mdicParameters Is Nothing Then
                mdicParameters = New Generic.Dictionary(Of String, DDParameter)
                Return mdicParameters
            Else
                Return mdicParameters
            End If
        End Get
    End Property
#End Region

    Public Sub Upsize(ByVal oDDManagerTarget As DDManager, ByVal obDDProcedureTarget As DDProcedure)
        Dim oSb As New Text.StringBuilder
        ' Old-style, with Parameters collection
        If mbHasParameters Then
            ' If procedure already exists, do an ALTER rather than CREATE
            If Not obDDProcedureTarget Is Nothing Then
                oSb.Append("alter")
            Else
                oSb.Append("create")
            End If
            oSb.Append(" procedure ").Append(Me.ProcedureName).Append(" ")
            For Each oParameter As DDParameter In Me.Parameters.Values
                oSb.Append(vbCrLf).Append(vbTab).Append(oParameter.ParameterName).Append(" ").Append(oParameter.DataType).Append(IIf(oParameter.IsOutput, " output,", ","))
            Next
            oSb.Remove(oSb.Length - 1, 1)
            oSb.Append(vbCrLf).Append("as ").Append(Me.ExecuteStatement)
            If Not oDDManagerTarget.DDDBConn.bExecuteSql(oSb.ToString, "Creating procedure " & Me.ProcedureName) Then
                Throw New Exception("Could not execute " & oSb.ToString)
            End If

            ' New style, with parameters in <STATEMENT>
        Else
            ' If procedure already exists, do an change "CREATE PROCEDURE" to "ALTER PROCEDURE"
            oSb.Append(Me.ExecuteStatement)
            If Not obDDProcedureTarget Is Nothing Then
                Dim sTemp As String = Me.ExecuteStatement.ToLower
                Dim iPos As Int32 = sTemp.IndexOf("create procedure")
                If iPos < 0 Then
                    Throw New Exception("For procedure " + Me.ProcedureName + " no 'create procedure' was found")
                End If
                oSb.Remove(iPos, 6)
                oSb.Insert(iPos, "alter")
            End If
            If Not oDDManagerTarget.DDDBConn.bExecuteSql(oSb.ToString, "Creating procedure " & Me.ProcedureName) Then
                Throw New Exception("Could not execute " & oSb.ToString)
            End If
        End If
    End Sub

End Class
