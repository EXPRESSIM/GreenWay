Imports AnUpsizerLib.AnEnums

Public Class claUpsizerTest

    Dim moDDDbConn As DDDbConn
    Dim msUser$
    Dim msServer$
    Dim msPwd$
    Dim msErdXMLPath$
    Dim moClientMsgSender As ClientMsgSender
    Dim moUpsizer As claUpsizer
    Dim mbLogSQL As Boolean
    Dim msLogPath$
    Dim mblnLogToDB As Boolean

    'Constructor for Test upsizer
    Public Sub New(ByVal sServer$, ByVal sUser$, ByVal sPwd$, ByVal sTestERDXMLPath$, _
            ByVal oClientMsgSender As ClientMsgSender, ByVal bLogSQL As Boolean, ByVal sLogPath$, ByVal blnLogToDB As Boolean)

        mbLogSQL = bLogSQL
        moClientMsgSender = oClientMsgSender
        'Used for messaging
        moUpsizer = New claUpsizer(moClientMsgSender, bLogSQL)
        msServer = sServer
        msUser = sUser
        msPwd = sPwd
        msErdXMLPath = sTestERDXMLPath
        moDDDbConn = CreateTestDB(mbLogSQL)
        msLogPath = sLogPath
        mblnLogToDB = blnLogToDB
    End Sub

    '****************************
    'Logging stuff for Test class
    '***************************

    'Send Error to client
    Private Sub LogUpsizeError(ByVal sFormat$, ByVal ParamArray sParams$())
        moClientMsgSender.SendErrorMsg(String.Format(sFormat, sParams))
    End Sub

    'Send Status msg to client
    Private Sub UpdateStatusMsg(ByVal StatusMsg$, ByVal Level As claUpsizer.StatusMsgLevel)
        moClientMsgSender.SendStatusMsg(StatusMsg, Level)
    End Sub

    Public Sub Dotest()
        Try

            UpdateStatusMsg("Initial Creation Test", claUpsizer.StatusMsgLevel.Level_1)
            InitialCreationTest()

            UpdateStatusMsg("Column Test", claUpsizer.StatusMsgLevel.Level_1)
            ColumnTest()

            UpdateStatusMsg("Index Test", claUpsizer.StatusMsgLevel.Level_1)
            IndexTest()

            UpdateStatusMsg("Relations Test", claUpsizer.StatusMsgLevel.Level_1)
            RelationsTest()

        Catch ex As Exception
            LogUpsizeError("Uncaught exception: {0}", ex.ToString)

        Finally
            If moDDDbConn IsNot Nothing Then moDDDbConn.DbConnection.Dispose()
        End Try
    End Sub

    Private Sub InitialCreationTest()
        Upsize(True, False, False)
        CheckFullyCompliant()
    End Sub

    ' Upsize the database
    Private Function Upsize(ByVal bImplementDRI As Boolean, ByVal bDropObsoleteData As Boolean, _
            ByVal bErrorsExpected As Boolean) As Boolean
        Dim oUpsizer As claUpsizer = New claUpsizer(moDDDbConn.DbConnection, msErdXMLPath, bImplementDRI, bDropObsoleteData, _
            False, moClientMsgSender, mbLogSQL, msLogPath, mblnLogToDB)
        Dim oErrors As AnUpsizerErrCol = Nothing
        Try
            oErrors = oUpsizer.Upsize()
        Catch ex As Exception
        Finally
            If Not oUpsizer Is Nothing Then
                oUpsizer.Dispose()
            End If
        End Try
        Return Not oErrors.HasFatal
    End Function

    Private Function CreateTestDB(ByVal LogSQL As Boolean) As DDDbConn

        Dim bDbFound As Boolean
        Dim obRs As ACS.DataAccess.claRecordSet = Nothing
        Dim obMasterConnection As ACS.DataAccess.claConnection = Nothing
        Dim obUpsizerTestConnection As ACS.DataAccess.claConnection = Nothing

        'Create Master connection
        obMasterConnection = ACS.DataAccess.claConnectionFactory.CreateSqlConnection(msServer, _
            "Master", msUser, msPwd, False)

        Using obMasterConnection

            Try
                obRs = obMasterConnection.OpenRecordset("execute sp_databases")

                Do While obRs.Read
                    If obRs.IDataReader_Item("DataBase_Name").ToString = "UPSIZERTEST" Then
                        'Set flag to drop
                        bDbFound = True
                        Exit Do
                    End If
                Loop

            Finally
                If obRs IsNot Nothing Then obRs.Dispose()
            End Try

            If bDbFound Then
                'Drop this DB
                Try
                    obMasterConnection.Execute("Drop Database UpsizerTest")
                Catch ex As Exception
                    'Bail out and display the error
                    Throw New Exception("Could not drop UpsizerTest because it is probably in use")
                End Try

            End If

            'Create a new one
            obMasterConnection.Execute("create database UpsizerTest")

            'Frees any resources to Master DB
        End Using

        'And return a connection to that DB
        obUpsizerTestConnection = ACS.DataAccess.claConnectionFactory.CreateSqlConnection(msServer, _
            "UpsizerTest", msUser, msPwd, False)

        Return New DDDbConn(obUpsizerTestConnection, moUpsizer, LogSQL)

    End Function

    ' Check all upsizing models for data type changes
    Private Sub ColumnTest()

        ' Check that if a column or table is dropped, it gets readded
        DropTable("PreventOptional")
        DropColumn("Parent", "c_bit")
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()

        ' Shrink columns and confirm they're put back
        AlterColumn("Parent", "c_money", "int not null", "0")
        AlterColumn("Parent", "c_int", "smallint not null", "0")
        AlterColumn("Parent", "c_varchar", "varchar(5) not null", "' '")
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()

        AlterColumn("Parent", "c_money", "smallint not null", "0")
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()

        ' Add some columns, and expand some, and test they're not thrown away
        AddTable("Added", "keycol int")
        AddColumn("Parent", "added", "int not null default 0")
        AlterColumn("Parent", "c_varchar", "varchar(20) not null", "' '")
        AlterColumn("Parent", "c_smallint", "int not null", "0")
        AlterColumn("Parent", "c_int", "money not null", "0")
        If Not Upsize(True, False, False) Then Exit Sub
        CheckTableExists("Added")
        CheckColumn("Parent", "c_varchar", "varchar", 20, False, False, "' '")
        CheckColumn("Parent", "c_smallint", "int", 0, False, False, "0")
        CheckColumn("Parent", "c_int", "money", 0, False, False, "0")

        ' Now upsize with drop obsolete data
        If Not Upsize(True, True, False) Then Exit Sub
        CheckFullyCompliant()
        CheckTableGone("Added")
        CheckColumnGone("Parent", "Added")

        ' A few more expansion checks
        AlterColumn("Parent", "c_smallint", "money not null", "0")
        AlterColumn("Parent", "c_varchar2", "text not null", "' '")
        AlterColumn("Parent", "c_text", "varchar(20) not null", "' '")
        If Not Upsize(True, False, False) Then Exit Sub
        CheckColumn("Parent", "c_smallint", "money", 0, False, False, "0")
        CheckColumn("Parent", "c_varchar2", "text", 0, False, False, "' '")
        CheckColumn("Parent", "c_text", "text", 0, False, False, "' '")
        If Not Upsize(True, True, False) Then Exit Sub
        CheckFullyCompliant()
    End Sub

    Private Sub IndexTest()
        ' Drop an index and make sure it gets added
        DropIndex("Parent", "c_varchar")
        DropIndex("Parent", "c_unique")
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()

        ' Add an index and make sure it gets dropped
        CreateIndex("Parent", "c_int", False)
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()

        ' Change an index from unique to non-unique, and see it gets reestablished
        DropIndex("Parent", "c_varchar")
        CreateIndex("Parent", "c_varchar", True)
        DropIndex("Parent", "c_unique")
        CreateIndex("Parent", "c_unique", False)
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()
    End Sub

    Private Sub RelationsTest()
        ' Drop a relation and make sure it's readded
        DropRelation("preventoptional", "parent_id")
        DropRelation("setnull", "parent_id") 'AN-25825
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()

        ' Add a relation and make sure it's dropped
        AddColumn("preventoptional", "newkey", "int not null default 0")
        CreateRelation("preventoptional", "newkey", "cascaderequired", "pkey", False)
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()
        CheckRelationGone("preventoptional", "newkey")

        ' Change the relation type and make sure it's changed back
        DropRelation("preventoptional", "parent_id")
        CreateRelation("preventoptional", "parent_id", "parent", "parent_id", True)
        DropRelation("cascaderequired", "parent_id")
        CreateRelation("cascaderequired", "parent_id", "parent", "parent_id", False)
        DropRelation("setnull", "parent_id")
        CreateRelation("setnull", "parent_id", "parent", "parent_id", en_DeletePolicy.Prevent)
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()

        ' Point an FK to the wrong table and make sure it gets fixed
        DropRelation("preventoptional", "parent_id")
        CreateRelation("preventoptional", "parent_id", "cyclic", "pkey", True)
        If Not Upsize(True, False, False) Then Exit Sub
        CheckFullyCompliant()

        ' Drop DRI and ensure relations gone and ensure nulls not allow
        If Not Upsize(False, True, False) Then Exit Sub
        Call CheckRelationGone("PreventOptional", "parent_id")
        Call CheckRelationGone("CascadeRequired", "parent_id")
        Call CheckRelationGone("SetNull", "parent_id")
        Call CheckRelationGone("Cyclic", "lowerparent_id")
        Call CheckRelationGone("Cyclic", "higherparent_id")
        Call CheckColumn("PreventOptional", "parent_id", "int", 0, False, False, "0")
        Call CheckColumn("CascadeRequired", "parent_id", "int", 0, False, False, "0")
        Call CheckColumn("SetNull", "parent_id", "int", 0, False, False, "0")
        Call CheckColumn("Cyclic", "lowerparent_id", "int", 0, False, False, "0")
        Call CheckColumn("Cyclic", "higherparent_id", "int", 0, False, False, "0")

        ' Insert some 0s into data, then upsize with DRI
        ' Optional column should get created (by 0_null), required won't
        Call IssueSql("insert into preventoptional (parent_id) values (0)")
        Call IssueSql("insert into cascaderequired (parent_id) values (0)")
        Call IssueSql("insert into setnull (parent_id) values (0)") 'AN-25825
        If Not Upsize(True, False, True) Then Exit Sub
        Call CheckRelation("PreventOptional", "parent_id", False)
        Call CheckRelationGone("CascadeRequired", "parent_id")
        Call CheckRelation("SetNull", "parent_id", False) 'AN-25825
        Call CheckColumn("PreventOptional", "parent_id", "int", 0, True, False, "")
        Call CheckColumn("CascadeRequired", "parent_id", "int", 0, False, False, "0")
        Call CheckColumn("SetNull", "parent_id", "int", 0, True, False, "") 'AN-25825
        ' Drop DRI again, then add an orphan to optional
        If Not Upsize(False, True, False) Then Exit Sub
        Call IssueSql("insert into preventoptional (parent_id) values (1)")
        If Not Upsize(True, False, True) Then Exit Sub
        Call CheckRelationGone("PreventOptional", "parent_id")
        Call CheckRelationGone("CascadeRequired", "parent_id")
        Call CheckRelation("SetNull", "parent_id", False) 'AN-25825
        Call CheckColumn("PreventOptional", "parent_id", "int", 0, True, False, "")
        Call CheckColumn("CascadeRequired", "parent_id", "int", 0, False, False, "0")
    End Sub

    Private Sub DropTable(ByVal sTable$)
        If Not moDDDbConn.bExecuteSql("drop table " & sTable, "") Then
            Throw New Exception("Unable to drop table " & sTable)
        End If
    End Sub

    Private Sub AddTable(ByVal sTable$, ByVal sSql$)
        If Not moDDDbConn.bExecuteSql("create table " & sTable & "(" & sSql & ")", "") Then
            Throw New Exception("Unable to add table " & sTable)
        End If
    End Sub

    Private Sub DropColumn(ByVal sTable$, ByVal sColumn$)
        DropDefault(sTable, sColumn)
        If Not moDDDbConn.bExecuteSql("alter table " & sTable & " drop column " & sColumn, "") Then
            Throw New Exception("Unable to drop column " & sTable & "." & sColumn)
        End If
    End Sub

    Private Sub AlterColumn(ByVal sTable$, ByVal sColumn$, ByVal sSql$, ByVal sDefault$)
        DropDefault(sTable, sColumn)
        DropIndex(sTable, sColumn)
        If Not moDDDbConn.bExecuteSql("alter table " & sTable & " alter column " & sColumn & " " & sSql, "") Then
            Throw New Exception("Unable to alter column " & sTable & "." & sColumn & " to " & sSql)
        End If
        If Not moDDDbConn.bExecuteSql("alter table " & sTable & " with nocheck add default " & sDefault & " for " & sColumn, "") Then
            Throw New Exception("Unable to set default for " & sTable & "." & sColumn)
        End If
    End Sub

    Private Sub AddColumn(ByVal sTable$, ByVal sColumn$, ByVal sSql$)
        If Not moDDDbConn.bExecuteSql("alter table " & sTable & " add " & sColumn & " " & sSql, "") Then
            Throw New Exception("Unable to alter column " & sTable & "." & sColumn & " to " & sSql)
        End If
    End Sub

    ' Check that table exists, and log errors
    Private Function CheckTableGone(ByVal sTable$) As Boolean
        If CheckTableExists(sTable) Then
            LogUpsizeError("Table " & sTable & " still exists")
        End If
    End Function

    Private Sub CheckColumnGone(ByVal sTable$, ByVal sColumn$)
        Dim sDatatypeActual$ = ""
        Dim iLengthActual% = 0
        Dim bAllowNullsActual As Boolean
        Dim bIdentityActual As Boolean
        Dim sDefaultActual$ = ""

        If GetColumn(sTable, sColumn, sDatatypeActual, iLengthActual, bAllowNullsActual, bIdentityActual, sDefaultActual) Then
            LogUpsizeError("Column " & sTable & "." & sColumn & " still exists")
        End If

    End Sub

    ' Drop the index on a column
    Private Sub DropIndex(ByVal sTable$, ByVal sColumn$)
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing

        'Hold a collection of index names to drop
        Dim IndexNames As New Generic.List(Of String)

        Try
            If Not moDDDbConn.bQuery(oRs, "execute sp_helpindex " & sTable, "") Then
                Throw New Exception("Could not obtain indexes")
            End If

            Do While oRs.Read
                If oRs.IDataReader_Item("index_keys").ToString.ToUpper.Contains(sColumn.ToUpper) Then
                    IndexNames.Add(oRs.IDataReader_Item("index_name").ToString)
                End If
            Loop
        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

        'Now drop the indexes
        For Each Index As String In IndexNames
            If Not moDDDbConn.bExecuteSql("Drop index " & sTable & "." & Index, "") Then
                Throw New Exception("Unable to drop index " & Index)
            End If
        Next

    End Sub

    Private Sub CreateIndex(ByVal sTable$, ByVal sExpr$, ByVal bUnique As Boolean)
        If Not moDDDbConn.bExecuteSql("create " & IIf(bUnique, "unique ", "").ToString & "index " & sTable & "__" & sExpr & " on " & _
                sTable & "(" & sExpr & ")", "") Then
            Throw New Exception("Unable to create index " & sTable & "(" & sExpr & ")")
        End If
    End Sub

    ' Drop the default constraint on a column
    Private Sub DropDefault(ByVal sTable$, ByVal sColumn$)
        Dim sSql$ = ""
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing
        Dim sDefName$ = ""
        Dim sFullName$ = ""

        ' Get the constraint name from the system tables
        sFullName = sTable & "." & sColumn
        sSql = "select d.name from sysobjects t, syscolumns c, sysobjects d " & _
            "where c.id=t.id and c.cdefault = d.id and t.name='" & _
            sTable & "' and c.name='" & sColumn & "' and t.type='u'"

        Try
            If Not moDDDbConn.bQuery(oRs, sSql, "") Then
                Throw New Exception("Could not obtain Constraint from System Table")
            End If
            If oRs.Read Then
                sDefName = oRs.IDataReader_Item("Name").ToString
            End If
        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

        ' Drop that constraint if we have a sDefName
        If sDefName <> "" Then
            If Not moDDDbConn.bExecuteSql _
                    ("alter table " & sTable & " drop constraint " & sDefName, "") Then

                Throw New Exception("Dropping default constraing for " & sFullName)
            End If
        End If
        
    End Sub

    Private Sub CreateRelation(ByVal sChild$, ByVal sFkey$, ByVal sParent$, ByVal sPkey$, ByVal bCascade As Boolean)
        CreateRelation(sChild, sFkey, sParent, sPkey, CType(IIf(bCascade, en_DeletePolicy.Cascade, en_DeletePolicy.Prevent), en_DeletePolicy))
    End Sub
    Private Sub CreateRelation(ByVal sChild$, ByVal sFkey$, ByVal sParent$, ByVal sPkey$, ByVal eDeletePolicy As en_DeletePolicy)
        If Not moDDDbConn.bExecuteSql("alter table " & sChild & " add constraint " & RelationName(sChild, sFkey) & _
                " foreign key (" & sFkey & ") references " & sParent & "(" & sPkey & ") " & DeletePolicyString(eDeletePolicy), "") Then
            Throw New Exception("Unable to create relation " & RelationName(sChild, sFkey))
        End If
    End Sub
    Private Sub DropRelation(ByVal sChild$, ByVal sFkey$)
        If Not moDDDbConn.bExecuteSql("alter table " & sChild & " drop constraint " & RelationName(sChild, sFkey), "") Then
            Throw New Exception("Unable to drop constraint " & RelationName(sChild, sFkey))
        End If
    End Sub
    Private Function DeletePolicyString(ByVal eDeletePoliy As en_DeletePolicy) As String
        Dim sReturn As String = ""
        Select Case eDeletePoliy
            Case en_DeletePolicy.Cascade
                sReturn = " on delete cascade "
            Case en_DeletePolicy.SetNull
                sReturn = " on delete set null "
        End Select

        Return sReturn
    End Function

    Private Function RelationName(ByVal sChild$, ByVal sFkey$) As String
        Return "fk_" & sChild & "__" & sFkey
    End Function

    Private Sub IssueSql(ByVal sSql$)
        If Not moDDDbConn.bExecuteSql(sSql, "") Then
            Throw New Exception("Error executing " & sSql)
        End If
    End Sub

    ' Check current database fully compliant with ERD (not however checking for any extra stuff)
    Private Function CheckFullyCompliant() As Boolean
        ' Check that all tables got created with the right columns
        CheckTableExists("Parent")
        Call CheckColumn("Parent", "parent_id", "int", 0, False, True, "")
        Call CheckColumn("Parent", "c_bit", "smallint", 0, False, False, "0")
        Call CheckColumn("Parent", "c_datetime", "datetime", 0, False, False, "'12/30/1899'")
        Call CheckColumn("Parent", "c_int", "int", 0, False, False, "0")
        Call CheckColumn("Parent", "c_money", "money", 0, False, False, "0")
        Call CheckColumn("Parent", "c_smallint", "smallint", 0, False, False, "0")
        Call CheckColumn("Parent", "c_text", "text", 0, False, False, "' '")
        Call CheckColumn("Parent", "c_varchar", "varchar", 10, False, False, "' '")
        Call CheckColumn("Parent", "c_unique", "varchar", 10, False, False, "' '")
        Call CheckColumn("Parent", "c_image", "image", 0, False, False, "")
        Call CheckIndex("Parent", "c_varchar", False)
        Call CheckIndex("Parent", "c_unique", True)
        Call CheckIndexes("Parent", "parent_id", "c_varchar", "c_unique")

        CheckTableExists("PreventOptional")
        Call CheckColumn("PreventOptional", "pkey", "int", 0, False, True, "")
        Call CheckColumn("PreventOptional", "parent_id", "int", 0, True, False, "")
        Call CheckRelation("PreventOptional", "parent_id", False)
        Call CheckIndexes("PreventOptional", "pkey")

        CheckTableExists("CascadeRequired")
        Call CheckColumn("CascadeRequired", "pkey", "int", 0, False, True, "")
        Call CheckColumn("CascadeRequired", "parent_id", "int", 0, False, False, "0")
        Call CheckRelation("CascadeRequired", "parent_id", True)
        Call CheckIndexes("CascadeRequired", "pkey")

        CheckTableExists("SetNull")
        Call CheckColumn("SetNull", "pkey", "int", 0, False, True, "")
        Call CheckColumn("SetNull", "parent_id", "int", 0, True, False, "")
        Call CheckRelation("SetNull", "parent_id", False)
        Call CheckIndexes("SetNull", "pkey")

        CheckTableExists("Cyclic")
        Call CheckColumn("Cyclic", "pkey", "int", 0, False, True, "")
        Call CheckColumn("Cyclic", "lowerparent_id", "int", 0, False, False, "0")
        Call CheckColumn("Cyclic", "higherparent_id", "int", 0, False, False, "0")
        Call CheckRelation("Cyclic", "lowerparent_id", True)
        Call CheckRelation("Cyclic", "higherparent_id", False)
        Call CheckIndexes("Cyclic", "pkey")

        CheckTableExists("DDRelations")
        Call CheckColumn("DDRelations", "child_table", "varchar", 100, False, False, "")
        Call CheckColumn("DDRelations", "parent_table", "varchar", 100, False, False, "")
        Call CheckColumn("DDRelations", "fkey", "varchar", 100, False, False, "")
        Call CheckColumn("DDRelations", "implemented", "smallint", 0, False, False, "0")
        Call CheckColumn("DDRelations", "delete_policy", "smallint", 0, False, False, "0")
        Call CheckColumn("DDRelations", "null_policy", "smallint", 0, False, False, "0")

        Call CheckDDRelations("PreventOptional", "Parent_id", "Parent", True, en_DeletePolicy.Prevent, en_NullPolicy.Allow)
        Call CheckDDRelations("CascadeRequired", "Parent_id", "Parent", True, en_DeletePolicy.Cascade, en_NullPolicy.Prevent)
        Call CheckDDRelations("SetNull", "Parent_id", "Parent", True, en_DeletePolicy.SetNull, en_NullPolicy.Allow)
        Call CheckDDRelations("Cyclic", "lowerparent_id", "Parent", True, en_DeletePolicy.Cascade, en_NullPolicy.Prevent)
        Call CheckDDRelations("Cyclic", "higherparent_id", "Parent", False, en_DeletePolicy.Cascade, en_NullPolicy.Prevent)
    End Function

    ' Check that table exists, and log errors
    Private Function CheckTableExists(ByVal sTable$) As Boolean
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing

        Try
            If Not moDDDbConn.bQuery(oRs, "execute sp_tables", "") Then
                Throw New Exception("Unalbe to obtain list of tables")
            End If

            Do While oRs.Read
                If oRs.IDataReader_Item("Table_Name").ToString.ToUpper = sTable.ToUpper Then
                    Return True
                End If
            Loop

        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

    End Function

    ' Check that column exists and has correct type; log error otherwise
    Private Sub CheckColumn(ByVal sTable$, ByVal sColumn$, ByVal sDatatype$, ByVal iLength%, _
            ByVal bAllowsNulls As Boolean, ByVal bIdentity As Boolean, ByVal sDefault As String)

        Dim sDatatypeActual$ = ""
        Dim iLengthActual% = 0
        Dim bAllowNullsActual As Boolean = False
        Dim bIdentityActual As Boolean = False
        Dim sDefaultActual$ = ""

        If Not GetColumn(sTable, sColumn, sDatatypeActual, iLengthActual, bAllowNullsActual, bIdentityActual, sDefaultActual) Then
            LogUpsizeError("Column " & sTable & "." & sColumn & " doesn't exist")
            Exit Sub
        End If
        If UCase(sDatatype) <> sDatatypeActual Then
            LogUpsizeError("Column " & sTable & "." & sColumn & " has datatype " & sDatatypeActual & " s/b " & sDatatype)
        End If
        If iLength <> iLengthActual Then
            LogUpsizeError("Column " & sTable & "." & sColumn & " has length " & iLengthActual & " s/b " & iLength)
        End If
        If bAllowsNulls <> bAllowNullsActual Then
            LogUpsizeError("Column " & sTable & "." & sColumn & " has allownulls " & bAllowNullsActual & " s/b " & bAllowsNulls)
        End If
        If bIdentity <> bIdentityActual Then
            LogUpsizeError("Column " & sTable & "." & sColumn & " has identity " & bIdentityActual & " s/b " & bIdentity)
        End If
        If UCase(sDefault) <> sDefaultActual Then
            LogUpsizeError("Column " & sTable & "." & sColumn & " has default " & sDefaultActual & " s/b " & sDefault)
        End If
    End Sub

    ' Try to find column in DB and return type info in byrefs
    Private Function GetColumn(ByVal sTable$, ByVal sColumn$, ByRef sDatatype$, ByRef iLength%, _
            ByRef bAllowNulls As Boolean, ByRef bIdentity As Boolean, ByRef sDefault$) As Boolean

        Dim oRs As ACS.DataAccess.claRecordSet = Nothing

        Try
            ' Issue sp_columns
            If Not moDDDbConn.bQuery(oRs, "execute sp_columns @table_name=" & sTable & _
                ", @column_name=" & sColumn, "") Then
                Throw New Exception("Unable to obtain columns")
            End If

            ' No such column
            If Not oRs.Read Then Return False

            ' Get datatype info
            sDatatype = oRs.IDataReader_Item("Type_Name").ToString.ToUpper
            bIdentity = False
            If sDatatype = "INT IDENTITY" Then
                sDatatype = "INT"
                bIdentity = True
            End If
            If sDatatype = "VARCHAR" Then
                iLength = CInt(oRs.IDataReader_Item("length"))
            Else
                iLength = 0
            End If
            If CInt(oRs.IDataReader_Item("Nullable")) <> 0 Then
                bAllowNulls = True
            End If

            ' Simplify default
            If oRs.IDataReader_Item("column_def") Is DBNull.Value Then
                sDefault = ""
            Else
                sDefault = oRs.IDataReader_Item("column_def").ToString
                While Left(sDefault, 1) = "("
                    sDefault = Mid(sDefault, 2, Len(sDefault) - 2)
                End While
            End If

            GetColumn = True

        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

    End Function

    ' Check that the only indexes which exist on a table are those with the desired key expressions
    Private Sub CheckIndexes(ByVal sTable$, ByVal ParamArray sExpressions$())
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing

        ' Issue sp_helpindex
        Try
            If Not moDDDbConn.bQuery(oRs, "execute sp_helpindex " & sTable, "") Then
                Throw New Exception("Unable to obtain indexes")
            End If

            ' Try to find index
            Do While oRs.Read
                Dim sExpr$ = oRs.IDataReader_Item("index_keys").ToString.ToUpper
                Dim bFound As Boolean = False
                For Each sExprDesired As String In sExpressions
                    If sExprDesired = sExpr Then
                        bFound = True
                        Exit For
                    End If
                Next
                If Not bFound Then
                    LogUpsizeError("Table {0} has undesired index on {1}", sTable, sExpr)
                End If
            Loop
        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try
    End Sub

    ' Check that index exists and has correct type; log error otherwise
    Private Sub CheckIndex(ByVal sTable$, ByVal sExpr$, ByVal bUnique As Boolean)
        Dim bUniqueActual As Boolean = False
        Dim sDesc$ = ""

        sDesc = "Index " & sTable & "(" & sExpr & ")"
        If Not GetIndex(sTable, sExpr, bUniqueActual) Then
            LogUpsizeError(sDesc & " doesn't exist")
            Exit Sub
        End If
        If bUnique <> bUniqueActual Then
            LogUpsizeError(sDesc & " has unique " & bUniqueActual & " s/b " & bUnique)
        End If
    End Sub

    ' Try to find index in DB and return type info in byref
    Private Function GetIndex(ByVal sTable$, ByVal sExpr$, ByRef bUnique As Boolean) As Boolean
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing

        ' Issue sp_helpindex
        Try
            If Not moDDDbConn.bQuery(oRs, "execute sp_helpindex " & sTable, "") Then
                Throw New Exception("Unable to obtain indexes")
            End If

            ' Try to find index
            Do While oRs.Read
                If oRs.IDataReader_Item("index_keys").ToString.ToUpper = sExpr.ToUpper Then

                    If oRs.IDataReader_Item("index_description").ToString.IndexOf(", unique") > 0 Then
                        bUnique = True
                    End If

                    Return True
                End If
            Loop
        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try
    End Function

    ' Check that relation exists and has correct type; log error otherwise
    Private Sub CheckRelation(ByVal sChild$, ByVal sFkey$, ByVal bCascade As Boolean)
        Dim bCascadeActual As Boolean
        Dim sDesc$
        sDesc = "Relation " & sChild & "(" & sFkey & ")"
        If Not GetRelation(sChild, sFkey, bCascadeActual) Then
            LogUpsizeError(sDesc & " doesn't exist")
            Exit Sub
        End If
        If bCascade <> bCascadeActual Then
            LogUpsizeError(sDesc & " has cascade " & bCascadeActual & " s/b " & bCascade)
        End If
    End Sub

    ' Check that relation exists and has correct type; log error otherwise
    Private Sub CheckRelationGone(ByVal sChild$, ByVal sFkey$)
        If GetRelation(sChild, sFkey, False) Then
            LogUpsizeError("Relation " & sChild & "(" & sFkey & ") still exists")
        End If
    End Sub

    ' Try to find relation in DB and return type info in byref
    Private Function GetRelation(ByVal sChild$, ByVal sFkey$, ByRef bCascade As Boolean) As Boolean

        ' Issue sp_fkeys
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing
        Try
            If Not moDDDbConn.bQuery(oRs, "execute sp_fkeys @fktable_name=" & sChild, "") Then
                Throw New Exception("Unable to obtain foriegn keys")
            End If

            ' Try to find index
            Do While oRs.Read
                If oRs.IDataReader_Item("fkcolumn_name").ToString.ToUpper = sFkey.ToUpper Then
                    If CInt(oRs.IDataReader_Item("delete_rule")) = 0 Then
                        bCascade = True
                    End If
                    Return True
                End If
            Loop
        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

    End Function

    Public Sub CheckDDRelations(ByVal sChild$, ByVal sFkey$, ByVal sParent$, ByVal bImplemented As Boolean, _
        ByVal eDeletePolicy As en_DeletePolicy, ByVal eNullPolicy As en_NullPolicy)

        Dim oRs As ACS.DataAccess.claRecordSet = Nothing
        Try
            If Not moDDDbConn.bQuery(oRs, "select * from ddrelations where child_table='" & sChild & _
                "' and fkey='" & sFkey & "'", "") Then
                Throw New Exception("Unable to obtain DDRelations for Child Table " & sChild)
            End If

            Dim sDesc$ = "DDRelation " & sChild & "(" & sFkey & ")"
            If Not oRs.Read Then
                LogUpsizeError(sDesc & " not found")
                Exit Sub
            End If
            If oRs.IDataReader_Item("parent_table").ToString.ToUpper <> sParent.ToUpper Then
                LogUpsizeError(sDesc & " has parent " & oRs.IDataReader_Item("parent_table").ToString & " s/b " & sParent)
            End If

            Dim bImplementedValue As Boolean = CBool(IIf(CInt(oRs.IDataReader_Item("implemented")) <> 0, True, False))

            If bImplementedValue <> bImplemented Then
                LogUpsizeError(sDesc & " has implemented " & bImplementedValue.ToString & " s/b " & bImplemented)
            End If
            If DirectCast(oRs.IDataReader_Item("delete_policy"), en_DeletePolicy) <> eDeletePolicy Then
                LogUpsizeError(sDesc & " has deletepolicy " & oRs.IDataReader_Item("delete_policy").ToString & " s/b " & eDeletePolicy)
            End If
            If DirectCast(oRs.IDataReader_Item("null_policy"), en_NullPolicy) <> eNullPolicy Then
                LogUpsizeError(sDesc & " has nullpolicy " & oRs.IDataReader_Item("null_policy").ToString & " s/b " & eNullPolicy)
            End If

        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try
    End Sub

End Class
