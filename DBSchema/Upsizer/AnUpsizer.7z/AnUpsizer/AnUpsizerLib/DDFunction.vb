Public Class DDFunction
#Region " Declarations "

    Dim moDDManager As DDManager
    Dim msFunctionName$       ' Name of Function
    Dim msPrefix$              ' Prefix to get fully qualified Function name
    Dim mbHasParameters As Boolean        ' Whether the XML specified a parameters collection (old style)
    Dim msExecuteStatement$    ' The sql for the Function to execute
    Dim msReturnType$
    Dim mdicParameters As Generic.Dictionary(Of String, DDParameter)
#End Region

#Region " Constructors "

    ' Construct from DB schema
    Friend Sub New(ByVal oDDManager As DDManager, ByVal FunctionName$)
        oDDManager = oDDManager
        msFunctionName = FunctionName
    End Sub

    ' Construct from XML
    Friend Sub New(ByVal oDDManager As DDManager, ByVal oDomDoctor As XMLDomDoctor)
        Dim bFound As Boolean

        moDDManager = oDDManager

        ' Get function-level data
        msFunctionName = oDomDoctor.GetAttribute("Name")
        'Get parameters and return type
        ' See if there is a parameters collection
        mbHasParameters = oDomDoctor.GetFirstNode("Parameters")
        If mbHasParameters Then
            bFound = oDomDoctor.GetFirstNode("Parameter")
            While bFound
                If CBool(oDomDoctor.GetAttribute("Output")) Then
                    Me.ReturnType = oDomDoctor.GetAttribute("DataType")
                Else
                    Dim oFunctionParam As DDParameter = New DDParameter(oDomDoctor.GetAttribute("Name"), oDomDoctor.GetAttribute("DataType"))
                    Me.Parameters.Add(oFunctionParam.ParameterName, oFunctionParam)
                End If
                bFound = oDomDoctor.GetNextNode("Parameter")
            End While
            oDomDoctor.Pop()
        End If

        'Get the sql
        Me.ExecuteStatement = oDomDoctor.GetSimpleNodeText("Statement", True)

    End Sub
#End Region
#Region " Properties "

    Public Property ExecuteStatement() As String
        Get
            Return msExecuteStatement
        End Get
        Set(ByVal value As String)
            msExecuteStatement = value
        End Set
    End Property

    Public Property FunctionName() As String
        Get
            Return msFunctionName
        End Get
        Set(ByVal value As String)
            msFunctionName = value
        End Set
    End Property

    Public ReadOnly Property Parameters() As Generic.Dictionary(Of String, DDParameter)
        Get
            If mdicParameters Is Nothing Then
                mdicParameters = New Generic.Dictionary(Of String, DDParameter)
                Return mdicParameters
            Else
                Return mdicParameters
            End If
        End Get
    End Property

    Public Property ReturnType() As String
        Get
            Return msReturnType
        End Get
        Set(ByVal value As String)
            msReturnType = value
        End Set
    End Property
#End Region

    Public Sub Upsize(ByVal oDDManagerTarget As DDManager, ByVal obDDFunctionTarget As DDFunction)
        Dim oSb As New Text.StringBuilder
        ' Old-style, with Parameters collection
        If mbHasParameters Then
            ' If function already exists, do an ALTER rather than CREATE
            If Not obDDFunctionTarget Is Nothing Then
                oSb.Append("alter")
            Else
                oSb.Append("create")
            End If
            oSb.Append(" Function ").Append(Me.FunctionName).Append("(")
            For Each oParameter As DDParameter In Me.Parameters.Values
                oSb.Append(oParameter.ParameterName).Append(" ").Append(oParameter.DataType).Append(",")
            Next
            oSb.Remove(oSb.Length - 1, 1)
            oSb.Append(") returns ").Append(Me.ReturnType)
            oSb.Append(" as ").Append(Me.ExecuteStatement)
            If Not oDDManagerTarget.DDDBConn.bExecuteSql(oSb.ToString, "Creating function " & Me.FunctionName) Then
                Throw New Exception("Could not execute " & oSb.ToString)
            End If

            ' New style, with parameters in <STATEMENT>
        Else
            ' If procedure already exists, do an change "CREATE PROCEDURE" to "ALTER PROCEDURE"
            oSb.Append(Me.ExecuteStatement)
            If Not obDDFunctionTarget Is Nothing Then
                Dim sTemp As String = Me.ExecuteStatement.ToLower
                Dim iPos As Int32 = sTemp.IndexOf("create function")
                If iPos < 0 Then
                    Throw New Exception("For procedure " + Me.FunctionName + " no 'create function' was found")
                End If
                oSb.Remove(iPos, 6)
                oSb.Insert(iPos, "alter")
            End If
            If Not oDDManagerTarget.DDDBConn.bExecuteSql(oSb.ToString, "Creating function " & Me.FunctionName) Then
                Throw New Exception("Could not execute " & oSb.ToString)
            End If
        End If
    End Sub
End Class
