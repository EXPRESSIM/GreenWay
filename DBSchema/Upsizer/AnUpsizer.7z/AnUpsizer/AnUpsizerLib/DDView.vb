Public Class DDView
#Region " Declarations "

    Dim moDDManager As DDManager
    Dim msViewName$           ' Name of view
    Dim msPrefix$             ' Prefix to get fully qualified table name
    Dim msStatement$                ' The sql to create the view

#End Region

#Region " Constructors "

    ' Construct from DB schema
    Friend Sub New(ByVal oDDManager As DDManager, ByVal ViewName$)
        oDDManager = oDDManager
        msViewName = ViewName
    End Sub

    ' Construct from XML
    Friend Sub New(ByVal oDDManager As DDManager, ByVal oDomDoctor As XMLDomDoctor)
        'Dim bFound As Boolean

        moDDManager = oDDManager

        ' Get view-level data
        msViewName = oDomDoctor.GetAttribute("Name")
        'Get the sql
        Me.Statement = oDomDoctor.GetSimpleNodeText("Statement", True)
    End Sub
#End Region
#Region " Properties "

    Public Property Statement() As String
        Get
            Return msStatement
        End Get
        Set(ByVal value As String)
            msStatement = value
        End Set
    End Property

    Public Property ViewName() As String
        Get
            Return msViewName
        End Get
        Set(ByVal value As String)
            msViewName = value
        End Set
    End Property
#End Region

    Public Sub Upsize(ByVal oDDManagerTarget As DDManager, ByVal obDDViewTarget As DDView)
        Dim oSb As New Text.StringBuilder

        Dim iPos As Int32 = Me.Statement.ToLower.IndexOf("create view")
        ' "Old style" has no "create view" statement
        If iPos < 0 Then
            ' If view already exists, do an ALTER rather than CREATE
            If Not obDDViewTarget Is Nothing Then
                oSb.Append("alter")
            Else
                oSb.Append("create")
            End If
            oSb.Append(" view ").Append(msViewName).Append(" as ").Append(Me.Statement)
        Else
            oSb.Append(Me.Statement)
            If Not obDDViewTarget Is Nothing Then
                oSb.Remove(0, iPos + 6)
                oSb.Insert(0, "alter")
            End If
        End If
            If Not oDDManagerTarget.DDDBConn.bExecuteSql(oSb.ToString, "Creating view " & ViewName) Then
                Throw New Exception("Could not execute " & oSb.ToString)
            End If
    End Sub
End Class
