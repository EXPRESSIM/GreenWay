<ComClass(AnUpsizerErrCol.ClassId, AnUpsizerErrCol.InterfaceId, AnUpsizerErrCol.EventsId)> _
Public Class AnUpsizerErrCol
    Implements IDisposable
#Region "COM GUIDs"
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "8e1913a9-11df-4568-bd6f-59f8e68dde1f"
    Public Const InterfaceId As String = "91f2ecdb-34cc-4ca2-9e2e-b05a881d2fa2"
    Public Const EventsId As String = "5822fbb3-54f7-40eb-8984-a0f429618728"
#End Region

    Dim mcolErrors As Collection
    Protected disposed As Boolean = False
    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()
        mcolErrors = New Collection
    End Sub

    Public Sub Add(ByVal sError As AnUpsizerError)
        mcolErrors.Add(sError)
    End Sub

    Public Function GetEnumerator() As System.Collections.IEnumerator
        'return our internal collection's IEnumerator.
        'COM calls this function when the collection is enumerated using the For-Each syntax
        Return mcolErrors.GetEnumerator
    End Function

    Public Function Count() As Integer
        Return mcolErrors.Count
    End Function

    Public Function HasFatal() As Boolean
        For Each oError As AnUpsizerError In Me
            If oError.Fatal Then Return True
        Next
    End Function

#Region "IDisposable Support"
    Protected Overridable Overloads Sub Dispose( _
    ByVal disposing As Boolean)
        If Not Me.disposed Then
            If disposing Then
                If Not mcolErrors Is Nothing Then
                    mcolErrors.Clear()
                End If

            End If
        End If
        Me.disposed = True
    End Sub
    Public Overloads Sub Dispose() Implements IDisposable.Dispose
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub

    Protected Overrides Sub Finalize()
        Dispose(False)
        MyBase.Finalize()
    End Sub
#End Region
End Class


