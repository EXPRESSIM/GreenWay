<ComClass(AnUpsizerError.ClassId, AnUpsizerError.InterfaceId, AnUpsizerError.EventsId)> _
Public Class AnUpsizerError

#Region " Declarations "
    Private mValue$
    Private mbFatal As Boolean
#End Region

#Region " COM GUIDs "
    ' These  GUIDs provide the COM identity for this class 
    ' and its COM interfaces. If you change them, existing 
    ' clients will no longer be able to access the class.
    Public Const ClassId As String = "a00840a0-a224-4f85-9b95-e773cbe0cc68"
    Public Const InterfaceId As String = "443fe3f2-a835-4ce4-836b-a59b2793a2d8"
    Public Const EventsId As String = "8980db45-3780-40b2-a0f7-a83335d5ccab"
#End Region

#Region " Constructors "

    ' A creatable COM class must have a Public Sub New() 
    ' with no parameters, otherwise, the class will not be 
    ' registered in the COM registry and cannot be created 
    ' via CreateObject.
    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal ErrorDesc$, ByVal Fatal As Boolean)
        mbFatal = Fatal

        If Fatal Then
            mValue = "(Fatal Error) " & ErrorDesc
        Else
            mValue = "(Non-Fatal Error) " & ErrorDesc
        End If
    End Sub

#End Region

#Region " Properties "

    Public ReadOnly Property Value() As String
        Get
            Value = mValue
        End Get
    End Property

    Public ReadOnly Property Fatal() As Boolean
        Get
            Return mbFatal
        End Get
    End Property

#End Region

End Class


