Public Class AnEnums

    Friend Enum en_DbUpdateType
        enmDutNone = 0              ' Column or table is just fine
        enmDutOptional = 1          ' Column or table update not required; perform only in "Drop Obsolete Data" mode
        enmDutRequired = 2          ' Column or table must be updated
    End Enum

    ' Data type (a simplification of DB's data type)
    Public Enum En_DataType
        enmStringDT = 1
        enmNumberDT = 2
        enmDateDT = 3
        enmBooleanDT = 4
        enmCurrencyDT = 5
        enmImageDT = 6
    End Enum

    Friend Enum en_JoinType
        enmJoinBothRequired = 0
        enmJoinAllParents = 1           ' Get all parents, if with no children
        enmJoinAllChildren = 2          ' Get all children, even with no parents
    End Enum

    Public Enum en_DeletePolicy As Short
        Prevent = 0
        Cascade = 1
        SetNull = 2
        SetDefault = 3
    End Enum

    Public Enum en_NullPolicy As Short
        Prevent = 0
        Allow = 1
        Ignore = 2        ' Client side code behaves old way
    End Enum

    'CollectionNAmes in the MetaDat
    Friend Enum SQLConnMetaDataCollectionNames
        Tables = 0
        Columns = 1
        IndexColumns = 2
        ForeignKeys = 3
        Indexes = 4
        Views = 5
        Procedures = 6
        ProcedureParameters = 7
    End Enum

    'These numbers represnt the restriction position in the string array.  Pass nothing for the ones inbetween
    Friend Enum SQLConnMetaDataColumns
        Table_Catalog = 0
        Table_Name = 2
        Column_Name = 3
        Column_Default = 5
        Is_Nullable = 6
        Data_Type = 7
        Character_Maximum_Length = 8
    End Enum

    Public Enum enmAppLogMessageType
        Debug = 1
        Info = 2
        Warning = 4
        NonFatalError = 8
        SQLError = 16
        FatalError = 32
        SQLCall = 64
    End Enum
    Public Enum enmDatabaseCompatibilityLevel
        SQLServer2000 = 80
        SQLServer2005 = 90
        SQLServer2008 = 100
    End Enum
End Class
