Imports AnUpsizerLib.AnEnums

Public Class DDTable

#Region " Declarations "

    Dim moDDManager As DDManager
    Dim msTableName$           ' Name of table
    Dim msPrefix$         ' Prefix to get fully qualified table name
    Dim msPrimaryKey$     ' Name of primary key column
    Dim mdicColumns As Generic.Dictionary(Of String, DDColumn)   ' Collection of columns
    Dim mdicIndexes As Generic.Dictionary(Of String, DDIndex)   ' Collection of Indexes
    Dim mdicRelations As Generic.Dictionary(Of String, DDRelation)   ' Collection of Relations

#End Region

#Region " Constructors "

    ' Construct from DB schema
    Friend Sub New(ByVal oDDManager As DDManager, ByVal TableName$)
        moDDManager = oDDManager
        msTableName = TableName

        msPrimaryKey = GetPrimaryKey(Me.DDManager.DDDBConn, msTableName)
        InitializeColumnsFromDB()
        InitializeIndexesFromDB()
        InitializeRelationsFromDB()
    End Sub

    ' Construct from XML
    Friend Sub New(ByVal oDDManager As DDManager, ByVal oDomDoctor As XMLDomDoctor)
        Dim bFound As Boolean

        moDDManager = oDDManager

        ' Get table-level data
        msTableName = oDomDoctor.GetAttribute("Name")
        msPrimaryKey = oDomDoctor.GetAttribute("PrimaryKey")

        ' Enumerate through through columns
        oDomDoctor.GetNode("Columns")
        bFound = oDomDoctor.GetFirstNode("Column")
        While bFound
            Dim oDDColumn As DDColumn = New DDColumn(Me, oDomDoctor)
            'Catch any duplicate key errors
            Try
                Columns.Add(oDDColumn.ColumnName, oDDColumn)
            Catch ex As Exception
                Throw New Exception("Tried to add Colmn " & oDDColumn.ColumnName & _
                    " With the Key of " & oDDColumn.ColumnName & _
                    " and parent table of " & Me.TableName & " and this failed because of a duplicate key.")
            End Try

            bFound = oDomDoctor.GetNextNode("Column")
        End While
        oDomDoctor.Pop()

        ' Enumerate through indexes
        oDomDoctor.GetNode("Indexes")
        bFound = oDomDoctor.GetFirstNode("Index")
        While bFound
            Dim oDDIndex As DDIndex = New DDIndex(Me, oDomDoctor)

            'Catch Duplicate Key errors
            Try
                Indexes.Add(oDDIndex.Expression, oDDIndex)
            Catch ex As Exception
                Throw New Exception("Tried to add Index " & oDDIndex.IndexName & _
                    " With the Key of " & oDDIndex.Expression & _
                    " and parent table of " & Me.TableName & " and this failed because of a duplicate key.")
            End Try

            bFound = oDomDoctor.GetNextNode("Index")
        End While
        oDomDoctor.Pop()

        ' Enumerate through relations
        oDomDoctor.GetNode("Relations")
        bFound = oDomDoctor.GetFirstNode("Relation")
        While bFound
            Dim oDDRelation As DDRelation = New DDRelation(Me, oDomDoctor)

            'Make sure we catch a duplicate add exception here
            Try
                Me.Relations.Add(oDDRelation.FKey, oDDRelation)
            Catch ex As Exception
                Throw New Exception("Tried to add Relation " & oDDRelation.Name & _
                    " With the Key of " & oDDRelation.FKey & _
                    " and parent table of " & Me.TableName & _
                    " and this failed because of a duplicate key.")
            End Try
            bFound = oDomDoctor.GetNextNode("Relation")
        End While
        oDomDoctor.Pop()
    End Sub

    'Constructor for creating new in memory tables
    Private Sub New(ByVal oDDManager As DDManager, ByVal stTableName$, ByVal stPKey$, ByVal bInitialized As Boolean)
        moDDManager = oDDManager
        msTableName = stTableName
        msPrimaryKey = stPKey
    End Sub

#End Region

#Region " Properties "

    Public ReadOnly Property Column(ByVal stColumnName$) As DDColumn
        Get
            Try
                Return Me.Columns.Item(stColumnName.Trim.ToUpper)
            Catch ex As Exception
                'Was not in collection so return nothing
                Return Nothing
            End Try
        End Get
    End Property

    Public ReadOnly Property Columns() As Generic.Dictionary(Of String, DDColumn)
        Get
            If mdicColumns Is Nothing Then
                mdicColumns = New Generic.Dictionary(Of String, DDColumn)
                Return mdicColumns
            Else
                Return mdicColumns
            End If
        End Get
    End Property

    Public ReadOnly Property Index(ByVal stIndexName$) As DDIndex
        Get
            Try
                Return Me.Indexes.Item(stIndexName.ToUpper)
            Catch ex As Exception
                'Was not in collection so return nothing
                Return Nothing
            End Try
        End Get
    End Property

    Public ReadOnly Property Indexes() As Generic.Dictionary(Of String, DDIndex)
        Get
            If mdicIndexes Is Nothing Then
                mdicIndexes = New Generic.Dictionary(Of String, DDIndex)
                Return mdicIndexes
            Else
                Return mdicIndexes
            End If
        End Get
    End Property

    Public ReadOnly Property Relation(ByVal stFKey$) As DDRelation
        Get
            Try
                Return Me.Relations.Item(stFKey.ToUpper)
            Catch ex As Exception
                'Was not in collection so return nothing
                Return Nothing
            End Try
        End Get
    End Property

    Public ReadOnly Property Relations() As Generic.Dictionary(Of String, DDRelation)
        Get
            If mdicRelations Is Nothing Then
                mdicRelations = New Generic.Dictionary(Of String, DDRelation)
                Return mdicRelations
            Else
                Return mdicRelations
            End If
        End Get
    End Property

    Public ReadOnly Property DDManager() As DDManager
        Get
            Return (moDDManager)
        End Get
    End Property

    'this is the key for the collection so always do an upper to normalize the keys
    Public Property TableName() As String
        Get
            TableName = msTableName.Trim.ToUpper
        End Get
        Set(ByVal value As String)
            msTableName = value
        End Set
    End Property

    Public Property Prefix() As String
        Get
            Prefix = msPrefix
        End Get
        Set(ByVal value As String)
            msPrefix = value
        End Set
    End Property

    Public Property PrimaryKey() As String
        Get
            PrimaryKey = msPrimaryKey
        End Get
        Set(ByVal value As String)
            msPrimaryKey = value
        End Set
    End Property

#End Region

#Region " Code to read schema from DB "

    ' Use sp_pkeys to get the primary key of a table
    ' Assumes no composite keys
    Private Shared Function GetPrimaryKey(ByVal oDDDbConn As DDDbConn, ByVal stTableName$) As String
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing

        Try
            If Not oDDDbConn.bQuery(oRs, "execute sp_pkeys @table_name=" & HelperFuncs.sQuoteValue(stTableName), _
                "Getting primary key for table " & stTableName) Then
                Throw New Exception("Could not obtain primary key for Table " & stTableName)
            End If

            If Not oRs.Read Then
                Return ""
            Else
                GetPrimaryKey = UCase(oRs.IDataReader_Item("Column_Name").ToString)
            End If

            'It cannot have more then one PKey so if we still have records blow out
            If oRs.Read Then
                Throw New Exception("Table '" & stTableName & "' has a composite primary key -- not allowed")
            End If

        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

    End Function

    ' Get columns from DB
    Private Sub InitializeColumnsFromDB()
        ' Enumerate through all columns in this table
        Dim obTableView As DataView = Me.DDManager.DataBaseColumns.DefaultView
        obTableView.RowFilter = "Table_Name = '" & Me.TableName & "'"
        For Each row As DataRowView In obTableView

            Dim sColName$ = row("Column_Name").ToString
            Dim iColSize As Integer
            If row("Character_Maximum_Length").Equals(System.DBNull.Value) Then iColSize = 0 Else iColSize = CInt(row("Character_Maximum_Length"))

            Dim AllowNull As Boolean
            If row("Is_Nullable").ToString.ToUpper.Contains("NO") Then AllowNull = False Else AllowNull = True

            Dim ColDataType$ = row("Data_Type").ToString

            Dim NewCol As New DDColumn(Me, sColName, iColSize, ColDataType, AllowNull)
            Try
                Me.Columns.Add(NewCol.ColumnName, NewCol)
            Catch ex As Exception
                Throw New Exception("Tried to add Colmn " & NewCol.ColumnName & _
                    " With the Key of " & NewCol.ColumnName & _
                    " and parent table of " & Me.TableName & " and this failed because of a duplicate key.")
            End Try
        Next
    End Sub

    'Get indexes from DB
    Private Sub InitializeIndexesFromDB()
        Dim pRs As ACS.DataAccess.claRecordSet = Nothing

        Try

            ' Now get the current indexes from the system table.
            ' This SQL is based on that in the sp_indexes system stored procedure,
            ' which for various reasons I wasn't able to use.
            If Not Me.DDManager.DDDBConn.bQuery(pRs, _
                "select x.name as INDEX_NAME, convert(int, xk.keyno) as ORDINAL, " _
                & "c.name as COLUMN_NAME, convert(bit,(x.status & 0x800)/0x800) as IS_PRIMARY_KEY, " _
                & "convert(bit,(x.status & 2)/2) as IS_UNIQUE" _
                & " from sysobjects o, sysindexes x, syscolumns c, sysindexkeys xk" _
                & " where o.type in ('U') and o.name = '" & msTableName & "' and x.id = o.id and c.id = o.id" _
                & " and xk.id = o.id and xk.indid = x.indid and xk.colid = c.colid and xk.keyno <= x.keycnt" _
                & " and permissions(o.id, c.name) <> 0 and (x.status&32) = 0" _
                & " order by index_name, ordinal", _
                "Getting indexes for table " & msTableName) Then

                Throw New Exception("Unalbe to obtain indexes for table " & msTableName)
            End If

            Dim sIndexName$ = ""
            Dim oNewDDIndex As DDIndex = Nothing

            If Me.TableName = "Servers" Then
                Dim x$ = ""
            End If

            Do While pRs.Read
                If CInt(pRs.IDataReader_Item("IS_PRIMARY_KEY")) = 0 Then

                    ' This is for compound index support, where there are multiple rows for the same indexname
                    If String.Compare(pRs.IDataReader_Item("INDEX_NAME").ToString, sIndexName, True) <> 0 Then
                        'From the previous loop we add the index
                        If Not oNewDDIndex Is Nothing Then

                            Try
                                ' ANE-12089 if user define's index, do not delete
                               If moDDManager.UserDefinedIndex(sIndexName) Is Nothing Then
                                    Me.Indexes.Add(oNewDDIndex.Expression, oNewDDIndex)
                                End If
                            Catch ex As Exception
                                Throw New Exception("Tried to add Index " & oNewDDIndex.IndexName & _
                                    " With the Key of " & oNewDDIndex.Expression & _
                                    " and parent table of " & msTableName & " and this failed because of a duplicate key.")
                            End Try

                        End If
                        'We can't set expression value until after this block so send ""
                        oNewDDIndex = New DDIndex(Me, pRs.IDataReader_Item("INDEX_NAME").ToString, _
                            CBool(pRs.IDataReader_Item("IS_UNIQUE")), "")
                        sIndexName = oNewDDIndex.IndexName
                    End If

                    oNewDDIndex.Expression = HelperFuncs.sCombineWithDelimiter(oNewDDIndex.Expression, _
                        pRs.IDataReader_Item("COLUMN_NAME").ToString, ",")
                End If

            Loop

            'This adds the last index when the record set loop is complete
            If Not oNewDDIndex Is Nothing Then

                Try
                    If moDDManager.UserDefinedIndex(sIndexName) Is Nothing Then
                        Me.Indexes.Add(oNewDDIndex.Expression, oNewDDIndex)
                    End If
                Catch ex As Exception
                    Throw New Exception("Tried to add Index " & oNewDDIndex.IndexName & _
                        " With the Key of " & oNewDDIndex.Expression & _
                        " and parent table of " & msTableName & " and this failed because of a duplicate key.")
                End Try
            End If

        Finally
            If pRs IsNot Nothing Then pRs.Dispose()
        End Try
    End Sub

    'Get relations from DB
    Private Sub InitializeRelationsFromDB()
        Dim pRs As ACS.DataAccess.claRecordSet = Nothing
        Dim stParentTable$ = ""
        Dim stPKey$ = ""
        Dim stChildTable$ = ""
        Dim stFKey$ = ""
        Dim stDesc$ = ""
        Dim DeletePolicy As en_DeletePolicy

        Try

            ' Now get the current relations from the system tables.
            ' This SQL is based on that in the sp_fkeys system stored procedure.
            If Not Me.DDManager.DDDBConn.bQuery(pRs, _
                "SELECT o1.name AS ParentTable, c1.name AS PKey, " & _
                "o2.name AS ChildTable, c2.name AS FKey, " & _
                "ObjectProperty(o.id, 'CnstIsDeleteCascade') AS CascadeDelete, rkey2, fkey2 " & _
                " FROM sysreferences r, sysobjects o, sysobjects o1, sysobjects o2, syscolumns c1, syscolumns c2 " & _
                " WHERE (r.fkeyid = OBJECT_ID('" & msTableName & "')) AND (o.xtype = 'F') AND r.constid = o.id " & _
                " AND r.rkeyid = o1.id AND c1.id = r.rkeyid AND c1.colid = r.rkey1 " & _
                " AND r.fkeyid = o2.id and c2.id = r.fkeyid AND c2.colid = r.fkey1 ", _
                "Getting relations for table " & msTableName) Then

                Throw New Exception("Unable to obtain Relations for Table " & msTableName)
            End If

            Do While pRs.Read
                stParentTable = UCase(pRs.IDataReader_Item("ParentTable").ToString)
                stPKey = UCase(pRs.IDataReader_Item("PKey").ToString)
                stChildTable = UCase(pRs.IDataReader_Item("ChildTable").ToString)
                stFKey = UCase(pRs.IDataReader_Item("FKey").ToString)
                stDesc = stChildTable & "." & stFKey & "->" & stParentTable & "." & stPKey
                DeletePolicy = CType(IIf(CInt(pRs.IDataReader_Item("CascadeDelete")) <> 0, _
                    en_DeletePolicy.Cascade, en_DeletePolicy.Prevent), en_DeletePolicy)

                ' We don't support composite foreign keys
                If CInt(pRs.IDataReader_Item("rkey2")) <> 0 OrElse CInt(pRs.IDataReader_Item("fkey2")) <> 0 Then
                    Throw New Exception("Relation " & stDesc & " has more than one key column")
                End If

                Dim oNewRelation As New DDRelation(Me, stFKey, stPKey, stChildTable, stParentTable, DeletePolicy)

                Try
                    Me.Relations.Add(oNewRelation.FKey, oNewRelation)
                Catch ex As Exception
                    Throw New Exception("Tried to add Relation " & oNewRelation.Name & _
                        " With the Key of " & oNewRelation.FKey & _
                        " and parent table of " & msTableName & _
                        " and this failed because of a duplicate key.")
                End Try

            Loop

        Finally
            If pRs IsNot Nothing Then pRs.Dispose()
        End Try
    End Sub

#End Region

    '****************************************************************************
    ' Upsize this table
    '****************************************************************************
    Public Sub Upsize(ByVal pobDDManagerTarget As DDManager, ByVal pobDDTableTarget As DDTable, _
            ByVal bImplementDRI As Boolean, ByVal bDropObsoleteData As Boolean)

        Dim oDDColumn As DDColumn = Nothing
        Dim oDDColumnTarget As DDColumn = Nothing
        Dim oDDRelation As DDRelation = Nothing
        Dim sUpsizeSql$ = ""
        Dim sColumnSql$ = ""

        ' First, do all of the add columns, since these can be done in a single
        ' create/alter table statement, without worrying about the limitations of alter column
        For Each obColSource As Generic.KeyValuePair(Of String, DDColumn) In Me.Columns

            If pobDDTableTarget IsNot Nothing Then
                oDDColumnTarget = pobDDTableTarget.Column(obColSource.Value.ColumnName)
            End If

            If oDDColumnTarget Is Nothing Then
                sColumnSql = obColSource.Value.UpsizeSql(oDDColumnTarget, bImplementDRI, bDropObsoleteData)
                sUpsizeSql = HelperFuncs.sCombineWithDelimiter(sUpsizeSql, sColumnSql, ", ")
            End If

        Next

        ' Create/alter table
        If sUpsizeSql <> "" Then
            Dim sVerb$
            If pobDDTableTarget Is Nothing Then
                sUpsizeSql = "create table " & Me.TableName & "(" & sUpsizeSql & ")"
                sVerb = "Creating"
            Else
                sUpsizeSql = "alter table " & Me.TableName & " add " & " " & sUpsizeSql
                sVerb = "Adding columns to"
            End If

            If Not pobDDManagerTarget.DDDBConn.bExecuteSql(sUpsizeSql, sVerb & " table " & Me.TableName) Then
                Throw New Exception("Upsize failed for Table " & Me.TableName)
            End If
        End If

        ' Add table to target DD if necessary
        If pobDDTableTarget Is Nothing Then
            pobDDTableTarget = New DDTable(pobDDManagerTarget, Me.TableName, Me.PrimaryKey, True)
            pobDDManagerTarget.Tables.Add(pobDDTableTarget.TableName, pobDDTableTarget)
        End If

        ' Add new DDColumns to target DD
        For Each obColSource As Generic.KeyValuePair(Of String, DDColumn) In Me.Columns
            oDDColumnTarget = pobDDTableTarget.Column(obColSource.Value.ColumnName)
            If oDDColumnTarget Is Nothing Then
                oDDColumnTarget = New DDColumn(Me, obColSource.Value.ColumnName, obColSource.Value.ColumnSize, _
                obColSource.Value.RawDataType, obColSource.Value.AllowNulls)

                pobDDTableTarget.Columns.Add(oDDColumnTarget.ColumnName, oDDColumnTarget)
            End If
        Next

        ' Drop any unnecessary FK constraints now, because they'll get in the way of some alter columns
        ' If we're not implementing DRI, drop them all
        'Can only drop them after you finish enumerating through them
        Dim DroppedRelations As New Generic.Queue(Of DDRelation)

        For Each oDDRelationTarget As DDRelation In pobDDTableTarget.Relations.Values
            oDDRelation = Me.Relation(oDDRelationTarget.FKey)
            If oDDRelation Is Nothing OrElse oDDRelation.ParentTable <> oDDRelationTarget.ParentTable OrElse Not bImplementDRI Then
                'Cue up this relation to drop later
                DroppedRelations.Enqueue(oDDRelationTarget)
            End If
        Next

        For Each oDDRelationTarget As DDRelation In DroppedRelations
            oDDRelationTarget.DropRelation()
        Next
        DroppedRelations.Clear()

        ' Drop any obsolete columns
        Dim DroppedCols As New Generic.Queue(Of DDColumn)
        If bDropObsoleteData Then
            For Each obColumnTarget As Generic.KeyValuePair(Of String, DDColumn) In pobDDTableTarget.Columns

                oDDColumn = Me.Column(obColumnTarget.Value.ColumnName)
                If oDDColumn Is Nothing Then
                    DroppedCols.Enqueue(obColumnTarget.Value)
                End If
            Next

            For Each DroppedCol As DDColumn In DroppedCols
                DroppedCol.DropColumn()
            Next
        End If

        ' Now do all the alter columns
        For Each obColSource As Generic.KeyValuePair(Of String, DDColumn) In Me.Columns
            oDDColumnTarget = pobDDTableTarget.Column(obColSource.Value.ColumnName)
            If oDDColumnTarget Is Nothing Then
                Dim x$ = ""
            End If
            obColSource.Value.AlterColumn(oDDColumnTarget, bImplementDRI, bDropObsoleteData)
        Next

        ' Drop any indexes which shouldn't be there, or are wrong
        'Have to que up the indexes because you cannot drop when enumerating through them
        Dim oDDIndex As DDIndex
        Dim oDdIndexTarget As DDIndex
        Dim DroppedIndexes As New Generic.Queue(Of DDIndex)

        For Each obIndexTarget As Generic.KeyValuePair(Of String, DDIndex) In pobDDTableTarget.Indexes

            oDdIndexTarget = obIndexTarget.Value
            oDDIndex = Me.Index(oDdIndexTarget.Expression)
            ' ANE-12089
            If oDDIndex Is Nothing Then
                DroppedIndexes.Enqueue(obIndexTarget.Value)
            ElseIf oDDIndex.Unique <> oDdIndexTarget.Unique Then
                DroppedIndexes.Enqueue(obIndexTarget.Value)
            End If
        Next

        For Each oDroppedIndex As DDIndex In DroppedIndexes
            If oDroppedIndex.DropIndex Then
                pobDDTableTarget.Indexes.Remove(oDroppedIndex.Expression)
            End If
        Next

        ' Add any indexes which should be there
        For Each obIndexSource As Generic.KeyValuePair(Of String, DDIndex) In Me.Indexes
            oDdIndexTarget = pobDDTableTarget.Index(obIndexSource.Value.Expression)
            If oDdIndexTarget Is Nothing Then
                If Not obIndexSource.Value.CreateIndex(pobDDTableTarget) Then
                    Throw New Exception("Unable to add index " & obIndexSource.Value.DDTable.TableName & _
                        "(" & obIndexSource.Value.Expression & ")")
                End If
            End If
        Next

        ' If we're implementing DRI, create the constraints
        ' NOTE: We actually create the relations later in DDManager, because it's only then that we know
        ' both the parent and child tables exist
        If bImplementDRI Then

            ' First drop any FK constraints which changed cascade type. Problem is I cannot drop a
            'Releation while i am enumerating through it. I have to create a temp collection of relation keys
            'to drop after I enumerate through them

            For Each oDDRelationTarget As DDRelation In pobDDTableTarget.Relations.Values
                oDDRelation = Me.Relation(oDDRelationTarget.FKey)
                If oDDRelation Is Nothing Then
                    Throw New Exception("Can't find source relation for " & oDDRelationTarget.Name)
                End If
                'If (oDDRelation.DeletePolicy = en_DeletePolicy.Cascade) <> _
                '    (oDDRelationTarget.DeletePolicy = en_DeletePolicy.Cascade) Then
                If oDDRelation.DeletePolicy <> oDDRelationTarget.DeletePolicy Then
                    'Mark it for dropping later
                    DroppedRelations.Enqueue(oDDRelationTarget)
                End If
            Next

            'Now drop all that are enqueue
            For Each oDDRelationTarget As DDRelation In DroppedRelations
                oDDRelationTarget.DropRelation()
            Next
            DroppedRelations.Clear()

        End If

        ' Add all relations into the DDRelations table
        ' (We set the implemented flag later in DDManager, after we try creating all the relations)
        For Each obRelationSource As Generic.KeyValuePair(Of String, DDRelation) In Me.Relations
            If Not pobDDManagerTarget.DDDBConn.bExecuteSql( _
                "insert into ddrelations (child_table, fkey, parent_table, delete_policy, null_policy) values (" & _
                HelperFuncs.sQuoteValue(Me.TableName) & "," & HelperFuncs.sQuoteValue(obRelationSource.Value.FKey) & "," & _
                HelperFuncs.sQuoteValue(obRelationSource.Value.ParentTable) & "," & obRelationSource.Value.DeletePolicy & _
                "," & GetDeletePolicy(bImplementDRI, obRelationSource.Value.AllowNulls) & ")", _
                "Creating DDRelation " & obRelationSource.Value.Name) Then

                Throw New Exception("Could not insert values into DDRelations")
            End If

        Next

    End Sub

    'Helper Func to determine Delete Policy
    Private Function GetDeletePolicy(ByVal bImpDRI As Boolean, ByVal bAllowNulls As Boolean) As Integer
        If Not bImpDRI Then
            Return en_NullPolicy.Ignore
        ElseIf bAllowNulls Then
            Return en_NullPolicy.Allow
        Else
            Return en_NullPolicy.Prevent
        End If
    End Function

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class
