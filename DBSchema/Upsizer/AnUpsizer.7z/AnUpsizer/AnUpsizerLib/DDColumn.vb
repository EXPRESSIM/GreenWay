Imports AnUpsizerLib.AnEnums
Imports System.Data.SqlDbType

Public Class DDColumn

#Region " Declarations "

    Dim moDDTable As DDTable
    Dim msName$                               ' Name of this column
    Dim meDataType As En_DataType             ' Safari's type
    Dim msRawDataType$                       'Holds the string datatype read form XML or the DB
    Dim meEquivType As En_DataType            ' Equivalent type
    Dim miColumnSize As Integer               ' Number of characters in a stringcolumn
    Dim mbAllowNulls As Boolean               ' Whether column is required

#End Region

#Region " Constructors "

    'Use this if you are reading from a DB or a new in memory column
    Friend Sub New(ByVal oDDTable As DDTable, _
        ByVal stColName$, _
        ByVal iColSize As Integer, _
        ByVal stDataType$, _
        ByVal bAllowNulls As Boolean)

        moDDTable = oDDTable
        msName = stColName
        mbAllowNulls = bAllowNulls
        msRawDataType = stDataType
        SetDatatypeAndColSize(stDataType, iColSize)
    End Sub

    Friend Sub New(ByVal oDDTable As DDTable, ByVal oDomDoctor As XMLDomDoctor)
        moDDTable = oDDTable
        msName = oDomDoctor.GetAttribute("Name")
        msRawDataType = oDomDoctor.GetAttribute("DataType")

        'This really only applies to certain datatypes but if it is "" then it will just be 0
        Dim stVarCharSize$ = oDomDoctor.GetAttribute("ColumnSize", False)
        If stVarCharSize = "" Then stVarCharSize = "0"

        SetDatatypeAndColSize(msRawDataType, CInt(stVarCharSize))

        Dim stAllowNulls$ = oDomDoctor.GetAttribute("AllowNulls", False)
        mbAllowNulls = stAllowNulls <> ""
    End Sub

#End Region

#Region " Properties "

    Public Property ColumnSize() As Integer
        Get
            ColumnSize = miColumnSize
        End Get
        Set(ByVal value As Integer)
            miColumnSize = value
        End Set
    End Property

    Public Property DataType() As En_DataType
        Get
            DataType = meDataType
        End Get
        Set(ByVal value As En_DataType)
            meDataType = value
        End Set
    End Property

    Public ReadOnly Property RawDataType() As String
        Get
            Return msRawDataType
        End Get
    End Property

    Public ReadOnly Property EquivType() As En_DataType
        Get
            EquivType = meEquivType
        End Get
    End Property

    'This is the key for the collection so do an upper
    Public Property ColumnName() As String
        Get
            Return msName.Trim.ToUpper
        End Get
        Set(ByVal value As String)
            msName = value
        End Set
    End Property

    Public Property AllowNulls() As Boolean
        Get
            Return mbAllowNulls
        End Get
        Set(ByVal value As Boolean)
            mbAllowNulls = value
        End Set
    End Property

    Public ReadOnly Property DDTable() As DDTable
        Get
            Return moDDTable
        End Get
    End Property

    Public ReadOnly Property Fullname() As String
        Get
            Return Me.DDTable.TableName & "." & Me.ColumnName
        End Get
    End Property

#End Region

#Region " Column type normalization "

    'Pass in the actual datatype string with VarChar defined size and set datatype and colsize
    Private Sub SetDatatypeAndColSize(ByVal stDataType$, ByVal VarCharSize As Integer)

        Select Case stDataType
            Case "TEXT"
                meDataType = En_DataType.enmStringDT
            Case "VARCHAR"
                meDataType = En_DataType.enmStringDT
                miColumnSize = VarCharSize
            Case "INT"
                meDataType = En_DataType.enmNumberDT
                miColumnSize = 10
            Case "SMALLINT"
                meDataType = En_DataType.enmNumberDT
                miColumnSize = 5
            Case "DATETIME"
                meDataType = En_DataType.enmDateDT
            Case "BIT"
                meDataType = En_DataType.enmBooleanDT
                miColumnSize = 1
            Case "BIT"
                meDataType = En_DataType.enmBooleanDT
                miColumnSize = 1
            Case "MONEY"
                meDataType = En_DataType.enmCurrencyDT
            Case "IMAGE"
                meDataType = En_DataType.enmImageDT
            Case Else

                Me.DDTable.DDManager.UpsizerLibParent.LogUpsizeError("Error in GetDataType Unsupported DB data type: " & _
                    stDataType & " From fieldname " & Me.ColumnName & " Table " & Me.DDTable.TableName, False)
        End Select

        SetEquivalentType()
    End Sub

    ' Set another property, so numeric types are all considered to be equivalent
    ' for purposes of upsizing comparison
    Private Sub SetEquivalentType()
        meEquivType = meDataType
        Select Case meDataType
            Case En_DataType.enmcurrencydt
                meEquivType = En_DataType.enmNumberDT
                miColumnSize = 15
            Case En_DataType.enmbooleandt
                meEquivType = En_DataType.enmNumberDT
                miColumnSize = 5
        End Select
    End Sub

#End Region

#Region " Functions to support updating schema "

    ' Alter one column
    Friend Sub AlterColumn(ByVal oDDColumnTarget As DDColumn, ByVal bImplementDRI As Boolean, _
            ByVal bDropObsoleteData As Boolean)

        Dim sUpsizeSql$
        Dim bDropDefaults As Boolean

        ' If we're turning a null constraint on, change any nulls to 0s first, so the NOT NULL won't fail
        If oDDColumnTarget.AllowNulls AndAlso (Not Me.AllowNulls OrElse Not bImplementDRI) Then
            If Not oDDColumnTarget.DDTable.DDManager.DDDBConn.bExecuteSql( _
                "update " & Me.DDTable.TableName & " set " & Me.ColumnName & "=0 where " & Me.ColumnName & " is null", _
                "Changing nulls to zeroes for column " & Me.Fullname) _
                Then
                Throw New Exception("Could not Change nulls to zeroes for column " & Me.Fullname)
            End If
        End If

        ' Get SQL to alter this column -- if blank, no change required
        sUpsizeSql = UCase(Me.UpsizeSql(oDDColumnTarget, bImplementDRI, bDropObsoleteData))
        If sUpsizeSql = "" Then
            'Nothing to do
            Exit Sub
        End If

        ' If a column has defaults (all of ours do) or an index, you can't alter a column
        ' *unless* the type isn't being changed and the width is being widened. In our
        ' case, that means only varchar columns count, and only if not converted into text.
        ' All numeric type changes change the type, not just the width.

        ' Data type being changed forces dropping of defaults
        If Me.DataType <> oDDColumnTarget.DataType Then
            bDropDefaults = True

            ' Column null type changing forces
        ElseIf (Me.AllowNulls And bImplementDRI) <> oDDColumnTarget.AllowNulls Then
            bDropDefaults = True

            ' Numeric type changes force dropping of defaults
        ElseIf Me.DataType = En_DataType.enmNumberDT And Me.ColumnSize <> oDDColumnTarget.ColumnSize Then
            bDropDefaults = True

            ' Column changed to memo forces dropping of defaults
        ElseIf Me.DataType = En_DataType.enmStringDT Then
            If Me.ColumnSize = 0 And oDDColumnTarget.ColumnSize > 0 Then
                bDropDefaults = True

                ' Column size getting smaller forces dropping of defaults
            ElseIf Me.ColumnSize < oDDColumnTarget.ColumnSize And bDropObsoleteData Then
                bDropDefaults = True

                ' Changing from a memo forces dropping of defaults
            ElseIf Me.ColumnSize > 0 And oDDColumnTarget.ColumnSize = 0 And bDropObsoleteData Then
                bDropDefaults = True
            End If

        End If

        If bDropDefaults Then
            oDDColumnTarget.DropIndexes()
            oDDColumnTarget.DropDefaults()
        End If

        ' Alter table
        sUpsizeSql = "alter table " & Me.DDTable.TableName & " alter column " & sUpsizeSql
        If Not oDDColumnTarget.DDTable.DDManager.DDDBConn.bExecuteSql(sUpsizeSql, _
            "Changing column " & Me.Fullname & " to " & sUpsizeSql) _
            Then
            Throw New Exception("Could not Alter Table " & Me.Fullname)
        End If

        ' Readd the defaults if necessary
        If bDropDefaults Then
            AddDefaults(oDDColumnTarget, bImplementDRI)
        End If

        ' If we're turning a null constraint off, change any 0s to nulls
        If Not oDDColumnTarget.AllowNulls And Me.AllowNulls And bImplementDRI Then
            If Not oDDColumnTarget.DDTable.DDManager.DDDBConn.bExecuteSql( _
                "update " & moDDTable.TableName & " set " & Me.ColumnName & "=null where " & Me.ColumnName & "=0", _
                "Unable to convert column " & Me.Fullname & " from zeros to nulls") _
                Then
                Throw New Exception("Could not change 0 to nulls for " & Me.ColumnName)
            End If
        End If

        ' Update DDColumn based on what we just did
        CopyValues(oDDColumnTarget)


    End Sub

    ' Copy our settings to the target column (assuming we've just upsized it)
    Friend Sub CopyValues(ByVal oDDColumnTarget As DDColumn)
        oDDColumnTarget.ColumnSize = Me.ColumnSize
        oDDColumnTarget.DataType = Me.DataType
        oDDColumnTarget.ColumnName = Me.ColumnName
        oDDColumnTarget.SetEquivalentType()
    End Sub

    ' Drop any default on the specified column
    Friend Sub DropDefaults()
        Dim sSql$ = ""
        Dim oRs As ACS.DataAccess.claRecordSet = Nothing
        Dim sDefName$ = ""

        ' Get the constraint name from the system tables
        sSql = "select d.name from sysobjects t, syscolumns c, sysobjects d " & _
            "where c.id=t.id and c.cdefault = d.id and t.name='" & _
            Me.DDTable.TableName & "' and c.name='" & Me.ColumnName & "' and t.type='u'"

        Try
            If Not Me.DDTable.DDManager.DDDBConn.bQuery(oRs, sSql, _
                        "Getting name of default constraint for " & Me.Fullname) Then
                Throw New Exception("Unable to select Default for " & Me.Fullname)
            End If

            If oRs.Read Then
                sDefName = oRs.IDataReader_Item("Name").ToString
            End If
        Finally
            If oRs IsNot Nothing Then oRs.Dispose()
        End Try

        ' Drop that constraint If we found the name
        If sDefName.Length > 0 Then
            If Not Me.DDTable.DDManager.DDDBConn.bExecuteSql _
                ("alter table " & Me.DDTable.TableName & " drop constraint " & sDefName, _
                "Dropping default constraing for " & Me.Fullname) Then

                Throw New Exception("Unable to drop constraint " & sDefName)
            End If
        End If

    End Sub

    ' Drop any indexes using the specified column
    Friend Sub DropIndexes()

        ' Use a queue of dropped indexes bcause we cannot drop them while enumerating through them
        Dim DroppedIndexes As New Generic.Queue(Of DDIndex)

        If Me.DDTable.Indexes.Count > 0 Then
            For Each obDDIndex As Generic.KeyValuePair(Of String, DDIndex) In Me.DDTable.Indexes

                If obDDIndex.Value.UsesColumn(Me.ColumnName) Then
                    If Not Me.DDTable.DDManager.DDDBConn.bExecuteSql( _
                            "drop index " & Me.DDTable.TableName & "." & obDDIndex.Value.IndexName, _
                            "Dropping index ") Then
                        Throw New Exception("Could not drop index " & Me.DDTable.TableName & "." & obDDIndex.Value.IndexName)
                    End If
                    'Add to the list of dropped indexes
                    DroppedIndexes.Enqueue(obDDIndex.Value)
                End If
            Next
        End If

        If DroppedIndexes.Count > 0 Then
            For Each oDroppedIndex As DDIndex In DroppedIndexes
                Me.DDTable.Indexes.Remove(oDroppedIndex.Expression)
            Next
        End If
    End Sub

    ' Add the default back on the specified column
    Friend Sub AddDefaults(ByVal oDDColumnTarget As DDColumn, ByVal bImplementDRI As Boolean)
        Dim sSql$
        sSql = Me.DefaultClause(bImplementDRI)
        If sSql <> "" Then
            sSql = "alter table " & Me.DDTable.TableName & " with nocheck add " & sSql & " for " & Me.ColumnName
            If Not oDDColumnTarget.DDTable.DDManager.DDDBConn.bExecuteSql(sSql, "Adding default for column " & _
                Me.Fullname) Then
                Throw New Exception("Could not add Default for " & Me.ColumnName)
            End If
        End If

    End Sub

    ' Return the SQL required to create/alter a column
    ' If current value is good enough, return an empty string
    ' This function doesn't force an update if the null constraint changed -- that's done in a previous pass
    Friend Function UpsizeSql(ByVal oDDColumnTarget As DDColumn, ByVal bImplementDRI As Boolean, _
            ByVal bDropObsoleteData As Boolean) As String
        Dim bUpdateRequired As Boolean
        Dim sSql$ = ""

        ' If no target column (table or column doesn't exist), must output SQL
        If oDDColumnTarget Is Nothing Then
            bUpdateRequired = True

            ' If data type changed, must output SQL
        ElseIf Me.EquivType <> oDDColumnTarget.EquivType Then
            bUpdateRequired = True

            ' If datatype invalid, must output SQL
            'ElseIf oDDColumnTarget.InvalidType Then
            '    bUpdateRequired = True

            ' If null constraint changes, update require
        ElseIf (bImplementDRI And Me.AllowNulls <> oDDColumnTarget.AllowNulls) _
                Or (Not bImplementDRI And oDDColumnTarget.AllowNulls) Then
            bUpdateRequired = True

            ' If number gets bigger, update required
        ElseIf Me.EquivType = En_DataType.enmNumberDT Then
            If Me.ColumnSize > oDDColumnTarget.ColumnSize Then
                bUpdateRequired = True
            End If
            ' If number gets smaller, and dropping obsolete data, update required
            If Me.ColumnSize < oDDColumnTarget.ColumnSize And bDropObsoleteData Then
                bUpdateRequired = True
            End If

            ' If string gets bigger, update required
        ElseIf Me.DataType = En_DataType.enmStringDT Then
            If Me.ColumnSize > oDDColumnTarget.ColumnSize And oDDColumnTarget.ColumnSize > 0 Then
                bUpdateRequired = True

                ' Or if DD is a memo, and DB isn't
            ElseIf Me.ColumnSize = 0 And oDDColumnTarget.ColumnSize <> 0 Then
                bUpdateRequired = True

                ' If string gets smaller and drop obsolete data
            ElseIf Me.ColumnSize < oDDColumnTarget.ColumnSize And bDropObsoleteData Then
                bUpdateRequired = True

                ' Changing from a memo
            ElseIf Me.ColumnSize > 0 And oDDColumnTarget.ColumnSize = 0 And bDropObsoleteData Then
                bUpdateRequired = True

            End If

        End If

        ' No change required
        If Not bUpdateRequired Then Return ""

        ' Base type
        Select Case meDataType
            Case En_DataType.enmStringDT
                If 0 < miColumnSize And miColumnSize <= 2000 Then
                    sSql = "VARCHAR(" & miColumnSize & ")"
                Else
                    sSql = "TEXT"
                End If
            Case En_DataType.enmDateDT
                sSql = "DATETIME"
            Case En_DataType.enmCurrencyDT
                sSql = "MONEY"
            Case En_DataType.enmBooleanDT
                sSql = "SMALLINT"
            Case En_DataType.enmNumberDT
                If miColumnSize <= 5 Then
                    sSql = "SMALLINT"
                Else
                    sSql = "INTEGER"
                End If
            Case En_DataType.enmImageDT
                sSql = "IMAGE"
        End Select

        ' Add the column name
        sSql = Me.ColumnName & " " & sSql

        ' If primary key, add primary key constraint
        If UCase(Me.ColumnName) = UCase(Me.DDTable.PrimaryKey) Then

            ' If primary key is a number, add Identity clause
            If meDataType = En_DataType.enmNumberDT Then
                sSql = sSql & " IDENTITY(1,1)"
            End If

            sSql = sSql & " PRIMARY KEY"

            ' Otherwise, add DEFAULT and NULL constraint
        Else

            ' Allow nulls if DRI and column says it
            If Me.AllowNulls And bImplementDRI Then
                sSql = sSql & " NULL"

                ' Otherwise, add default and not null
            Else
                ' Add DEFAULT clause if not an alter column
                If oDDColumnTarget Is Nothing Then
                    sSql = sSql & " " & DefaultClause(bImplementDRI)
                End If

                sSql = sSql & " NOT NULL"
            End If
        End If

        ' Return
        Return sSql

    End Function

    Friend Function DefaultClause(ByVal bImplementDRI As Boolean) As String
        ' If nulls allowed, no default clause

        If Me.AllowNulls AndAlso bImplementDRI Then Return ""

        Select Case Me.DataType
            Case En_DataType.enmBooleanDT, En_DataType.enmNumberDT, En_DataType.enmCurrencyDT
                Return "DEFAULT 0"
            Case En_DataType.enmStringDT
                Return "DEFAULT ' '"
            Case En_DataType.enmDateDT
                Return "DEFAULT '12/30/1899'"
            Case En_DataType.enmImageDT
                Return "DEFAULT 0x"
            Case Else
                Throw New Exception("UpsizeSql Invalid data type " & meDataType)
        End Select

        Return ""

    End Function

    ' Drop this column
    Friend Function DropColumn() As Boolean
        DropDefaults()
        DropIndexes()

        If Not Me.DDTable.DDManager.DDDBConn.bExecuteSql("alter table " & Me.DDTable.TableName & _
            " drop column " & Me.ColumnName, "Dropping column " & Me.Fullname) _
            Then Return False
        Me.DDTable.Columns.Remove(Me.ColumnName)

        Return True

    End Function

#End Region
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class
