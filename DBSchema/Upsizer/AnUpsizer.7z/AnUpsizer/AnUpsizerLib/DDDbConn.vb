Public Class DDDbConn
    Implements IDisposable

    Dim moConnection As ACS.DataAccess.claConnection
    Dim msServer$
    Dim msDatabase$
    Dim moUpsizer As claUpsizer
    Dim mbCompareOnly As Boolean
    Dim mqErrors As Generic.Queue(Of String)
    Dim mbLogSQL As Boolean
    Protected disposed As Boolean = False
    Private mblnConnectionDisposed As Boolean


    Friend Sub New(ByVal oConnection As ACS.DataAccess.claConnection, ByVal obclaUpziser As claUpsizer, _
        ByVal LogSQL As Boolean)

        moConnection = oConnection
        msServer = oConnection.NUnitGetConnectInfo.Server
        msDatabase = oConnection.NUnitGetConnectInfo.DataBase
        moUpsizer = obclaUpziser
        mbLogSQL = LogSQL
    End Sub

    Public ReadOnly Property Errors() As Generic.Queue(Of String)
        Get
            If mqErrors Is Nothing Then
                mqErrors = New Generic.Queue(Of String)
                Return mqErrors
            Else
                Return mqErrors
            End If
        End Get
    End Property

    Public ReadOnly Property Name() As String
        Get
            Name = msServer & "." & msDatabase
        End Get
    End Property

    Friend ReadOnly Property Database() As String
        Get
            Database = msDatabase
        End Get
    End Property

    Public Property CompareOnly() As Boolean
        Get
            CompareOnly = mbCompareOnly
        End Get
        Set(ByVal value As Boolean)
            mbCompareOnly = value
        End Set
    End Property

    Public ReadOnly Property DbConnection() As ACS.DataAccess.claConnection
        Get
            DbConnection = moConnection
        End Get
    End Property

    Public Property ConnectionDisposed() As Boolean
        Get
            Return mblnConnectionDisposed
        End Get
        Set(ByVal blnConnectionDisposed As Boolean)
            mblnConnectionDisposed = blnConnectionDisposed
        End Set
    End Property

    'Wrappers of claConnection
    ' Execute an upsizer SQL statement
    ' Log statement if a log file is configured
    ' Don't execute if "compare only" is configured
    Friend Function bExecuteSql(ByVal sSql$, ByVal sDesc$) As Boolean
        WriteToSQLLog(sDesc)
        WriteToSQLLog(Space(2) & sSql)

        ' Execute or fakeout
        If mbCompareOnly Then
            bExecuteSql = True
        Else
            Try
                If moConnection.Execute(sSql) Then
                    Return True
                End If

            Catch ex As Exception
                'Add to error collection
                Me.Errors.Enqueue(ex.InnerException.ToString)
                WriteToSQLLog(Space(2) & "***Errors: " & ex.GetBaseException.Message)
            End Try

        End If
    End Function

    Friend Function bExecuteSql(ByVal sSql$, ByVal sDesc$, ByRef iRecordsAffected As Integer) As Boolean
        WriteToSQLLog(sDesc)
        WriteToSQLLog(Space(2) & sSql)

        ' Execute or fakeout
        If mbCompareOnly Then
            bExecuteSql = True
        Else
            Try
                If moConnection.Execute(sSql, iRecordsAffected) Then
                    Return True
                End If

            Catch ex As Exception
                'Add to error collection
                Me.Errors.Enqueue(ex.InnerException.ToString)
                WriteToSQLLog(Space(2) & "***Errors: " & ex.GetBaseException.Message)
            End Try

        End If
    End Function

    ' Execute a query
    ' Description is what goes in the error message. Blank means not to log an error
    Friend Function bQuery(ByRef oRs As ACS.DataAccess.claRecordSet, ByVal sSql$, ByVal sDesc$) As Boolean
        WriteToSQLLog(sDesc)
        WriteToSQLLog(Space(2) & sSql)

        Try
            oRs = moConnection.OpenRecordset(sSql)
            If oRs IsNot Nothing Then Return True

        Catch ex As Exception
            'Add to error collection
            Me.Errors.Enqueue(ex.InnerException.ToString)
            WriteToSQLLog(Space(2) & "***Errors: " & sDesc$ & vbCrLf & ex.GetBaseException.Message)

        End Try

    End Function

    'Write to the SQL log
    Private Sub WriteToSQLLog(ByVal sql$)
        If mbLogSQL Then
            moUpsizer.WriteToSQLLog(sql)
        End If
    End Sub

#Region "IDisposable Support"
    Protected Overridable Overloads Sub Dispose( _
    ByVal disposing As Boolean)
        If Not Me.disposed Then
            If disposing Then
                If Not mblnConnectionDisposed Then
                    moConnection.Dispose()
                End If
                If mqErrors IsNot Nothing Then
                    mqErrors.Clear()
                End If
            End If
        End If
        Me.disposed = True
    End Sub
    Public Overloads Sub Dispose() Implements IDisposable.Dispose
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
    Protected Overrides Sub Finalize()
        Dispose(False)
        MyBase.Finalize()
    End Sub
#End Region

End Class
