Public Class DDParameter
#Region " Declarations "

    Dim msParameterName$        ' Name of the parameter
    Dim msDataType$             ' The data type of the parameter
    Dim mblnIsOutput As Boolean    ' Whether or not this parameter is an output parameter
#End Region
#Region " Constructors "
    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal sParamName As String, ByVal sDataType As String)
        ParameterName = sParamName
        DataType = sDataType
    End Sub

    Public Sub New(ByVal sParamName As String, ByVal sDataType As String, ByVal blnIsOutPut As Boolean)
        ParameterName = sParamName
        DataType = sDataType
        IsOutput = blnIsOutPut
    End Sub
#End Region
#Region " Declarations "
    Public Property ParameterName() As String
        Get
            Return msParameterName
        End Get
        Set(ByVal value As String)
            msParameterName = value
        End Set
    End Property

    Public Property DataType() As String
        Get
            Return msDataType
        End Get
        Set(ByVal value As String)
            msDataType = value
        End Set
    End Property

    Public Property IsOutput() As Boolean
        Get
            Return mblnIsOutput
        End Get
        Set(ByVal value As Boolean)
            mblnIsOutput = value
        End Set
    End Property

#End Region

End Class
