Imports System.Data.SqlClient

Public Class TestClass

    'Private Sub CommitDDLChange(ByVal oDDTargetManager As DDManager, _
    '    ByVal ServerTableName As String, _
    '    ByVal dsTableName As String, _
    '    ByVal Verb$)

    '    Dim SQLString As New System.Text.StringBuilder("")

    '    SQLString.Append(Verb & " TABLE " & ServerTableName & " (")

    '    For Each Col As DDColumn In oDDManager.Tables(dsTableName).Columns

    '        SQLString.Append(" " & Col.ColumnName & " ")

    '        Dim mytype As String = Col.DataType.ToString

    '        Select Case mytype.ToLower
    '            Case "system.string"
    '                SQLString.Append(" nvarchar (50), ")
    '            Case "system.boolean"
    '                SQLString.Append(" bit, ")
    '        End Select
    '    Next

    '    Dim PFKey As String = DirectCast(oDDTargetManager.Tables(dsTableName).PrimaryKey, DataColumn())(0).ColumnName

    '    SQLString.Append("CONSTRAINT [ pk_" & PFKey & _
    '    "] PRIMARY KEY CLUSTERED (" & PFKey & "))")

    '    Dim strSQL As String = SQLString.ToString

    '    'Commit the DDL statement
    '    oDDManager.DDDBConn.bExecuteSql(SQLString.ToString, "Commiting DDL Statement")

    'End Sub


End Class
