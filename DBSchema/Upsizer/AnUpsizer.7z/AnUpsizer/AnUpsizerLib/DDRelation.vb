Imports AnUpsizerLib.AnEnums

Public Class DDRelation

#Region " Declarations "

    Const SQLERR_CYCLIC_CASCADE$ = "may cause cycles or multiple cascade paths"
    Dim moDDTable As DDTable
    Dim msFKey$
    Dim msChild$
    Dim msParentTable$
    Dim msPKey$
    Dim mbCascadeFailed As Boolean
    Dim meDeletePolicy As en_DeletePolicy

#End Region

#Region " Constructors "

    ' Construct from XML
    Friend Sub New(ByVal oDDTable As DDTable, ByVal oDomDoctor As XMLDomDoctor)
        moDDTable = oDDTable

        msFKey = oDomDoctor.GetAttribute("ForeignKey")
        msParentTable = oDomDoctor.GetAttribute("ParentTable")

        Select Case oDomDoctor.GetAttribute("DeletePolicy", False)
            Case "Cascade"
                meDeletePolicy = en_DeletePolicy.Cascade
            Case "Set Null"
                meDeletePolicy = en_DeletePolicy.SetNull
            Case ""
                meDeletePolicy = en_DeletePolicy.Prevent
            Case Else
                Me.DDTable.DDManager.UpsizerLibParent.LogUpsizeError("Invalid DeletePolicy " & _
                    oDomDoctor.GetAttribute("DeletePolicy", False), False)
        End Select
    End Sub

    ' Populate via DB connection
    Friend Sub New(ByVal oDDTable As DDTable, _
        ByVal stFKey$, _
        ByVal stPKey$, _
        ByVal stChild$, _
        ByVal stParentTable$, _
        ByVal enmeDeletePolicy As en_DeletePolicy)

        moDDTable = oDDTable
        msFKey = stFKey
        msPKey = stPKey
        msChild = stChild
        msParentTable = stParentTable
        meDeletePolicy = enmeDeletePolicy
    End Sub

#End Region

#Region " Properties "

    Public ReadOnly Property Name() As String
        Get
            Return "FK_" & Me.ChildTable & "__" & msFKey
        End Get
    End Property

    Public Property CascadeFailed() As Boolean
        Get
            Return mbCascadeFailed
        End Get
        Private Set(ByVal value As Boolean)
            mbCascadeFailed = value
        End Set
    End Property

    Public ReadOnly Property DeletePolicy() As en_DeletePolicy
        Get
            Return meDeletePolicy
        End Get
    End Property

    Public ReadOnly Property ChildTable() As String
        Get
            Return Me.moDDTable.TableName
        End Get
    End Property

    Public ReadOnly Property ParentTable() As String
        Get
            Return msParentTable
        End Get
    End Property

    Public ReadOnly Property PKey() As String
        Get
            If msPKey Is Nothing Then
                msPKey = Me.DDTable.DDManager.Table(ParentTable).PrimaryKey
            End If

            Return msPKey
        End Get
    End Property

    'This is the Key for the collection so do an Upper on the name
    Public ReadOnly Property FKey() As String
        Get
            Return msFKey.Trim.ToUpper
        End Get
    End Property

    Public ReadOnly Property DDColumn() As DDColumn
        Get
            Return Me.DDTable.Columns(Me.FKey)
        End Get
    End Property

    Public ReadOnly Property DDTable() As DDTable
        Get
            Return moDDTable
        End Get
    End Property

    Public Function AllowNulls() As Boolean
        Return Me.DDColumn.AllowNulls
    End Function

#End Region

#Region " Database support "

    ' Create this relation in the target DB
    Public Sub CreateRelation(ByVal oDDTableTarget As DDTable)
        Dim bCascadeFailed As Boolean
        Dim bCyclicErrorFound As Boolean
        Dim bAddRelation As Boolean
        ' If cascade, try to create with cascade
        If Me.DeletePolicy = en_DeletePolicy.Cascade OrElse Me.DeletePolicy = en_DeletePolicy.SetNull Then
            If Not oDDTableTarget.DDManager.DDDBConn.bExecuteSql(GetSQL(oDDTableTarget.TableName, Me.DeletePolicy), "Creating releation " & Me.Name) Then

                ' If error due to cyclic problem, don't quit yet -- try to create without cascade
                ' but mark as cascade failed, so in DDRelations, we can mark as unimplemented to
                ' force client side cascade
                For Each sError As String In oDDTableTarget.DDManager.DDDBConn.Errors
                    If sError.Contains(SQLERR_CYCLIC_CASCADE) Then
                        bCascadeFailed = True
                        bCyclicErrorFound = True
                        Exit For
                    End If
                Next

                If Not bCyclicErrorFound Then
                    Me.DDTable.DDManager.UpsizerLibParent.LogUpsizeError("Error Creating FK constraint with " & GetDeletePolicyName(Me.DeletePolicy) & _
                    Me.Name & " because of orphans in DB", False)
                End If
            Else
                bAddRelation = True
            End If
        End If

        ' Try without cascade
        If Me.DeletePolicy <> en_DeletePolicy.Cascade AndAlso Me.DeletePolicy <> en_DeletePolicy.SetNull OrElse bCascadeFailed Then
            
            If Not oDDTableTarget.DDManager.DDDBConn.bExecuteSql(GetSQL(oDDTableTarget.TableName), "Creating FK constraint " & Me.Name) Then
                Me.DDTable.DDManager.UpsizerLibParent.LogUpsizeError("Error Creating FK constraint without cascade " & _
                    Me.Name & " because of orphans in DB", False)
            Else
                bAddRelation = True
            End If
        End If

        ' Create relation in target DD
        If bAddRelation Then
            Dim obNewRelation As New DDRelation(Me.DDTable, Me.FKey, Me.PKey, _
                Me.ChildTable, Me.ParentTable, Me.DeletePolicy)

            obNewRelation.CascadeFailed = bCascadeFailed
            oDDTableTarget.Relations.Add(obNewRelation.FKey, obNewRelation)
        End If
    End Sub
    Private Function GetDeletePolicyName(ByVal enDeletePolicy As en_DeletePolicy) As String
        Select Case enDeletePolicy
            Case en_DeletePolicy.Cascade
                Return "cascade"
            Case en_DeletePolicy.SetNull
                Return "set null"
        End Select
        Return ""
    End Function
    Private Function GetSQL(ByVal sTableName As String, Optional ByVal enDeletePolicy As en_DeletePolicy = en_DeletePolicy.Prevent) As String
        Dim sSQL As String = "alter table " & sTableName & " add constraint " & Me.Name & " foreign key (" & _
                Me.FKey & ") references " & Me.ParentTable & "(" & Me.PKey & ")"

        Select Case enDeletePolicy
            Case en_DeletePolicy.Cascade
                sSQL = sSQL & " on delete cascade"
            Case en_DeletePolicy.SetNull
                sSQL = sSQL & " on delete set null"
        End Select
        Return sSQL
    End Function
    ' Drop this relation
    Public Sub DropRelation()

        If Not Me.DDTable.DDManager.DDDBConn.bExecuteSql("alter table " & msChild & _
            " drop constraint " & Me.Name, "Dropping constraint " & Me.Name) _
            Then
            Throw New Exception("Unalbe to drop constraint " & Me.Name)
        End If

        Me.DDTable.Relations.Remove(Me.FKey)
    End Sub

#End Region
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class
